---
name: sysmac-sourceless-lib-decrypt
version: 0.5.3
description: 离线解密欧姆龙 Sysmac Studio「无源库」（创建库类型「常规库」+ 勾选「禁用源显示」得到的 .slr/.smc2）里加密保留的 ST 源码；类型「没有源代码的库」+ 禁用源显示的组合已于 2026-11-20 实测：该类库不含 EncryptedFile，改为内嵌 BuiltLibraryFile 编译体，文内给出判型、转路线与解析方法。适用于授权的安全审计：验证自己做的库到底防不防得住。核心结论——这类"无源库"不是删除源码，而是 AES-256-CBC 加密保留 + 显示层禁用；密钥与 IV 完全由文件内明文 EncryptionLock 字符串自包含推导，无外部密钥、无机器绑定、无密码参与，任何拿到文件的人都能纯离线解出全部源码。本 skill 给出加密载体形态、EncryptionLock 32 字符布局与进制链推导算法、完整可运行的 Python 解密配方、EncryptedBody 自描述信封处理、重加密逐字节比对的自验证方法，以及"不解密也能看到什么"的明文泄露面清单。当用户要求审计 Sysmac 无源库、解出 .slr/.smc2 里库功能块的 ST 源码、评估无源库防护强度，或需要从 EncryptedFile 取回自己库的源码时使用。附自包含脚本 scripts/smx_decrypt.py（判型 + 批量解密 + 重加密逐字节自证 + 两条真实 lock 锚点自检，纯离线，只需 pycryptodome）。2026-11-21 补充：「没有源代码的库」+禁显类型虽无密文可解，但在**同时拥有同版本可解容器**时可转 rebuild skill §2b.2「换载体」拿到可看源码的工程（端到端验证通过）；把明文装配进无源码库本体从未实测。2026-11-22 追加：对「没有源代码的库」+禁显的 17 POU 工程实测，Controller ELF 可反汇编/反编译为伪代码（8 FULL / 8 PARTIAL / 1 SKELETON），但 ST 原文仍不可得，且不要走 AES 解密；伪代码不能宣称源码等价。2026-11-22 再补：把反编译伪代码经 rebuild §2b.5 重建为源可见工程的尝试已被用户判定不可用（POU 体为空、语义全丢），伪代码只能作人工重写参考，不能变成可运行程序。仅限自有库与已授权目标；不得用于侵犯第三方知识产权。
metadata:
  author: hoverwu
  unofficial: true
  tested_against: 'Sysmac Studio V1.68 (1.68.0.64010) 64bit 导出的库 .slr（创建类型「常规库」+ 勾选「禁用源显示」；7 个 POU：1 FB + 6 Function）与引用工程 .smc2，2026-11-20 实测；另实测「没有源代码的库」+ 禁显工程/库（IsSource=false，7 POU，2026-11-20）；2026-11-22 另实测「没有源代码的库」+禁显 17 POU 工程（0 EncryptedFile / 17 BuiltLibraryFile）的编译体反编译边界'
  emoji: '🔓'
  requires:
    python: '>=3.10'
    pip: ['pycryptodome']
---

# Sysmac 无源库离线解密（授权审计用）

作者：hoverwu ｜ 版本：0.5.3 ｜ 建立：2026-11-20

## 0.0 依赖与环境（换机器必读）

**离线段（解密 / 重建 / 编译产物分析）自包含**，只要：

| 项 | 要求 | 说明 |
| --- | --- | --- |
| Python | ≥ 3.10 | 只用标准库 + `pycryptodome` |
| `pycryptodome` | 任意版本 | `pip install pycryptodome`；装进专用 venv，别污染全局 |
| 操作系统 | 不限 | 离线段纯 Python，Windows/Linux/macOS 都可 |
| 网络 | **不需要** | 全程离线；不上传任何库文件 |
| 原工程 / 密码 / 机器绑定 | **都不需要** | key/IV 由文件内明文 lock 自包含推导 |

**UI 段（`sysmac-sourceless-lib-rebuild` §3）另需**：Windows + Sysmac Studio V1.68（本 skill 的实测版本）
+ `sysmac-studio-control` 操控 skill（含 `ss_*.py`，**不在本 skill 目录内**，属另一个项目）。
没有它就只能做离线段——离线段已经能拿到全部明文，UI 段只用于"证明 Sysmac 真的显示"。

**先自检再动手**（4 项，含两条真实 lock 锚点）：

```bash
python scripts/smx_decrypt.py --selftest
```

**一条命令完成判型 + 批量解密 + 重加密自证**：

```bash
python scripts/smx_decrypt.py "库.slr"              # 人读
python scripts/smx_decrypt.py "库.slr" -o out --json # 落盘 .st.txt + 机器可读报告
```

输出 `TYPE`（五型）/ 三旗标 / `EncryptedFile` 的 **raw 与 unescaped 双计数** / `BuiltLibraryFile` 与
`StructuredTextModel` 计数 / `Unicode` 直方图 / 逐 POU 的字符数与 sha256 / **重加密逐字节是否一致** / `VERDICT`。
`--selftest` 与 `--anchors` 可单独跑。

> 若你的环境里已经有 `sysmac-studio-control` 的 `ss_libtype.py`，两者判型口径一致，可互换。

## 0.1 版本适用性（换版本必读）

**本 skill 的全部结论只在一个版本上验证过**：Sysmac Studio **V1.68（文件版本 `1.68.0.64010`）64bit** + Windows 11 64bit，
样例为 7 个 POU（1 FB + 6 Function）的 `.slr`（创建类型「常规库」+ 勾选「禁用源显示」）。

- **归档是哪版生成的**：`LibraryModel` 里有 `<ApplicationProductVersion>1.68.0.64010</ApplicationProductVersion>`。
  `scripts/smx_decrypt.py` 会读它并打一行 `PRODUCER Sysmac Studio <版本>`；与实测版本不一致时打 `VERSION:` 警告
  （**不阻断**，只提示"结论未在该版本上验证过"）。读不到也报警——别把"没读到"当成"版本一致"。
- **本机 Sysmac 是哪版**：`python <sysmac-sourceless-lib-rebuild>/scripts/smx_ui.py version`，或 帮助(H) → 版本信息。

| 情形 | 离线段（§1–§6 全部内容） | UI 段（`sysmac-sourceless-lib-rebuild` §3） |
| --- | --- | --- |
| 同 build `1.68.0.64010` | 直接照用 | 直接照用 |
| 同 minor 不同 build | 直接照用；`--selftest` 的两条真实 lock 锚点是纯算法，不随版本变 | 先确认版本，再做一次单 POU A/B 对照 |
| 跨 minor | **先验 3 件事再引用结论**：① 判型五型仍成立（`TYPE` 不是 `UNKNOWN`）；② `--selftest` 仍过；③ 解出的明文里 `EncryptedBody` 信封结构未变 | **必须重测**（UIA 树是本 skill 最脆弱的部分） |

**换版本最小复核清单**：

```bash
python scripts/smx_decrypt.py --selftest                  # 1) 推导 + 锚点 + 信封处理仍对
python scripts/smx_decrypt.py "库.slr"                    # 2) 看 PRODUCER 行 + TYPE 不是 UNKNOWN
python scripts/smx_decrypt.py "库.slr" -o out --json      # 3) 逐 POU 的 reenc=OK 全绿
```

三条全过 → 离线段结论可沿用；任一条不过 → 把输出连同 `PRODUCER` 行记下来，按 §7 记「未验证」，**不要外推**。

## 0. 非官方声明与授权边界（先读）

- 本 Skill **不是 OMRON 官方产物**，全部结论来自对自己导出的无源库做逆向验证（防御性审计），已实测的条目标注【实测】。
- **只用于审计自己的库或已获明确授权的目标**。解密第三方库源码可能侵犯著作权；本 skill 不替代该判断。
- 不上传库文件/密文到任何在线解密、反编译服务（配方全程离线，本机可完成）。
- 原件只读：一切实验在副本上做；先 `sha256sum` 记录原件哈希。

## 1. 一句话结论【实测】

**「无源库」= 加密保留源码 + 禁止显示，不是删除源码。** 加密为 AES-256-CBC/PKCS7；密钥与 IV 完全由文件内**明文** `EncryptionLock` 字符串自包含推导——无外部密钥、无机器绑定、无库密码参与。防护强度≈混淆（"钥匙贴在锁上"）。

**实测对象口径（重要，别外推）**：以上 AES 结论只对**创建库时类型选「常规库」+ 勾选「禁用源显示」**导出的库成立。Sysmac 另一种**「没有源代码的库」+ 禁用源显示**已于 2026-11-20 实测：该类库 `IsSource=false`、`IsBackwardCompatibleNoSource=true`，归档内 **0 个 EncryptedFile**，本 skill 的解密配方**不适用**；但它并非"什么都拿不到"——库以 `BuiltLibraryFile` 形式内嵌 `Controller`（base64 → ELF64 **ET_DYN** x86-64 共享对象；2026-11-22 复核更正，原记 ET_REL 有误）、`Simulator`（base64 → PE）与 `PouBodySourceHolder`（base64 → 仅 CX-IL 链接元数据，无 ST Body）。按 `.oem` 的 `trackingId` 可映射 POU，按 ELF/PE 路线可恢复接口符号、调用图与状态机骨架；**源码文本仍不可仅凭该文件恢复**。判型仍按 §1 三步：仍是 EncryptedFile → 本配方适用；无 EncryptedFile 但有 BuiltLibraryFile → 转编译体解析。

**拿到新库先判型（先跑命令，别手数标签）**：

```bash
python scripts/smx_decrypt.py "库.slr"               # 判型 + 解密 + 重加密自证（自包含）
python scripts/smx_decrypt.py "工程.smc2" --json     # 机器可读
python scripts/smx_decrypt.py --selftest             # 4 项自检
```

一条命令给出：`TYPE`（`AES_HIDDEN` / `AES_VISIBLE` / `NO_SOURCE` / `PLAIN_VISIBLE` / `UNKNOWN`）、旗标、
`EncryptedFile` 的 **raw 与 unescaped 双计数**、`BuiltLibraryFile` / `StructuredTextModel` / 明文体计数、
以及 `NEXT` 建议路径。**为什么必须用命令**：`<EncryptedFile>` 在实体 XML 里是 HTML 转义的
（`&lt;EncryptedFile&gt;`），直接对原始 XML 数会得 **0**，从而把"常规库+禁显"误判成"无加密源码"——
判型是岔路口，判错会把整条分析带偏。命令里 `raw` 与 `unescaped` 两个数不一致就是这条陷阱的指纹。

手工复核时的三步（全只读）：① 解包看根实体 `LibraryModel` 的旗标与「常规库+禁显」样本的差异（有无 NoSource 类旗标）；② 看 PouBody 实体里还是不是 `<EncryptedFile>`（EncryptionLock + base64 Body）结构；③ 对比引用工程 `.smc2` 里的嵌入形态。仍是 EncryptedFile → 本 skill 配方直接适用；PouBody 空壳/无 Body → 离线解密死路，转 `sysmac-build-artifact-capture`（编译产物捕获 → 反汇编）或运行时通道，并把结果按 §7 回填本 skill。

**分流决策（判型之后）**：

| 判型结果 | 下一步 |
| --- | --- |
| `AES_HIDDEN`（`IsSource=true` + `IsDisableSourceDisplay=true` + 有密文） | 本 skill §4 配方解密 → 需要交付可读库时转 `sysmac-sourceless-lib-rebuild` |
| `AES_VISIBLE`（`IsSource=true` + `IsDisableSourceDisplay=false` + **仍有密文**） | **无需解密**：显示已开，Sysmac 会自己用 lock 现解；要交付明文再走 §4 取文本。**这类库的密文与钥匙都还在**——2026-11-21 实测：拿改旗标后的库按 §4 配方纯离线解，**7/7 全出、与明文逐字节一致**（重加密也逐字节回原密文）⇒ **分发即公开源码** |
| `NO_SOURCE`（`IsSource=false` / `NoSource=true`，`BuiltLibraryFile` 内嵌）且**手上没有明文参照** | 只能走编译体解析（`sysmac-build-artifact-capture`）：接口/调用图/状态机骨架可恢复，**ST 全文不可得**；2026-11-22 实测 17 POU：Controller ELF 可反汇编/反编译为伪代码（8 FULL / 8 PARTIAL / 1 SKELETON），但这不是原 ST，也不能宣称源码等价 |
| `NO_SOURCE` 且**已有同版本明文参照** | 转 `sysmac-sourceless-lib-rebuild` §2b。**注意实测边界**：已走通的是「换载体」——用**同名同版本的可解容器**（AES 库）改旗标后替换工程引用，**不是**把明文装配进无源码库本体（后者从未实测，且有结构障碍，见 rebuild §2b.3）。前提是你手上确实有那个可解容器 |
| `PLAIN_VISIBLE`（无密文 + 明文 `Text`） | 已是源可见库，直接导出/对照，无需解密 |

**2026-11-22 追加：`NO_SOURCE` 的编译体反编译边界**（17 POU 工程实测）。这类目标 `StructuredTextModel=0`、`EncryptedFile=0`，AES 解密路径**完全不适用**；可做的是从目标自身 `BuiltLibraryFile` 解出 `Controller` ELF64 与 `Simulator` PE，按 `.oem` 的 `trackingId` 映射 POU。Controller ELF 为 ET_DYN/x86-64、无 DWARF；用 `capstone` 可反汇编，用 `.dynsym`/`.rela.plt` 可解析调用名，用 `.rodata` 可读常量。17/17 均能产出伪代码，但完整度分层：小 Function 可 FULL，大型 FB 多为 PARTIAL/SKELETON（`FB_AxisObject` 7 492 指令仅骨架）。**结论：能恢复逻辑骨架/伪代码，不能恢复原 ST；不要因为看到 `BuiltLibraryFile` 就尝试解密，也不要声称"源码已逆向成功"。** ~~若要查看这些伪代码，可按 `sysmac-sourceless-lib-rebuild` §2b.5 生成源可见验证工程~~ —— **此路已实测判不可用（2026-11-22）**：按 rebuild §2b.5 生成的源可见工程，17/17 POU 体为空（仅 `;`）、逻辑全在注释里，只能看不能跑，用户明确判定「重构的不行」。反编译伪代码**不能**经重建工程变成可运行程序；它只是人工重写的参考底稿。


## 2. 载体形态【实测】

| 对象 | 形态 |
| --- | --- |
| `.slr` / `.smc2` | ZIP 容器（store 为主），GUID 命名的实体 xml + `.oem` 实体清单（UTF-8 BOM 的 XML，Entity type/id/name/父子结构） |
| 库根模型 `LibraryModel` | `IsSource="true"` + `IsDisableSourceDisplay="true"`、`Password` 空——源码都在，只禁了显示 |
| POU 程序体 `PouBody/<GUID>.xml` | `StructuredTextModel` 内 HTML 转义包裹 `<EncryptedFile>`：`<EncryptionLock>`（**明文**，32 字符）+ `<Unicode>Utf8|Utf16</Unicode>` + `<Body>`（base64 密文，16 字节对齐）+ `<Checksum>`（语义未定位，见 §7） |
| FB/Function 实体本体 | 可能是 148 B `NullObject` 占位——接口/变量在其它实体文件里 |
| 解密载荷 | 不是裸 ST：是 `EncryptedBody` 自描述信封（§5 第 5 步） |

**明文泄露面【实测】**：即使不碰加密，库的变量表（含内部 VAR 与中文注释）、FB/Function 接口（全部引脚）、数据类型定义、调用网络（实例声明的 JSON 网络）在 `.slr`/`.smc2` 里**全部明文**——审计先看这些，算法骨架往往已可推断。

**导入重加密【实测】**：同一 POU 在 `.slr` 与引用工程 `.smc2` 里 lock 与密文**不同**（每次导出/导入用 `Random(DateTime.Now.Ticks)` 生成新 lock），但解密明文 md5 **逐字节相同**——随机性只影响"生成哪把锁"，不影响"锁能否被打开"。

## 3. 加密算法【实测，DLL 方法级】

实现位于 `Omron.Cxap.Framework.Implementation.dll`（`EncrypterBase.DecryptBody` / `Key.LockToKey` / `Key.LockToIV` / `NativeEncryptionServiceFacade.CreateRijndaelAlgorithm`）：

- `Rijndael.Create()` **未设 Mode/Padding/BlockSize** → 默认 **CBC / PKCS7 / 128bit 块**；key 32 B（AES-256）、IV 16 B。
- 密文 = `base64( AES-256-CBC-PKCS7( UTF8(明文ST), key32, iv16 ) )`。
- key/IV 字符串 → 字节用 `StringToByteArray`：逐字符取低字节（ASCII），长度不足右补 `0x2D('-')`。
- 无源库路径与工程口令保护（`SolutionCryptoProviderMD5`）是**两条不同路径**；`Password` 空不影响无源库解密。

### EncryptionLock 32 字符布局【实测】

以 `ISRR1EFH9/SIGAWSPT--------------` 为例：

```
[0:4)   ISRR    进制表前半
[4:9)   1EFH9   key 数据段（截到 '/'）
[9]     /       分隔符
[10:14) SIGA    IV 数据段（到段内首个 '-' 前 4 位）
[14:18) WSPT    进制表后半
[18:32) ----…   填充
```

推导规则：

1. 进制表 `loc2 = lock[:4] + lock[首个'-'前4 : 首个'-']`（8 字符）；每字符在字母表 `0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ` 中的下标即一个进制基 `enc[0..7]`（范围 11–35）。
2. key 数据段 = `lock[4:]` 从段内下标 4 起找 `'/'`，截到它；IV 数据段 = `'/'` 之后到段内首个 `'-'` 再前推 4 位。
3. 解扰循环（key/IV 共用）：`i = 7→1`，`part = DecimalToBase( BaseToDecimal(part, enc[i]), enc[i-1] )`；最后 `part = DecimalToBase( BaseToDecimal(part, enc[0]), 36 )`。
4. 结果右补 `'-'`：key 到 32 字符、IV 到 16 字符；按 ASCII 取字节。
5. 原始 key/IV 段各为 4 字符（生成时随机取 4 个字母表字符）。

## 4. 可运行解密配方（Python，纯离线）【实测 14/14 成功】

依赖：`pycryptodome`（装进专用 venv，别污染全局解释器）。以下代码是实测脚本的移植版——先跑 §末尾的**自验证**确认推导正确再用于自己的库。

> **已固化成命令**：`python scripts/smx_decrypt.py <库> [-o out] [--json]`。它把"判型 → 遍历实体 → 解密 → 信封二次 unescape → 重加密自证 → 落盘 .st.txt"全串起来了，并内置 §5 的两条锚点。
> 下面这段是**配方本体**，用于换环境 / 换版本时对照，或你想自己控制落盘结构时直接用。

```python
ALPH = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'

def b2d(s, b):
    neg = s.startswith('-')
    if neg: s = s[1:]
    v = 0
    for ch in s:
        d = ALPH.index(ch)
        if d >= b: raise ValueError(f'char {ch} invalid for base {b}')
        v = v * b + d
    return -v if neg else v

def d2b(v, b):
    if v == 0: return '0'
    neg = v < 0
    if neg: v = -v
    out = ''
    while v:
        out = ALPH[v % b] + out
        v //= b
    return ('-' if neg else '') + out

def _encoder(lock):
    fd = lock.index('-')
    loc2 = lock[:4] + lock[fd - 4:fd]
    return [ALPH.index(c) for c in loc2], loc2

def _unscramble(part, enc):
    for i in range(7, 0, -1):
        part = d2b(b2d(part, enc[i]), enc[i - 1])
    return d2b(b2d(part, enc[0]), 36)

def lock_to_key(lock):
    enc, _ = _encoder(lock)
    s = lock[4:]
    return _unscramble(s[:s.index('/', 4)], enc).ljust(32, '-')

def lock_to_iv(lock):
    enc, _ = _encoder(lock)
    s = lock[lock.index('/', 4) + 1:]
    return _unscramble(s[:s.index('-') - 4], enc).ljust(16, '-')

def decrypt_pou_body(entity_xml_text):
    """entity_xml_text = PouBody <GUID>.xml 全文（含 EncryptedFile）。
    返回 (实体 GUID, EncryptedBody 信封 xml 字符串)。"""
    import re, base64, html
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad
    t = html.unescape(entity_xml_text)          # EncryptedFile 被外层 HTML 转义包裹
    lock = re.search(r'<EncryptionLock>(.*?)</EncryptionLock>', t).group(1)
    body = re.search(r'<Body>(.*?)</Body>', t, re.S).group(1)
    uni  = re.search(r'<Unicode>(.*?)</Unicode>', t)
    key = lock_to_key(lock).encode('ascii')     # 32 B
    iv  = lock_to_iv(lock).encode('ascii')      # 16 B
    cipher = base64.b64decode(body)
    plain = unpad(AES.new(key, AES.MODE_CBC, iv).decrypt(cipher), 16)
    if uni and uni.group(1) == 'Utf16':
        plain = plain.decode('utf-16-le', errors='replace')
    else:
        plain = plain.decode('utf-8', errors='replace')
    guid = re.search(r'<EntityIdentifier>(.*?)</EntityIdentifier>', plain)
    return (guid.group(1) if guid else None), plain
```

### 信封处理【实测】

解密出的明文不是裸 ST，而是自描述信封：

```xml
<?xml version="1.0" encoding="utf-16"?>
<EncryptedBody>
  <EntityType>PouBody</EntityType>
  <EntityIdentifier><GUID></EntityIdentifier>
  <DefaultAccessLevel>All</DefaultAccessLevel>
  <Body>…HTML 转义的 ST 源码…</Body>
</EncryptedBody>
```

对 `<Body>` 内容再做一次 `html.unescape` 即得裸 ST 源码。信封里的 EntityType/EntityIdentifier 可用来校验"解出的密文没有被挪位"。

## 5. 自验证方法（判定解密正确，不靠猜）【实测】

1. **重加密逐字节比对（最强）**：把解出的明文按同一 key/IV 重新 `AES-256-CBC-PKCS7` 加密 + base64，回填对比原 `<Body>`——AES-CBC 确定性输出应与原密文**逐字节一致**。不一致 = 推导或信封处理有错。
2. **交叉引擎**：pycryptodome 与 .NET `RijndaelManaged`（PowerShell）双实现各跑一遍，结果必须一致（Sysmac 同源引擎是后者）。
3. **跨容器配对**：同一库 POU 在 `.slr` 与引用工程 `.smc2` 各解一次，明文 md5 应相同（lock 不同、明文恒等）。
4. **明文完整性**：ST 首部注释与尾部收尾段（功能块典型 `bExecOld := bExecute;` 式边沿记忆段）齐全，非截断。
5. **推导自检锚点**【实测】：lock `ISRR1EFH9/SIGAWSPT--------------` 必须推出 key 32 字符 = `MRBO` + 28 个 `'-'`、IV 16 字符 = `EYYW` + 12 个 `'-'`；lock `VELK52D2H/4IC7LHPZN-------------` 必须推出 `UNRJ…` / `STQC…`。不一致先修推导再继续。

## 6. 审计流程建议

1. `sha256sum` 记录原件哈希；全部操作在副本上。
2. 先看**明文泄露面**（§2）：变量表/接口/数据类型/调用网络——很多审计在这一步就能回答"防不防得住"。
3. 解密全部 `EncryptedFile`（配方 §4 + 自验证 §5），落盘 `.st.txt` 与 lock/key/iv 对照表（**key/IV 不是秘密，但落盘时注明来源 lock**）。
4. 若要交付"重建库"或"源码比对"，用配套 skill `sysmac-sourceless-lib-rebuild`。
5. 报告里区分【实测】与推断；无法观测的一律 INCONCLUSIVE，不硬凑结论。

## 7. 已验证事实 vs 未验证

> `影响面` 三档：**阻塞可用性**（错了结论要降级）｜**静默错误风险**（错了看不出来）｜**仅认知/边界**（记录即可，不必排期）。

| 状态 | 影响面 | 内容 |
| --- | --- | --- |
| 实测 | — | 14/14 EncryptedFile 解密成功（7 slr + 7 proj）；跨容器明文 md5 一致 7/7；重加密逐字节一致 7/7；key/IV 推导两真实 lock 验证闭合 |
| 实测（2026-11-21，判型陷阱） | 静默错误风险 → 已工具化 | **`<EncryptedFile>` 在实体 XML 里是 HTML 转义的**（`&lt;EncryptedFile&gt;`）。直接对原始 XML 数标签会得到 **0**，从而误判"这个库没有加密源码、AES 不适用"。**判型不要手数**：跑 `scripts/smx_decrypt.py`（§1），它内部先 `html.unescape`、并把 **raw 与 unescaped 双计数**一起打印，两个数不一致即报警。已复核：无源码库 `.slr` 与同名 `.smc2` 反转义后仍为 0 个 EncryptedFile、8 个 `BuiltLibraryFile` ⇒ 无源码库的判型成立（不是转义造成的假阴性） |
| 实测（2026-11-21，改旗标库） | 静默错误风险 → 已工具化+已量化 | **有密文 ≠ 源码被隐藏**：改过旗标的库 `IsDisableSourceDisplay=false`（显示已开），但里面 7 个密文 Body 与原库**逐字节相同**（lock 也相同）——"改旗标"只是允许显示，密文和钥匙都还在，Sysmac 现解现显示。**进一步实测解密成本为零**：按 §4 配方纯离线解这 7 个 Body，**7/7 全出、与离线明文逐字节一致、重加密逐字节回原密文**（FB = 12 110 字符 / 345 行 / `2cc52a1b…`，与离线明文、UI 提取三方一致）⇒ **这类库分发出去就是公开源码**。因此判型必须**旗标 + 载体**一起看：`AES_HIDDEN`（禁显）与 `AES_VISIBLE`（已开显但密文在）是两种库，处置不同（见 §1 分流表）。`scripts/smx_decrypt.py` 已把这两种分开报 |
| 实测（2026-11-21） | — | **`Unicode` 属性全量扫描**：本机 35 个 `.slr`/`.smc2`、12 个含加密信封的归档、**717 个信封全部 `Utf8`，0 个 `Utf16`**（含欧姆龙自带库：CJSeriesInst 76 / ForVar 51 / IF 220 / IFForVar 245）。⇒ Utf16 分支至今**无样本**，风险量化为 717/717；实现上按"非 Utf8 即拒绝并告警"处理，**不要猜编码** |
| 未验证 | 仅认知/边界 | `EncryptedFile <Checksum>`（有符号 int32）语义——不等于明文/密文 CRC32。**当前三条路径都不生成新密文**（改旗标 / 明文替换 / 重加密同 key），Checksum 原样保留天然有效 ⇒ 现在无触发路径。只有"改代码后重新加密分发（密封补丁库）"才需要它，届时用"改一字节看 Sysmac 报不报错"一轮 UI 即可定性 |
| 未验证 | 仅认知/边界 | `Unicode=Utf16` 的实际解码细节（无样本）。策略：遇到就拒绝并记录 lock/文件名，不做猜测性解码 |
| 实测（2026-11-20，无源码库判型） | — | **创建类型「没有源代码的库」+ 勾选「禁用源显示」**：`IsSource=false` / `IsBackwardCompatibleNoSource=true`，0 个 EncryptedFile，AES 配方不适用；库内嵌 `BuiltLibraryFile` × 7（`Controller`=ELF64 **ET_DYN** x86-64、`Simulator`=PE、`PouBodySourceHolder`=仅 CX-IL 元数据；2026-11-22 复核更正 ELF 类型，原记 ET_REL 有误）。可按 trackingId 映射 POU、反汇编、恢复 iStep/错误码/调用骨架；ST 源码文本不可仅凭该文件恢复。**不得把「常规库+禁显」的 AES 结论外推到本类型** |
| 实测（2026-11-21，无源码库闭环） | — | **本类型的完整闭环已跑通**：用离线明文重建出源可见库（`IsSource=true` + `IsDisableSourceDisplay=false`）导入新工程后，Sysmac 编辑器显示 ST 全文，与离线明文**逐字节一致**（11 766 字符 / 345 行 / `2cc52a1b…`），保存后工程内嵌 7 个 `StructuredTextModel`。即：本类型**源码拿不到 ≠ 拿不回**——只要有一份明文参照（工程内明文泄露面/运行时捕获），重建 + UI 验证即可交付可读源码库 |

## 8. 版本记录

| 版本 | 日期 | 内容 |
| --- | --- | --- |
| 0.5.3 | 2026-11-22 | **文档更正：`Controller` 的 ELF 类型 ET_REL → `ET_DYN`（共享对象）**。直接从 7 POU `.slr` 与 17 POU 工程解出的载荷实测 `e_type=0x03`（段表为 `.dynsym`/`.dynamic`/`.got.plt`/`.rela.plt`，无 `.symtab`、无 DWARF）；旧记录 ET_REL 系 2026-11-20 误记。仅改文档与措辞，脚本、算法与结论不变 |
| 0.5.2 | 2026-11-22 | **纠正 0.5.1 里的一处误导**：原文说"若要查看这些伪代码，可按 rebuild §2b.5 生成源可见验证工程"，暗示这条路能产出可看结果。实测判定：该工程 17/17 POU 体为空（仅 `;`），逻辑全在注释里，只能看不能跑，用户明确「重构的不行」。§1 边界段已改为"此路不可用"，并明确反编译伪代码不能经重建工程变成可运行程序，只能作人工重写参考 |
| 0.5.1 | 2026-11-22 | 回填 17 POU「没有源代码的库」+禁显工程实测：`StructuredTextModel=0` / `EncryptedFile=0` / 17 `BuiltLibraryFile`，AES 解密不适用；Controller ELF64 可反汇编/反编译为伪代码（8 FULL / 8 PARTIAL / 1 SKELETON），但 ST 原文仍不可得，伪代码不得宣称源码等价。§1 分流表与新增边界段同步 |
| 0.5.0 | 2026-11-21 | **通用化（换机/换版本可用）**：① 新增 **§0.1「版本适用性」**——写明实测版本 `1.68.0.64010` / Windows 11，说明 `PRODUCER` 行怎么读、三档版本差异各自要重验什么、并给出 3 条换版本最小复核清单；② `scripts/smx_decrypt.py` 加 `VERIFIED_VERSION` 与 `VERSION:` 警告（版本不符只提示不阻断）；③ 清理正文里残留的内部任务编号与证据路径；④ 恢复被过度脱敏的实测值（FB 明文 `2cc52a1b…`） |
| 0.4.0 | 2026-11-21 | **可移植性修复（2026-11-21）**：① 新增 `scripts/smx_decrypt.py`（1.0.0）——判型 + 批量解密 + 重加密逐字节自证 + 两条真实 lock 锚点自检，**纯离线自包含**（只需 pycryptodome），实测五个真实文件全对、7/7 解密且重加密一致；② 新增 §0.0「依赖与环境（换机器必读）」写明离线段自包含、UI 段另需 `sysmac-studio-control`；③ §1 判型命令由外部 `ss_libtype.py` 改为本 skill 自带脚本（等价可互换）；④ 更正 `NO_SOURCE`+明文参照一行的口径（「换载体」≠「明文装配」）；⑤ 版本表按 semver 重排 |
| 0.3.4 | 2026-11-21 | 回填 T17 实测：**「改旗标库分发即公开源码」从推论变成实测**——拿 `IsDisableSourceDisplay=false` 但密文原样的库，按 §4 配方纯离线解，**7/7 全出、与 T3 明文逐字节一致、重加密逐字节回原密文**（FB 12 110 字符/345 行/`2cc52a1b…`，与离线明文、UI 提取三方一致），解密成本为零（无原工程、无密码、无机器绑定、无 UI）；§1 分流表 `AES_VISIBLE` 行与 §7 对应条目同步 |
| 0.3.3 | 2026-11-21 | 判型工具化（2026-11-21）：§1 判型改为**先跑 `ss_libtype.py`**（MCP 新增离线命令，内部 `html.unescape` + raw/unescaped 双计数 + 按祖先链剔除 `BuildOption` 干扰模型，带 `--selftest` 11 项）；§1 分流表按 `AES_HIDDEN` / `AES_VISIBLE` / `NO_SOURCE` / `PLAIN_VISIBLE` 四型重写；§7 新增「有密文 ≠ 源码被隐藏」实测（重建库改旗标后 7 个 Body 与原库逐字节相同） |
| 0.3.2 | 2026-11-21 | 回填 T14 两项实测：① **`<EncryptedFile>` 是 HTML 转义的**，直接数原始 XML 会得 0 从而误判"无加密源码"，判型必须先 `html.unescape`（已复核无源码库反转义后仍为 0，T11 判型成立）；② `Unicode` 全量扫描：35 个归档 / 12 个含信封 / **717 个信封全 Utf8、0 Utf16**（含欧姆龙自带库 592 个），Utf16 分支风险量化为 717/717，策略改为"非 Utf8 即拒绝并告警"。§7 表新增 `影响面` 列 |
| 0.3.1 | 2026-11-21 | 回填 审计方/T12 实测：新增 §1「分流决策」表——无 EncryptedFile 但**已有明文参照**时直接转 `sysmac-sourceless-lib-rebuild` 重建源可见库，UI 显示全文与明文逐字节一致（端到端 PASS）；明确「源码拿不到 ≠ 拿不回」 |
| 0.3.0 | 2026-11-20 | 回填 审计方/T11 实测：「没有源代码的库」+禁显＝0 EncryptedFile、`BuiltLibraryFile` 内嵌 ELF64/PE/CX-IL holder；解密路径不适用，转编译体解析；源码仍不可直接恢复 |
| 0.2.0 | 2026-11-20 | 口径澄清：实测对象=创建类型「常规库」+勾选「禁用源显示」；新增 §1 判型三步与「没有源代码的库」+禁显组合的未验证条目（用户后续实验） |
| 0.1.0 | 2026-11-20 | 首版：机制、EncryptionLock 推导、解密配方、信封、自验证（实测 7 POU 无源库，V1.68 导出） |
