#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""smx_decrypt.py —— Sysmac 无源库离线判型 + 批量解密（自包含，只依赖 pycryptodome）

用法:
    python smx_decrypt.py <库.slr|工程.smc2>                 # 判型 + 解密全部 EncryptedFile
    python smx_decrypt.py <文件> -o <输出目录> --json        # 机器可读报告
    python smx_decrypt.py --selftest                        # 内置自检（含两条真实 lock 锚点）
    python smx_decrypt.py --anchors                         # 只跑推导锚点

设计要点（都是踩过的坑，别改）:
  1. 实体 XML 里的 <EncryptedFile> 是 **HTML 转义**的（&lt;EncryptedFile&gt;）。
     对原始 XML 数标签得 0，会误判成"无加密源码"。本脚本 raw / unescaped 双计数并列输出，
     两数不等即打 ESCAPING 警告 —— 这个"不等"就是陷阱的指纹。
  2. .smc2 里有两个 LibraryModel：ReferredLibraries 下的是被引用库；BuildOption 下的是
     工程自身的构建选项（IsDisableSourceDisplay=true 属正常）。按**祖先链**剔除，不按 Name 猜。
  3. 重加密必须用**解密得到的原始字节**（信封 XML 的 UTF-8 字节），不要 decode 再 encode。
  4. Unicode 非 Utf8 一律拒绝并告警（本机 717/717 全 Utf8，Utf16 分支无样本，不猜编码）。

作者: hoverwu ｜ 版本: 1.0.0 ｜ 仅限自有库与已授权审计
"""
import sys, os, io, re, json, html, base64, hashlib, zipfile, argparse

ALPH = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'

# 本 skill 全部结论只在这个版本上验证过。换版本先看 SKILL.md「版本适用性」。
VERIFIED_VERSION = '1.68.0.64010'
VERIFIED_FAMILY = '1.68'

# 两条真实 lock 的推导锚点（来自 Sysmac Studio V1.68 导出库，实测闭合）
ANCHORS = [
    ('ISRR1EFH9/SIGAWSPT--------------', 'MRBO', 'EYYW'),
    ('VELK52D2H/4IC7LHPZN-------------', 'UNRJ', 'STQC'),
]


# ---------------------------------------------------------------- 推导
def b2d(s, b):
    neg = s.startswith('-')
    if neg:
        s = s[1:]
    v = 0
    for ch in s:
        d = ALPH.index(ch)
        if d >= b:
            raise ValueError('char %r invalid for base %d' % (ch, b))
        v = v * b + d
    return -v if neg else v


def d2b(v, b):
    if v == 0:
        return '0'
    neg = v < 0
    if neg:
        v = -v
    out = ''
    while v:
        out = ALPH[v % b] + out
        v //= b
    return ('-' if neg else '') + out


def encoder(lock):
    fd = lock.index('-')
    loc2 = lock[:4] + lock[fd - 4:fd]
    return [ALPH.index(c) for c in loc2]


def unscramble(part, enc):
    for i in range(7, 0, -1):
        part = d2b(b2d(part, enc[i]), enc[i - 1])
    return d2b(b2d(part, enc[0]), 36)


def lock_to_key(lock):
    enc = encoder(lock)
    s = lock[4:]
    return unscramble(s[:s.index('/', 4)], enc).ljust(32, '-')


def lock_to_iv(lock):
    enc = encoder(lock)
    s = lock[lock.index('/', 4) + 1:]
    return unscramble(s[:s.index('-') - 4], enc).ljust(16, '-')


def check_anchors():
    rows, ok = [], True
    for lock, kp, ip in ANCHORS:
        k, i = lock_to_key(lock), lock_to_iv(lock)
        good = k.startswith(kp) and i.startswith(ip) and len(k) == 32 and len(i) == 16
        ok = ok and good
        rows.append({'lock': lock, 'key32': k, 'iv16': i, 'pass': good})
    return ok, rows


# ---------------------------------------------------------------- 解密
def _aes():
    try:
        from Crypto.Cipher import AES
    except ImportError:
        raise SystemExit(
            '缺少依赖 pycryptodome。\n'
            '  安装： pip install pycryptodome\n'
            '  或装进专用 venv： python -m venv .venv && .venv/Scripts/pip install pycryptodome\n'
            '（本脚本其余部分只用标准库；只有 AES 解密/重加密需要它）')
    return AES


def decrypt_entity(text):
    """text = 实体 XML 全文。返回 dict(lock, unicode, cipher, plain_bytes, plain_str)。"""
    from Crypto.Util.Padding import unpad
    t = html.unescape(text)
    lock = re.search(r'<EncryptionLock>(.*?)</EncryptionLock>', t).group(1).strip()
    body = re.search(r'<Body>(.*?)</Body>', t, re.S).group(1)
    uni = re.search(r'<Unicode>(.*?)</Unicode>', t)
    uni = uni.group(1).strip() if uni else 'Utf8'
    cipher = base64.b64decode(''.join(body.split()))
    key = lock_to_key(lock).encode('ascii')
    iv = lock_to_iv(lock).encode('ascii')
    plain = unpad(_aes().new(key, AES_MODE_CBC(), iv).decrypt(cipher), 16)
    if uni != 'Utf8':
        return {'lock': lock, 'unicode': uni, 'cipher': cipher,
                'plain_bytes': plain, 'plain_str': None,
                'error': 'Unicode=%s 无样本，按策略拒绝解码' % uni}
    return {'lock': lock, 'unicode': uni, 'cipher': cipher,
            'plain_bytes': plain, 'plain_str': plain.decode('utf-8', errors='replace')}


def AES_MODE_CBC():
    return _aes().MODE_CBC


def reencrypt(plain_bytes, lock):
    from Crypto.Util.Padding import pad
    key = lock_to_key(lock).encode('ascii')
    iv = lock_to_iv(lock).encode('ascii')
    return _aes().new(key, AES_MODE_CBC(), iv).encrypt(pad(plain_bytes, 16))


def envelope_to_st(plain_str):
    """信封 <EncryptedBody><Body>…</Body></EncryptedBody> → 裸 ST（再 unescape 一次）。"""
    m = re.search(r'<Body>(.*?)</Body>', plain_str, re.S)
    raw = m.group(1) if m else plain_str
    return html.unescape(raw)


# ---------------------------------------------------------------- 判型
def _local(tag):
    return tag.rsplit('}', 1)[-1]


def judge(path):
    """返回 {type, flags, counts, unicode_hist, warnings, models}"""
    import xml.etree.ElementTree as ET
    raw_enc = esc_enc = built = stm = 0
    uni_hist = {}
    warnings = []
    models = []
    entries = 0
    producer = None
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            if not name.lower().endswith('.xml'):
                continue
            entries += 1
            try:
                text = z.read(name).decode('utf-8-sig', errors='replace')
            except Exception as e:
                warnings.append('READ-FAIL %s: %s' % (name, e))
                continue
            raw_enc += text.count('<EncryptedFile>')
            un = html.unescape(text)
            if producer is None:
                m = re.search(r'<ApplicationProductVersion>([^<]*)</ApplicationProductVersion>', un)
                if m and m.group(1).strip():
                    producer = m.group(1).strip()
            esc_enc += un.count('<EncryptedFile>')
            built += un.count('<BuiltLibraryFile')
            stm += un.count('<StructuredTextModel')
            for u in re.findall(r'<Unicode>(.*?)</Unicode>', un):
                u = u.strip()
                uni_hist[u] = uni_hist.get(u, 0) + 1
            # 旗标：按祖先链剔除 BuildOption
            try:
                root = ET.fromstring(text)
            except Exception:
                continue
            stack = [(root, [])]
            while stack:
                node, anc = stack.pop()
                if _local(node.tag) == 'LibraryModel':
                    flags = {}
                    for ch in node:
                        if _local(ch.tag) in ('IsSource', 'IsDisableSourceDisplay',
                                              'IsBackwardCompatibleNoSource', 'Name',
                                              'LibraryId', 'Version', 'Password'):
                            flags[_local(ch.tag)] = (ch.text or '').strip()
                    models.append({'entry': name, 'ancestors': anc,
                                   'role': 'buildoption' if 'BuildOption' in anc else 'entity',
                                   'flags': flags})
                for ch in node:
                    stack.append((ch, anc + [_local(ch.tag)]))

    primary = [m for m in models if m['role'] == 'entity'] or models
    if primary:
        f = primary[0]['flags']
        is_src = f.get('IsSource', '').lower() == 'true'
        dis = f.get('IsDisableSourceDisplay', '').lower() == 'true'
        nosrc = f.get('IsBackwardCompatibleNoSource', '').lower() == 'true'
        if esc_enc > 0:
            typ = 'AES_HIDDEN' if dis else 'AES_VISIBLE'
        elif not is_src or nosrc:
            typ = 'NO_SOURCE'
        elif stm > 0:
            typ = 'PLAIN_VISIBLE'
        else:
            typ = 'UNKNOWN'
    else:
        f, typ = {}, 'UNKNOWN'

    if raw_enc != esc_enc:
        warnings.append('ESCAPING: 原始 XML <EncryptedFile>=%d，unescape 后=%d —— '
                        '直接数原始 XML 会误判"无加密源码"' % (raw_enc, esc_enc))
    if typ == 'AES_VISIBLE':
        warnings.append('AES_VISIBLE: 显示已开但密文仍在 —— 按本脚本可直接解出明文，'
                        '分发即公开源码')
    if 'Utf16' in uni_hist:
        warnings.append('Utf16: 出现 %d 个 Utf16 信封，无样本，按策略拒绝解码' % uni_hist['Utf16'])
    if typ == 'NO_SOURCE' and built == 0:
        warnings.append('NO_SOURCE 但无 BuiltLibraryFile —— 判型可疑，人工复核')
    if producer and producer != VERIFIED_VERSION:
        warnings.append(
            'VERSION: 该归档由 Sysmac Studio %s 生成，本 skill 只在 %s 上验证过 —— '
            '实体 schema / 加密细节 / 判型判据都可能不同，结论需重新实测'
            % (producer, VERIFIED_VERSION))
    elif not producer:
        warnings.append('VERSION: 归档里没读到 ApplicationProductVersion，'
                        '无法确认生成版本（本 skill 只验证过 %s）' % VERIFIED_VERSION)
    roles = {m['role'] for m in models}
    if len(roles) > 1:
        warnings.append('双 LibraryModel：entity=%d / buildoption=%d，已按祖先链取 entity'
                        % (sum(m['role'] == 'entity' for m in models),
                           sum(m['role'] == 'buildoption' for m in models)))

    return {'type': typ, 'flags': f, 'models': models, 'producer': producer,
            'counts': {'xml_entries': entries, 'encrypted_file_raw': raw_enc,
                       'encrypted_file_unescaped': esc_enc,
                       'built_library_file': built, 'structured_text_model': stm},
            'unicode': uni_hist, 'warnings': warnings}


NEXT = {
    'AES_HIDDEN': '走 sysmac-sourceless-lib-decrypt §4 解密；要交付可读库转 rebuild 路径 b/c',
    'AES_VISIBLE': '无需解密（Sysmac 自己解）；要明文用本脚本；分发即公开源码',
    'NO_SOURCE': 'AES 不适用 → 编译体解析（capture）或 rebuild（有明文参照时）',
    'PLAIN_VISIBLE': '已是源可见库，直接导出/对照',
    'UNKNOWN': '未找到模型或旗标缺失，不猜，记录样本',
}


# ---------------------------------------------------------------- 主流程
def run(path, outdir=None, as_json=False):
    path = os.path.abspath(path)
    if not os.path.isfile(path):
        raise SystemExit('找不到文件: %s' % path)
    info = judge(path)
    info['file'] = path
    info['size'] = os.path.getsize(path)
    info['sha256'] = _sha256(path)
    info['next'] = NEXT.get(info['type'], '')

    anchor_ok, anchor_rows = check_anchors()
    info['anchors'] = {'pass': anchor_ok, 'rows': anchor_rows}

    entities = []
    if info['type'] in ('AES_HIDDEN', 'AES_VISIBLE'):
        _aes()          # 预检依赖：缺 pycryptodome 就在这里一次性报清楚，不要逐条吞异常
        with zipfile.ZipFile(path) as z:
            for name in z.namelist():
                if not name.lower().endswith('.xml'):
                    continue
                text = z.read(name).decode('utf-8-sig', errors='replace')
                if '<EncryptedFile>' not in html.unescape(text):
                    continue
                row = {'entry': name}
                try:
                    d = decrypt_entity(text)
                    row.update({'lock': d['lock'], 'unicode': d['unicode'],
                                'cipher_len': len(d['cipher'])})
                    if d['plain_str'] is None:
                        row.update({'error': d.get('error', 'decode refused')})
                    else:
                        st = envelope_to_st(d['plain_str'])
                        row['st_chars'] = len(st.replace('\r\n', '\n').strip('\n'))
                        row['st_sha256'] = hashlib.sha256(
                            st.replace('\r\n', '\n').strip('\n').encode('utf-8')).hexdigest()
                        row['reencrypt_identical'] = (
                            base64.b64encode(reencrypt(d['plain_bytes'], d['lock'])).decode()
                            == base64.b64encode(d['cipher']).decode())
                        g = re.search(r'<EntityIdentifier>(.*?)</EntityIdentifier>', d['plain_str'])
                        row['guid'] = g.group(1).strip() if g else None
                        if outdir:
                            os.makedirs(outdir, exist_ok=True)
                            fn = (row['guid'] or name.replace('/', '_')) + '.st.txt'
                            with open(os.path.join(outdir, fn), 'w',
                                      encoding='utf-8', newline='') as fh:
                                fh.write(st)
                            row['st_file'] = fn
                except Exception as e:
                    row['error'] = '%s: %s' % (type(e).__name__, e)
                entities.append(row)

    ok = sum(1 for e in entities if e.get('st_sha256'))
    reenc = sum(1 for e in entities if e.get('reencrypt_identical'))
    verdict = 'N/A'
    if info['type'] in ('AES_HIDDEN', 'AES_VISIBLE'):
        verdict = 'PASS' if entities and ok == len(entities) and reenc == len(entities) \
            and anchor_ok else 'FAIL'
    info['decrypted'] = entities
    info['summary'] = {'entities': len(entities), 'decrypted': ok,
                       'reencrypt_identical': reenc, 'anchors_pass': anchor_ok,
                       'verdict': verdict}

    if as_json:
        print(json.dumps(info, ensure_ascii=False, indent=1))
    else:
        _pretty(info)
    return info


def _sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def _pretty(i):
    print('FILE    %s' % i['file'])
    print('        size=%s B  sha256=%s' % (format(i['size'], ','), i['sha256'][:16] + '…'))
    pv = i.get('producer') or '(未记录)'
    mark = '' if pv == VERIFIED_VERSION else '  ← 与已验证版本不同'
    print('PRODUCER Sysmac Studio %s%s' % (pv, mark))
    print('TYPE    %-13s %s' % (i['type'], i['next']))
    f = i['flags']
    print('FLAGS   IsSource=%s  IsDisableSourceDisplay=%s  NoSource=%s' % (
        f.get('IsSource', '-'), f.get('IsDisableSourceDisplay', '-'),
        f.get('IsBackwardCompatibleNoSource', '-')))
    c = i['counts']
    print('BODY    EncryptedFile=%d (raw=%d)  BuiltLibraryFile=%d  '
          'StructuredTextModel=%d' % (c['encrypted_file_unescaped'],
                                      c['encrypted_file_raw'],
                                      c['built_library_file'],
                                      c['structured_text_model']))
    print('UNICODE %s' % (i['unicode'] or '-'))
    if i['decrypted']:
        print('DECRYPT %d/%d 条；重加密逐字节一致 %d/%d；锚点 %s' % (
            i['summary']['decrypted'], i['summary']['entities'],
            i['summary']['reencrypt_identical'], i['summary']['entities'],
            'PASS' if i['anchors']['pass'] else 'FAIL'))
        for e in i['decrypted']:
            if e.get('error'):
                print('   ! %-58s %s' % (e['entry'], e['error']))
            else:
                print('   · %-58s %5d 字符  %s  %s' % (
                    e['entry'], e['st_chars'], e['st_sha256'][:8],
                    'reenc=OK' if e['reencrypt_identical'] else 'reenc=DIFF'))
    print('VERDICT %s' % i['summary']['verdict'])
    for w in i['warnings']:
        print('WARN    %s' % w)


def selftest():
    ok, rows = check_anchors()
    for r in rows:
        print('%s %-34s key=%s iv=%s' % ('PASS' if r['pass'] else 'FAIL',
                                         r['lock'], r['key32'], r['iv16']))
    # 往返：任意明文 → 加密 → 解密
    lock = ANCHORS[0][0]
    from Crypto.Util.Padding import unpad
    msg = b'<EncryptedBody><Body>PROGRAM P VAR x : INT; END_VAR</Body></EncryptedBody>'
    ct = reencrypt(msg, lock)
    pt = unpad(_aes().new(lock_to_key(lock).encode(), AES_MODE_CBC(),
                          lock_to_iv(lock).encode()).decrypt(ct), 16)
    rt = pt == msg
    print('%s roundtrip  (lock=%s)' % ('PASS' if rt else 'FAIL', lock))
    esc = '<StructuredTextModel>&lt;EncryptedFile&gt;x&lt;/EncryptedFile&gt;</StructuredTextModel>'
    trap = (esc.count('<EncryptedFile>') == 0 and
            html.unescape(esc).count('<EncryptedFile>') == 1)
    print('%s escaping-trap  raw=0 unescaped=1' % ('PASS' if trap else 'FAIL'))
    good = ok and rt and trap
    print('\nSELFTEST %s' % ('PASS' if good else 'FAIL'))
    return 0 if good else 1


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument('file', nargs='?')
    ap.add_argument('-o', '--out')
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--anchors', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if a.anchors:
        ok, rows = check_anchors()
        for r in rows:
            print('%s %s key=%s iv=%s' % ('PASS' if r['pass'] else 'FAIL',
                                          r['lock'], r['key32'], r['iv16']))
        return 0 if ok else 1
    if not a.file:
        ap.print_help()
        return 2
    info = run(a.file, a.out, a.json)
    return 0 if info['summary']['verdict'] in ('PASS', 'N/A') else 1


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    raise SystemExit(main())
