---
name: sysmac-build-artifact-capture
version: 0.3.3
description: 捕获 Sysmac Studio 真实编译产物——已保存的 .smc2/.slr 里没有编译载荷（NexBuildResults/传输信息全是空壳），必须建带时间戳副本、用 UI 真编译一次、菜单原生保存，然后做 GUID 归一化归档 diff 并解出内嵌编译 zip。skill 给出七步清单与每步判据（编译证据判据 busy OR 快照变化、INCONCLUSIVE 不放宽；检查所有程序对无改动工程是 no-op 不构成证据）、构建"四件套"两种实测形态（跨工程"新增四件套"与"基线空实体原位重写"都可能，不要预设）、内嵌 zip 成员分类表（LV_*.cxil2 明文 CX IL 接口、UserLib_*.cxif2 编译接口声明与 _n_o_t_d_i_v_i_d_e_d_!_ 源码隐藏标记、ELF .o 目标码、Resource_UserTypes.cxip、hex 族二进制）、NexBuildResults TrackingId ↔ POU 映射方法（经 .oem 实体名），以及收尾哈希核对。实测工程引用的是创建类型「常规库」+勾选「禁用源显示」的库；引用「没有源代码的库」类型时，2026-11-20 实测发现其编译体已随库以 BuiltLibraryFile（Controller=ELF64/Simulator=PE/CX-IL holder）内嵌，无需 UI 编译即可离线解析。2026-11-22 追加：`BuiltLibraryFile` 的 Controller ELF64 可进一步反汇编/反编译为伪代码（17 POU 实测 8 FULL / 8 PARTIAL / 1 SKELETON），但只能恢复逻辑骨架，不能恢复原 ST；Simulator PE 未反汇编。再补：把伪代码重建为源可见工程的尝试已判不可用（POU 体为空、语义全丢），伪代码只能作人工重写参考。依赖 sysmac-studio-control 操控 skill 做 UI 段；仅限自有工程与授权审计。
metadata:
  author: hoverwu
  unofficial: true
  tested_against: 'Sysmac Studio V1.68 (1.68.0.64010) 64bit / Windows 11 / 两个不同工程实测（引用「常规库+禁用源显示」库的工程 76 成员 zip、普通工程 1220 成员 zip），2026-11-20；2026-11-22 对 17 POU NO_SOURCE 工程的 Controller ELF64 做反汇编/反编译边界实测（非原 ST），并实测"伪代码重建源可见工程"路线不可用（POU 体为空）'
  emoji: '🧲'
  requires:
    python: '>=3.10'
---

# Sysmac 编译产物捕获（副本编译 + 原生保存 + 归档 diff）

作者：hoverwu ｜ 版本：0.3.3 ｜ 建立：2026-11-20

仅限自有工程/授权审计；三个铁前提：**原件只读**、编译只对**带时间戳的副本**、UI 走 headless UIA 后台通道（Sysmac 自动提权 High，UIA 进程须同完整性——中权限通道连读子树都被 UIPI 拒绝）。

## 0.0 依赖与环境（换机器必读）

**UI 段与离线段分开看**：

| 段 | 需要什么 | 没有会怎样 |
| --- | --- | --- |
| 第 1–4 步（副本 / 打开 / 编译 / 原生保存） | Windows + Sysmac Studio V1.68 + `sysmac-studio-control` skill（`ss_build.py run` / `ss_save.py`，**不在本目录内**）+ 提权通道（Sysmac 是 High IL） | 只能拿现成的"已编译并保存"归档做离线段 |
| 第 5–7 步（diff / 解 zip / 映射） | **本目录 `scripts/smx_capture_offline.py`，纯 stdlib，离线可跑** | — |

```bash
python scripts/smx_capture_offline.py --selftest                       # 3 项自检
python scripts/smx_capture_offline.py diff   基线.smc2 捕获.smc2        # GUID 归一化 diff
python scripts/smx_capture_offline.py extract 捕获.smc2 -o out          # 解内嵌编译 zip + 分类
python scripts/smx_capture_offline.py map     捕获.smc2 库.slr           # TrackingId ↔ POU
python scripts/smx_capture_offline.py analyze 基线.smc2 捕获.smc2 库.slr -o out   # 三合一
```

`analyze` 的 `OVERALL` 判据：**构建实体有变化（新增或原位重写）且库 POU 全部命中**才算 PASS；
只看"新增"会把"原位重写"形态误判成"没编译"。

## 0.1 版本适用性（换版本必读）

**全部结论只在一个版本上验证过**：Sysmac Studio **V1.68（文件版本 `1.68.0.64010`）64bit** + Windows 11 64bit。

- **归档是哪版生成的**：读 `LibraryModel` 里的 `<ApplicationProductVersion>`。本 skill 的脚本会打一行
  `PRODUCER Sysmac Studio <版本>`；与 `1.68.0.64010` 不一致时打 `VERSION:` 警告（**不阻断**）。
- **本机 Sysmac 是哪版**：`python <rebuild>/scripts/smx_ui.py version`（读 exe 文件版本资源），或 帮助(H) → 版本信息。

| 情形 | 离线段（第 5–7 步 + `smx_capture_offline.py`） | UI 段（第 1–4 步） |
| --- | --- | --- |
| 同 build `1.68.0.64010` | 直接照用 | 直接照用 |
| 同 minor 不同 build | 直接照用（GUID 归一化 diff、内嵌 zip 结构都是容器级约定） | 先确认版本，再做一次小工程试编译，确认"忙/计数/网格"三判据仍可观测 |
| 跨 minor | 先跑 `--selftest`，再用**一个小工程**走完 diff/extract/map 确认成员命名规则未变 | **必须重测**：工具栏按钮名、状态栏 ProgressBar、保存对话框形态都可能变；§1 第 3、4 步的判据要重新确认 |

**换版本最小复核清单**：`python scripts/smx_capture_offline.py --selftest` 通过 → 拿一个"编译过并保存"的旧归档跑
`analyze`，看 `OVERALL` 仍为 PASS 且 `UserLib_*.cxif2` 命名规则一致。不一致就把 `PRODUCER` 行与输出一起记录，按 §2 记 INCONCLUSIVE，**不要外推**。

## 0. 为什么必须这么做【实测】

已保存的 `.smc2`/`.slr` **没有可取的编译载荷**：`NexBuildResults`（30 条全 `HasResult=false`）、`NexBuildVerifierGroup`、`NexTransferInformation`（无 FileInformation）在基线里全是**空壳**，只有加密源码 + 明文接口 + 调用名元信息。真实编译码只存在于"编译过 + 保存过"的归档里——所以要：副本 → UI 真编译 → 菜单原生保存 → diff + 捕获。

## 1. 七步清单（每步：动作 / 判据 / 坑）

### 1. 建副本并校验
带时间戳复制 `.smc2` → `sha256` 与原件一致 → `testzip()` 通过。之后一切写入只对该副本。

### 2. 打开副本（headless）
`SysmacStudio.exe <副本路径>` 启动（由提权通道启动则继承 High，不再弹 UAC）。**ESI 核对框可能不出现**：不要按"进度框后必弹"的预期硬点——轮询 `popups`，框真出现才点 `NoButton`（点 Yes 会用本机 ESI 替换工程 ESI，污染实验）；有的工程根本不触发。

### 3. 编译（唯一算数的证据）
- `工程(P)>检查所有程序(C)` **对无改动工程是瞬时 no-op**（busy 不可见、计数/网格不变）——可点但**单独不构成编译证据**，如实记 INCONCLUSIVE。
- 主证据是工具栏 `编译控制器(B)`。判据缺一不可：观测到忙（状态栏 ProgressBar）**或**计数/网格快照变化 + 之后**连续两个稳定空闲新快照**；errors>0 判 FAIL；只有警告不算失败；忙读不到记 None 不当空闲。**任一不满足判 INCONCLUSIVE，不放宽。**
- 坑：未关的 WPF 模态对话框（库索引等）会吞掉全部工具栏点击 → 假 INCONCLUSIVE；点击落空且无 Sysmac 模态时全屏截图查系统弹层（如「选择应用打开 .pdf」CoreWindow，ESC 解除）。

### 4. 菜单原生保存
`文件(F)>保存(S)`（**不要裸 Ctrl+S**，残留下拉会吃键盘）。判据：sha256 变化 + 目标仍是含条目、CRC 全过的有效 zip。

### 5. GUID 归一化归档 diff
原生保存会**轮换 `.oem` 顶层 GUID** 及其下所有含 GUID 的文件名——直接比 namelist 会得到"全增全删"假象。先把两个归档的条目名做 **GUID 归一化**（每段 GUID 替换成 `<GUID>` 占位）再比，得出：新增条目 / 删除条目 / 内容变化条目。

> **已固化成命令**：`python scripts/smx_capture_offline.py diff <基线> <捕获>`（GUID 归一化 + 只报构建实体）。

**两种实测形态，不要预设**：
- 普通"交付版"工程：编译+保存后**新增**构建四件套（`<GUID>.NexBuildResults` / `.NexBuildVerifierGroup` / `.NexTransferInformation` / 内嵌 `.zip`，共用一个实体 GUID）。
- 库引用测试工程：四件套在基线里**已以空实体存在**，编译+保存后**原位重写**（0 新增、若干条目大小变化——含 CommunicationSetting/ValidationResults/manifest/.oem/stsdb4）。diff 只看"谁从空壳变成有内容"，不看"谁新增"。

### 6. 解出内嵌 zip 并分类
解出全部成员到证据目录，按名字分类（两个实测工程的成员集合不同，下表是并集）。

> **已固化成命令**：`python scripts/smx_capture_offline.py extract <捕获> -o <目录>`（自动挑成员最多的内嵌 zip，按 §1 表分类并统计直方图）。

| 成员 | 实测形态 |
| --- | --- |
| `LV_<32hex>.cxil2` | **明文** CX IL 接口文本：`{IMPORT<ULs.cxip>} MODULE NX … INTERFACE LV_<guid> VAR …`。库 FB/Function 的完整接口（输入/输出/内部变量与 FB 实例声明）都在——不加密 |
| `UserLib_<32hex>.cxif2` | **明文**编译后接口声明：`FUNCTION_BLOCK {a<_n_o_t_d_i_v_i_d_e_d_!_>} <名> VAR_INPUT …`。`_n_o_t_d_i_v_i_d_e_d_!_` 是"源码隐藏"标记——**签名与接口仍明文进编译产物，只有实现体被标隐藏** |
| `Program_/SubProgram_<hex>_N.o` + `Signature_<同hash>.o` | **ELF 目标码**（普通工程实测 ELF64 `e_machine=0x3E`；库工程实测 ELF32）+ 配对签名；反汇编还原逻辑的直接对象 |
| `Resource_UserTypes.cxip` | 数 MB 级二进制（实测 boost `serialization::archive` / 用户数据类型资源） |
| 其余 hex 名无扩展名二进制 | 头部 `41ec832f` 族等私有格式；先记头部与直方图，不当结论 |

### 7. TrackingId ↔ POU 映射 + 收尾
- `NexBuildResults`：`<NexControllerBuildResults … IsAllProgramsCheckDone>` 下逐实体 `<EntityBuildResult TrackingId="<GUID>" Result HasResult IsPretendMatch CompileVersion …>`。**TrackingId 是 POU → 编译结果的连接键**；库 POU 条目的 `CompileVersion` 为空属正常（宿主工程的程序实体才有）。
- TrackingId → 名称映射来源：**项目侧 `.oem`**（FB 引用/调用实体）+ **库 `.slr` 的 `.oem`**（库 POU 实体，type/name/父子）；`entity-map` 类工具里通常没有现成 TrackingId，直接扫 XML。
- **已固化成命令**：`python scripts/smx_capture_offline.py map <捕获> <库.slr>` —— 读库 `.oem` 的 `Entity type/name/trackingId`，与内嵌 zip 的 `UserLib_<32hex>.cxif2` 逐一比对，输出命中/缺失/多余。实测本工程 **7/7 命中、无缺无余**。
- 实测样例：库 FB 的 TrackingId 命中 `LV_<同GUID>.cxil2`（完整 IL 接口）+ `UserLib_<同GUID>.cxif2`（编译接口声明）——即**内嵌 zip 成员的 `<32hex>` 名就是 TrackingId 的无连字符形式**。
- `NexTransferInformation` 记录形态（`HasFileInformations` 是否翻转、FileInformation 计数）——它是"下载链路传的是什么"的实证。
- **收尾**：不保存关闭实例（WPF 保存确认框标题=工程名、Invoke 否(N)）→ 核对副本新 sha 与全部原件哈希未变 → 证据落盘（diff 报告、分类直方图、捕获目录、映射表）。

## 2. 证据与结论标准

- PASS = 捕获到编译载荷**且**目标 POU 的编译条目按 TrackingId 定位成功（能指出它对应哪些 zip 成员/条目）。
- 编译没发生（无证据）、四件套未翻转、或目标条目找不到 → 如实 FAIL/INCONCLUSIVE + 证据，不放宽判据。
- 推断（如 hex 族的格式、.o 与 POU 的一一对应）放"待验证"，不当结论。
- **形态外推边界**：§1 的成员分类表来自引用创建类型**「常规库」+ 勾选「禁用源显示」**库的工程。引用创建类型**「没有源代码的库」**时另走 DLL 专用路径（`ExtractBuildNoSourceLibrary` / `IsNoSourceLibrary` 等）；2026-11-20 实测表明该类库的编译体已随 `.slr` 与引用工程内嵌为 `BuiltLibraryFile`（`Controller`=ELF64 **ET_DYN** x86-64、`Simulator`=PE、`PouBodySourceHolder`=仅 CX-IL 元数据；2026-11-22 复核更正 ELF 类型，原记 ET_REL 有误），**无需 UI 编译即可离线解析**；不会再出现 LV/UserLib 源码接口件。捕获后按实测定分类，不套用 §1 表。
- **什么时候根本不用跑本 skill**【实测，2026-11-21】：
  - 只想**看/拿源码**，而手上已有明文参照（或同版本可解容器）→ 直接转 `sysmac-sourceless-lib-rebuild` §2b.2「换载体」，不必编译、不必反汇编。**注意**：该 skill 里"把明文装配进无源码库本体"那条路**未实测**（§2b.3），别当可用路径。
  - 只有 NO_SOURCE 工程、没有可解容器 → 可走 `sysmac-sourceless-lib-rebuild` §2b.5 生成源可见验证工程（接口精确、逻辑为反编译伪代码，**仍不是原 ST**）；若目标是拿原源码，本条不满足。
  - 目标是「没有源代码的库」→ 编译体已内嵌，离线解 `BuiltLibraryFile` 即可，**别为"拿到编译码"专门编译一遍**。
  - 反过来，**把内嵌库改成外部 `.slr` 引用后保存，工程会显著变小**（实测 248 749 B → 89 119 B）：原工程内嵌 7×ELF64 + 7×PE，改后只留外部引用 + 明文 ST。体积骤降属预期，不是损坏；用"7 个 `StructuredTextModel` 存在 + 哈希"来判完整性，别用体积。

### 2.1 未验证项与影响面

> 三档：**阻塞可用性**｜**静默错误风险**｜**仅认知/边界**。

| 未验证项 | 影响面 | 说明 / 建议 |
| --- | --- | --- |
| hex 名无扩展名二进制族的格式（头部 `41ec832f` 等） | 仅认知/边界 | 只影响"这些成员是什么"的命名与解释，不影响源码恢复。私有格式，逆向成本高、收益低 → **不排期** |
| `.o` 与 POU 的一一对应（按 TrackingId 推断） | 静默错误风险（低） | 若推断错，反汇编会归到错的 POU。缓解：映射必须同时满足 `.oem` 名 + `NexBuildResults` TrackingId 两条证据，单靠文件名不算 |
| `Resource_UserTypes.cxip`（boost `serialization::archive`） | 仅认知/边界 | 用户数据类型资源；解不出不影响 POU 源码与接口。**不排期**，除非要做"完整重建编译产物" |
| 无源码库专用 DLL 路径（`ExtractBuildNoSourceLibrary` / `IsNoSourceLibrary`）未做方法级逆向 | 仅认知/边界 | 现有结论是**行为观测**（内嵌 `BuiltLibraryFile`），不是方法级证明；换大版本可能需重测。不增加能力 → **不排期**，但换版本时先按 §1 重跑一遍观察 |
| 本 skill 的成员分类表只覆盖「常规库+禁显」工程 | 阻塞可用性 | 引用「没有源代码的库」时不出现 LV/UserLib 源码接口件，套表会误判 → 见上文形态外推边界，**必须按实测重新分类**。2026-11-21 已在本工程（引用源可见重建库）直接量到 `UserLib_*.cxif2` = 7、`LV_*.cxil2` = 8，与另一工程同构 |

**结论**：本 skill 的未验证项里，只有最后一条会真正导致误判，且已有明确的分流规则；其余三条是"知道了更好、不知道不影响结论"的认知空白。

### 2.2 编译体反编译边界（2026-11-22 实测）

`BuiltLibraryFile` 的 `Controller` 载荷不是只能看符号——它可以进一步反汇编/反编译，但边界要说清：

- 17 POU「没有源代码的库」+禁显工程：17/17 Controller ELF64（ET_DYN / x86-64，无 DWARF）反汇编成功，规模 47～7 492 指令；产物是 `.asm.txt` 与结构化统计。
- 调用名从 `.dynsym` / `.rela.plt` / `.plt` 解析；常量从 `.rodata` 按 RIP 相对引用回算；变量名从同一目标文件内明文 SLWD 取；变量访问呈 9 字节描述符步进（`desc[k]=base+9*k`）。
- 反编译结果分层：**8 FULL / 8 PARTIAL / 1 SKELETON**。小 Function 可完整恢复控制流；大型 FB（如 `FB_AxisObject` 7 492 指令 / 335 calls / 1 417 jumps）只能到状态机/调用序列骨架。
- **不能恢复原 ST 源码**：没有源码文本、没有局部变量名、没有枚举名；伪代码只能称"逻辑等价伪代码"（且只有用户另行提供原源码的个别函数做过等价对照）。
- `Simulator` PE 本轮未反汇编；不要把它当作已覆盖。
- 如果目标只是"看/拿源码"，这条路线**不满足**；它只适合验证防护强度、恢复接口/调用图/逻辑骨架。若工程里已有 `BuiltLibraryFile`，无需为了拿编译码再跑一次 UI 编译。
- **伪代码不能"装回去"（2026-11-22 实测，已判不可用）**：把 17 个 POU 的伪代码以注释形式重建为源可见工程，结构侧全过（17 `StructuredTextModel` / 0 `BuiltLibraryFile` / holder 17/17），但 **17/17 POU 体只有 `;`、0 条可执行语句**，运行起来什么都不做，用户判定「重构的不行」。**结论：反编译伪代码只能作人工重写参考底稿，不能经重建工程变成可运行程序。** 看到"结构校验全绿"不要以为程序回来了——那只是容器对了。

**入口纪律（别自己数标签）**：拿到 `.slr`/`.smc2` 先跑
`python <sysmac-sourceless-lib-decrypt>/scripts/smx_decrypt.py <路径>` 判型，再决定要不要进本 skill。
原因：`<EncryptedFile>` 在实体 XML 里是 HTML 转义的，直接对原始 XML 计数会得 **0**，
把「常规库+禁显」误判成「无加密源码」——这正是本 skill 与 decrypt 的分岔口，判错就整条路线跑偏。
该脚本同时打印 raw / unescaped 双计数，两个数不一致即报警。

## 3. 版本记录

| 版本 | 日期 | 内容 |
| --- | --- | --- |
| 0.3.3 | 2026-11-22 | **文档更正：`BuiltLibraryFile` 的 `Controller` ELF 类型 ET_REL → `ET_DYN`**。实测 7 POU `.slr` 与 17 POU 工程解出的载荷均为 `e_type=0x03`（共享对象布局），原记 ET_REL 有误。仅改文档，脚本与结论不变 |
| 0.3.2 | 2026-11-22 | **§2.2 补一条反向边界：伪代码不能"装回去"**。实测把 17 个 POU 伪代码以注释形式重建为源可见工程，结构侧全过但 **17/17 体只有 `;`、0 条可执行语句**，运行什么都不做，用户判定「重构的不行」⇒ 反编译伪代码只能作人工重写参考底稿，不能经重建工程变成可运行程序。description 与 `tested_against` 同步 |
| 0.3.1 | 2026-11-22 | 回填 17 POU NO_SOURCE 工程的 Controller ELF64 反编译边界：17/17 反汇编成功（47～7 492 指令），8 FULL / 8 PARTIAL / 1 SKELETON；`.dynsym`/`.rela.plt` 解析调用、`.rodata` 读常量、SLWD 取变量名；**不能恢复原 ST**，Simulator PE 未反汇编。新增 §2.2 明确"看源码"与"看骨架"的分流 |
| 0.3.0 | 2026-11-21 | **通用化（换机/换版本可用）**：① 新增 **§0.1「版本适用性」**——写明实测版本 `1.68.0.64010` / Windows 11，给出「同 build / 同 minor / 跨 minor」三档处理与最小复核清单，并说明 `PRODUCER` 行怎么读；② 脚本加 `VERIFIED_VERSION` 与 `VERSION:` 警告（版本不符只提示不阻断）；③ 入口纪律由外部 `ss_libtype.py` 改指 `sysmac-sourceless-lib-decrypt` 自带的 `smx_decrypt.py`；④ 清理文档里残留的内部任务编号与本机路径，恢复被过度脱敏的实测值（hex 族头部 `41ec832f`） |
| 0.2.0 | 2026-11-21 | **可移植性修复（2026-11-21）**：① 新增 `scripts/smx_capture_offline.py`（1.0.0，纯 stdlib）——`diff`（GUID 归一化，只报构建实体）/ `extract`（解内嵌编译 zip + 按 §1 表分类）/ `map`（库 `.oem` trackingId ↔ `UserLib_*.cxif2`）/ `analyze`（三合一 + OVERALL 判据）/ `--selftest`；实测 T15 捕获副本：76 成员、`UserLib`=7、`LV`=8、**7/7 命中无缺无余**，与 T15 记录一致；② 新增 §0.0「依赖与环境」，把 UI 段（需 `sysmac-studio-control` + 提权）与离线段（纯 stdlib）分开写清；③ 第 5/6/7 步各加一条命令指引；④ 版本表按 semver 重排 |
| 0.1.5 | 2026-11-21 | 回填 T15/T16：① §2.1 成员分类行补 T15 实测（本工程 `UserLib_*.cxif2`=7、`LV_*.cxil2`=8，与 T9 同构）；② 新增「入口纪律」——判型统一走 `ss_libtype.py`，别自己数 `<EncryptedFile>`（HTML 转义会得 0，直接导致本 skill 与 decrypt 的分岔口判反）；③ 修正版本表行序 |
| 0.1.4 | 2026-11-21 | 新增 §2.1「未验证项与影响面」：把 hex 族格式、`.o`↔POU 映射、`Resource_UserTypes.cxip`、无源码库 DLL 路径四条按影响面分档，明确"不排期"的判定理由；并指出唯一会致误判的是"成员分类表只覆盖常规库+禁显"这一条（已有分流规则） |
| 0.1.3 | 2026-11-21 | 新增「什么时候根本不用跑本 skill」：有明文参照时直接转 rebuild 路径 c；并记入"内嵌库改外部引用后工程体积骤降属预期"（248 749→89 119 B）的完整性判据口径 |
| 0.1.2 | 2026-11-20 | 回填 审计方/T11 实测：「没有源代码的库」编译体内嵌于 BuiltLibraryFile（ELF64 Controller / PE Simulator / CX-IL holder），无需 UI 编译即可离线解析 |
| 0.1.1 | 2026-11-20 | 口径澄清：实测工程引用的是「常规库」+勾选「禁用源显示」的库；新增「没有源代码的库」类型构建路径未实测的形态边界 |
| 0.1.0 | 2026-11-20 | 首版：七步清单、编译证据判据、GUID 归一化 diff、两种四件套形态、成员分类、TrackingId 映射（两工程实测） |
