#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""smx_capture_offline.py —— Sysmac 编译产物捕获的**离线**部分（纯 stdlib，不开 UI）

UI 段（建副本 → 编译 → 原生保存）由 sysmac-studio-control 的 ss_build.py / ss_save.py 完成；
本脚本负责"保存之后"的全部可复跑分析：

    python smx_capture_offline.py diff   <基线.smc2> <捕获.smc2>
    python smx_capture_offline.py extract <捕获.smc2> -o <目录>
    python smx_capture_offline.py map    <捕获.smc2> <库.slr>
    python smx_capture_offline.py analyze <基线.smc2> <捕获.smc2> <库.slr> -o <目录>
    python smx_capture_offline.py --selftest

三个关键判据（错了会得出相反结论）:
  1. **保存会轮换 .oem 顶层 GUID**，直接比 namelist 会得到"全增全删"假象。
     必须先把条目名做 GUID 归一化再比。
  2. **构建四件套有两种形态**：普通工程是"新增"；库引用工程是基线里已以空实体存在、
     编译后被**原位重写**（0 新增、若干条目大小变化）。只看"新增"会漏判成"没编译"。
  3. **内嵌 zip 成员的 <32hex> 名就是 TrackingId 的无连字符形式**，
     与库 `.slr` 的 `.oem` 里 Entity 的 trackingId 对应 —— 这是"库 POU 是否整体参与编译"的直接证据。

作者: hoverwu ｜ 版本: 1.0.0 ｜ 仅限自有工程与授权审计
"""
import sys, os, io, re, json, html, zipfile, hashlib, argparse

GUID_RE = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}'
                     r'-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')
BUILD_PAT = re.compile(r'NexBuildResults|NexBuildVerifierGroup|NexTransferInformation'
                       r'|ValidationResults|\.zip$|\.manifest$')
POU_TYPES = ('Function', 'FunctionBlock', 'Program', 'SubProgram', 'FunctionBlockInstance')

# 本 skill 全部结论只在这个版本上验证过。换版本先看 SKILL.md「版本适用性」。
VERIFIED_VERSION = '1.68.0.64010'


def producer_of(zf):
    """归档里记录的生成版本（LibraryModel/ApplicationProductVersion）。"""
    for n in zf.namelist():
        if not n.lower().endswith(('.xml', '.oem')):
            continue
        try:
            t = html.unescape(zf.read(n).decode('utf-8-sig', errors='replace'))
        except Exception:
            continue
        m = re.search(r'<ApplicationProductVersion>([^<]*)</ApplicationProductVersion>', t)
        if m and m.group(1).strip():
            return m.group(1).strip()
    return None


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def norm_name(name):
    return GUID_RE.sub('<GUID>', name)


def open_zip(path):
    z = zipfile.ZipFile(path)
    return z, {i.filename: i.file_size for i in z.infolist()}


# ------------------------------------------------------------------ diff
def cmd_diff(base, cap):
    from collections import Counter
    za, ea = open_zip(base)
    zb, eb = open_zip(cap)
    na = {norm_name(k): v for k, v in ea.items()}
    nb = {norm_name(k): v for k, v in eb.items()}
    added = sorted(set(nb) - set(na))
    removed = sorted(set(na) - set(nb))
    changed = sorted(k for k in set(na) & set(nb) if na[k] != nb[k])
    real_added = [f for f in eb if norm_name(f) in set(added)]
    real_changed = [f for f in eb if norm_name(f) in set(changed)]
    # 归一化后同名的条目（GUID 轮换后新旧并存）——字典会丢掉一个，必须报出来
    dup = sorted(k for k, v in Counter(norm_name(f) for f in eb).items() if v > 1)
    return {'base': base, 'captured': cap, 'producer': producer_of(zb),
            'verified_version': VERIFIED_VERSION,
            'testzip': zb.testzip(),
            'entries': [len(ea), len(eb)],
            'added': added, 'removed': removed, 'changed': changed,
            'added_real': real_added, 'changed_real': real_changed,
            'dup_normalized': dup,
            'build_added': [f for f in real_added if BUILD_PAT.search(f)],
            'build_changed': [f for f in real_changed if BUILD_PAT.search(f)]}


# --------------------------------------------------------------- extract
def classify(member):
    b = os.path.basename(member)
    if re.match(r'LV_[0-9a-fA-F]{32}\.cxil2$', b):
        return 'LV_*.cxil2  CX IL 接口（明文）'
    if re.match(r'UserLib_[0-9a-fA-F]{32}\.cxif2$', b):
        return 'UserLib_*.cxif2  编译接口声明（明文，实现体标隐藏）'
    if re.search(r'(Program|SubProgram)_[0-9a-fA-F]+_N\.o$', b) or \
       re.match(r'Signature_[0-9a-fA-F]+\.o$', b):
        return 'ELF 目标码 .o'
    if b == 'Resource_UserTypes.cxip':
        return 'Resource_UserTypes.cxip  用户数据类型资源'
    if re.match(r'^[0-9a-fA-F]{8,}(\.[A-Za-z0-9]+)?$', b):
        return 'hex 名私有格式（记头部，不当结论）'
    return '其它'


def cmd_extract(cap, outdir):
    z, e = open_zip(cap)
    os.makedirs(outdir, exist_ok=True)
    cand = [f for f in e if f.lower().endswith('.zip')]
    # 内嵌编译 zip：优先名字里带 zip 且能被 ZipFile 打开、成员多的
    best, best_n = None, -1
    for f in cand:
        try:
            inner = zipfile.ZipFile(io.BytesIO(z.read(f)))
            n = len(inner.namelist())
        except Exception:
            continue
        if n > best_n:
            best, best_n = f, n
    rep = {'captured': cap, 'inner_zip': best, 'members': best_n, 'classes': {},
           'pous': [], 'extracted_to': None}
    if not best:
        return rep
    inner = zipfile.ZipFile(io.BytesIO(z.read(best)))
    sub = os.path.join(outdir, 'inner')
    os.makedirs(sub, exist_ok=True)
    inner.extractall(sub)
    rep['extracted_to'] = sub
    hist = {}
    for m in inner.namelist():
        c = classify(m)
        hist[c] = hist.get(c, 0) + 1
        mm = re.match(r'(UserLib|LV)_([0-9a-fA-F]{32})\.(cxif2|cxil2)$', os.path.basename(m))
        if mm:
            rep['pous'].append({'kind': mm.group(1), 'tracking32': mm.group(2).lower(),
                                'member': m, 'size': inner.getinfo(m).file_size})
    rep['classes'] = hist
    # NexBuildResults 原文落盘（判"是否真编译过"的原始证据）
    for f in e:
        if 'NexBuildResults' in f:
            dst = os.path.join(outdir, 'NexBuildResults.xml')
            with open(dst, 'wb') as fh:
                fh.write(z.read(f))
            rep['nex_build_results'] = dst
            break
    return rep


# -------------------------------------------------------------------- map
def lib_tracking(lib):
    """从 .slr 的 .oem 读 Entity(type,name,trackingId)。"""
    z, e = open_zip(lib)
    rows = []
    for n in e:
        if not n.lower().endswith('.oem'):
            continue
        t = z.read(n).decode('utf-8-sig', errors='replace')
        for m in re.finditer(r'<Entity ([^>]*?)/?>', t):
            a = m.group(1)
            typ = re.search(r'type="([^"]*)"', a)
            nm = re.search(r'name="([^"]*)"', a)
            tid = re.search(r'trackingId="([^"]*)"', a)
            if typ and tid and typ.group(1) in POU_TYPES:
                rows.append({'type': typ.group(1), 'name': (nm.group(1) if nm else ''),
                             'trackingId': tid.group(1)})
    return rows


def cmd_map(cap, lib):
    ext = cmd_extract(cap, os.path.join(os.path.dirname(os.path.abspath(cap)),
                                        '_smx_map'))
    found = {p['tracking32'] for p in ext['pous'] if p['kind'] == 'UserLib'}
    rows = lib_tracking(lib)
    for r in rows:
        r['tracking32'] = r['trackingId'].replace('-', '').lower()
        r['in_build'] = r['tracking32'] in found
    missing = sorted(found - {r['tracking32'] for r in rows})
    return {'captured': cap, 'library': lib, 'pous': rows,
            'userlib_in_zip': len(found), 'matched': sum(r['in_build'] for r in rows),
            'unmatched_in_zip': missing,
            'verdict': 'PASS' if rows and all(r['in_build'] for r in rows)
                       and not missing else 'FAIL'}


# ----------------------------------------------------------------- print
def print_diff(r):
    print('DIFF  %s\n   vs %s' % (r['captured'], r['base']))
    pv = r.get('producer') or '(未记录)'
    print('  PRODUCER Sysmac Studio %s%s' % (
        pv, '' if pv == r.get('verified_version') else '  ← 与已验证版本不同，成员分类可能变'))
    print('  条目 %d → %d   testzip=%s' % (r['entries'][0], r['entries'][1], r['testzip']))
    print('  归一化后：新增 %d  删除 %d  大小变化 %d' % (
        len(r['added']), len(r['removed']), len(r['changed'])))
    for n in r['build_added']:
        print('  + %s' % n)
    for n in r['build_changed']:
        print('  ~ %s' % n)
    if not r['build_added'] and not r['build_changed']:
        print('  ! 没有构建实体变化 —— 编译可能没发生（或没保存），判 INCONCLUSIVE')
    if r.get('dup_normalized'):
        print('  ! 归一化后同名条目 %d 组（GUID 轮换后新旧并存），'
              '大小比较按后者为准：%s' % (len(r['dup_normalized']),
                                          r['dup_normalized'][:3]))


def print_extract(r):
    print('EXTRACT %s' % r['captured'])
    if not r['inner_zip']:
        print('  ! 未找到可打开的内嵌编译 zip')
        return
    print('  内嵌 zip %s  成员 %d' % (r['inner_zip'], r['members']))
    print('  解出到 %s' % r['extracted_to'])
    for k, v in sorted(r['classes'].items(), key=lambda x: -x[1]):
        print('    %-58s %d' % (k, v))


def print_map(r):
    print('MAP   %s\n  库 %s' % (r['captured'], r['library']))
    print('  %-16s %-22s %-10s %s' % ('TYPE', 'NAME', 'TRACKING', 'IN_BUILD'))
    for p in r['pous']:
        print('  %-16s %-22s %-10s %s' % (p['type'], p['name'],
                                          p['tracking32'][:8],
                                          'YES' if p['in_build'] else 'no'))
    print('  内嵌 zip 里 UserLib_* = %d；库 POU = %d；命中 %d' % (
        r['userlib_in_zip'], len(r['pous']), r['matched']))
    if r['unmatched_in_zip']:
        print('  ! zip 里多出的 tracking: %s' % r['unmatched_in_zip'])
    print('VERDICT %s' % r['verdict'])


# -------------------------------------------------------------- selftest
def selftest():
    import tempfile
    ok = True
    tmp = tempfile.mkdtemp(prefix='smxcap_')
    try:
        g1 = '11111111-2222-3333-4444-555555555555'
        g2 = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'
        inner = io.BytesIO()
        with zipfile.ZipFile(inner, 'w') as z:
            z.writestr('UserLib_%s.cxif2' % ('deadbeef' * 4),
                       'FUNCTION_BLOCK {a<_n_o_t_d_i_v_i_d_e_d_!_>} X')
            z.writestr('LV_%s.cxil2' % ('deadbeef' * 4), '{IMPORT} MODULE NX')
        base = os.path.join(tmp, 'base.smc2')
        with zipfile.ZipFile(base, 'w') as z:
            z.writestr('%s/%s.oem' % (g1, g1), '<x/>')
            z.writestr('%s/%s.zip' % (g1, g1), b'')
            z.writestr('%s/%s.NexBuildResults' % (g1, g1), '<empty/>')
        cap = os.path.join(tmp, 'cap.smc2')
        with zipfile.ZipFile(cap, 'w') as z:
            z.writestr('%s/%s.oem' % (g2, g2), '<x/>')          # GUID 轮换
            z.writestr('%s/%s.zip' % (g2, g2), inner.getvalue())  # 原位重写
            z.writestr('%s/%s.NexBuildResults' % (g2, g2), '<r HasResult="true"/>')
        d = cmd_diff(base, cap)
        good = (d['added'] == [] and len(d['build_changed']) == 2)
        print('%s guid-normalized-diff  新增=%d 构建实体变化=%d' % (
            'PASS' if good else 'FAIL', len(d['added']), len(d['build_changed'])))
        ok = ok and good

        e = cmd_extract(cap, os.path.join(tmp, 'out'))
        good = e['members'] == 2 and len(e['pous']) == 2
        print('%s extract  成员=%d POUs=%d' % ('PASS' if good else 'FAIL',
                                               e['members'], len(e['pous'])))
        ok = ok and good

        lib = os.path.join(tmp, 'lib.slr')
        with zipfile.ZipFile(lib, 'w') as z:
            z.writestr('r/r.oem',
                       '<sysmac><Entity type="FunctionBlock" name="FB_X" '
                       'trackingId="deadbeef-dead-beef-dead-beefdeadbeef"/></sysmac>')
        m = cmd_map(cap, lib)
        good = m['verdict'] == 'PASS' and m['matched'] == 1
        print('%s map  matched=%d verdict=%s' % ('PASS' if good else 'FAIL',
                                                 m['matched'], m['verdict']))
        ok = ok and good
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nSELFTEST %s' % ('PASS' if ok else 'FAIL'))
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('cmd', nargs='?', choices=['diff', 'extract', 'map', 'analyze'])
    ap.add_argument('args', nargs='*')
    ap.add_argument('-o', '--out')
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if a.cmd == 'diff':
        r = cmd_diff(a.args[0], a.args[1])
        print(json.dumps(r, ensure_ascii=False, indent=1)) if a.json else print_diff(r)
        return 0
    if a.cmd == 'extract':
        r = cmd_extract(a.args[0], a.out or '_capture')
        print(json.dumps(r, ensure_ascii=False, indent=1)) if a.json else print_extract(r)
        return 0
    if a.cmd == 'map':
        r = cmd_map(a.args[0], a.args[1])
        print(json.dumps(r, ensure_ascii=False, indent=1)) if a.json else print_map(r)
        return 0 if r['verdict'] == 'PASS' else 1
    if a.cmd == 'analyze':
        base, cap, lib = a.args[0], a.args[1], a.args[2]
        out = a.out or '_capture'
        d = cmd_diff(base, cap)
        e = cmd_extract(cap, out)
        m = cmd_map(cap, lib)
        if a.json:
            print(json.dumps({'diff': d, 'extract': e, 'map': m},
                             ensure_ascii=False, indent=1))
        else:
            print_diff(d)
            print()
            print_extract(e)
            print()
            print_map(m)
        ok = bool(d['build_added'] or d['build_changed']) and m['verdict'] == 'PASS'
        print('\nOVERALL %s' % ('PASS' if ok else 'INCONCLUSIVE/FAIL'))
        return 0 if ok else 1
    ap.print_help()
    return 2


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    raise SystemExit(main())
