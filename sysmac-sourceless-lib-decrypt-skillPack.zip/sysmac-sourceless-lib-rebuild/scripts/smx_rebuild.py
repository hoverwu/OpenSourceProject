#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""smx_rebuild.py —— Sysmac 无源库重建（路径 b 改旗标 / 结构校验）

用法:
    python smx_rebuild.py flag <源.slr> [-o <产物.slr>]     # 路径 b：IsDisableSourceDisplay true→false
    python smx_rebuild.py check <源> <产物>                  # 结构校验（改完必跑）
    python smx_rebuild.py --selftest

三条纪律（踩过的坑）:
  1. **字节级替换**，不要 decode→改→encode：实体 XML 可能带 UTF-8 BOM、可能 CRLF，
     重新编码会改字节，导致"只有旗标变了"这条判据失效。用 bytes.replace 就地改。
  2. **按原 compress_type / 顺序 / date_time / external_attr 重写 ZIP**，否则 Sysmac 侧
     可能不接受，或条目元数据全变、diff 判据失效。
  3. **ZIP64 保护性判据**：条目 >60000 或单文件 >2GB 直接拒绝（本流程未验证 ZIP64 重写）。

路径 b 的产物性质（务必说清）：密文与 lock **原样保留**，只是允许显示。
  → 自己能看；分发出去等于公开源码（对方按 decrypt 配方即可解）。
  → 要真正"去加密"必须做明文装配，那是另一条路（本脚本不提供，见 SKILL.md §2b 的边界说明）。

作者: hoverwu ｜ 版本: 1.0.0 ｜ 仅限自有库与已授权审计
"""
import sys, os, re, html, json, shutil, zipfile, hashlib, argparse

OLD = b'<IsDisableSourceDisplay>true</IsDisableSourceDisplay>'
NEW = b'<IsDisableSourceDisplay>false</IsDisableSourceDisplay>'
LIMIT_ENTRIES = 60000
LIMIT_BYTES = 2 * 1024 ** 3

# 本 skill 全部结论只在这个版本上验证过。换版本先看 SKILL.md「版本适用性」。
VERIFIED_VERSION = '1.68.0.64010'


def producer_of(zf):
    """归档里记录的生成版本（LibraryModel/ApplicationProductVersion）。"""
    for n in zf.namelist():
        if not n.lower().endswith(('.xml', '.oem')):
            continue
        try:
            t = html.unescape(zf.read(n).decode('utf-8-sig', errors='replace'))
        except Exception:
            continue
        m = re.search(r'<ApplicationProductVersion>([^<]*)</ApplicationProductVersion>', t)
        if m and m.group(1).strip():
            return m.group(1).strip()
    return None


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()


def _payload(src):
    with zipfile.ZipFile(src) as z:
        return z.infolist(), [(i, z.read(i.filename)) for i in z.infolist()]


def _guard(infos):
    n = len(infos)
    big = max((i.file_size for i in infos), default=0)
    if n > LIMIT_ENTRIES or big > LIMIT_BYTES:
        raise SystemExit('拒绝重建：条目数=%d / 单文件=%.2f GB，已进入 ZIP64 区；'
                         '本流程未验证 ZIP64 重写' % (n, big / 1024 ** 3))


def cmd_flag(src, dst, force=False):
    src = os.path.abspath(src)
    dst = os.path.abspath(dst or (os.path.splitext(src)[0] + '_重建.slr'))
    if src == dst:
        raise SystemExit('产物不能覆盖源文件（原件只读）')
    infos, payload = _payload(src)
    _guard(infos)

    hits = [(i.filename, data.count(OLD)) for i, data in payload if OLD in data]
    if not hits:
        # 可能已经是 false，或用了属性形式
        alt = [(i.filename, data.count(b'IsDisableSourceDisplay="true"'))
               for i, data in payload if b'IsDisableSourceDisplay="true"' in data]
        if alt:
            raise SystemExit('发现属性形式 IsDisableSourceDisplay="true"（%s），'
                             '本脚本只处理元素文本形式，请人工确认' % alt)
        raise SystemExit('未找到 %s —— 该库可能已是源可见，或旗标形式不同'
                         % OLD.decode())
    if len(hits) > 1:
        raise SystemExit('多个条目命中旗标：%s —— 需人工确认哪个是根实体' % hits)

    with zipfile.ZipFile(dst, 'w') as out:
        for i, data in payload:
            if OLD in data:
                data = data.replace(OLD, NEW)
            zi = zipfile.ZipInfo(i.filename, date_time=i.date_time)
            zi.compress_type = i.compress_type
            zi.external_attr = i.external_attr
            zi.internal_attr = i.internal_attr
            zi.create_system = i.create_system
            out.writestr(zi, data)

    rep = cmd_check(src, dst, quiet=True)
    rep.update({'mode': 'flag', 'src': src, 'dst': dst,
                'src_size': os.path.getsize(src), 'dst_size': os.path.getsize(dst),
                'src_sha256': sha256(src), 'dst_sha256': sha256(dst),
                'patched_entries': [h[0] for h in hits]})
    _print_report(rep)
    return 0 if rep['verdict'] == 'PASS' else 1


def cmd_check(src, dst, quiet=False):
    import xml.etree.ElementTree as ET
    src, dst = os.path.abspath(src), os.path.abspath(dst)
    with zipfile.ZipFile(src) as a, zipfile.ZipFile(dst) as b:
        na, nb = a.namelist(), b.namelist()
        producer = producer_of(a)
        changed = [n for n in na if n in nb and a.read(n) != b.read(n)]
        added = [n for n in nb if n not in na]
        removed = [n for n in na if n not in nb]
        bad = b.testzip()
        xml_bad = []
        for n in changed:
            if n.lower().endswith('.xml'):
                try:
                    ET.fromstring(b.read(n).decode('utf-8-sig'))
                except Exception as e:
                    xml_bad.append('%s: %s' % (n, e))
        flag_after = {}
        for n in changed:
            t = html.unescape(b.read(n).decode('utf-8-sig', errors='replace'))
            m = re.search(r'<IsDisableSourceDisplay>(.*?)</IsDisableSourceDisplay>', t)
            if m:
                flag_after[n] = m.group(1)
        enc = sum(html.unescape(b.read(n).decode('utf-8-sig', errors='replace'))
                  .count('<EncryptedFile>') for n in nb if n.lower().endswith('.xml'))

    problems = []
    if bad:
        problems.append('testzip 坏条目: %s' % bad)
    if len(na) != len(nb):
        problems.append('条目数 %d → %d' % (len(na), len(nb)))
    if added or removed:
        problems.append('新增 %d / 删除 %d 条目' % (len(added), len(removed)))
    if xml_bad:
        problems.append('XML 不良构: %s' % xml_bad)
    if any(v != 'false' for v in flag_after.values()):
        problems.append('旗标未翻成 false: %s' % flag_after)
    if not changed:
        problems.append('没有任何条目变化（旗标没改到？）')

    # 版本只告警，不判 FAIL：结构校验本身仍有效，但结论不能外推到别的版本
    warnings = []
    if producer and producer != VERIFIED_VERSION:
        warnings.append('VERSION: 归档由 Sysmac Studio %s 生成，本 skill 只在 %s 上验证过 —— '
                        '结构判据可能不适用，结论需重新实测' % (producer, VERIFIED_VERSION))
    elif not producer:
        warnings.append('VERSION: 未读到 ApplicationProductVersion，无法确认生成版本'
                        '（本 skill 只验证过 %s）' % VERIFIED_VERSION)

    rep = {'mode': 'check', 'src': src, 'dst': dst, 'producer': producer,
           'verified_version': VERIFIED_VERSION, 'warnings': warnings,
           'entries': [len(na), len(nb)], 'changed': changed,
           'added': added, 'removed': removed,
           'flag_after': flag_after, 'encrypted_file_after': enc,
           'verdict': 'PASS' if not problems else 'FAIL', 'problems': problems}
    if not quiet:
        _print_report(rep)
    return rep


def _print_report(r):
    pv = r.get('producer') or '(未记录)'
    mark = '' if pv == r.get('verified_version') else '  ← 与已验证版本不同'
    print('PRODUCER Sysmac Studio %s%s' % (pv, mark))
    if r['mode'] == 'flag':
        print('SRC   %s\n      %s B  %s' % (r['src'], format(r['src_size'], ','),
                                            r['src_sha256'][:16] + '…'))
        print('DST   %s\n      %s B  %s' % (r['dst'], format(r['dst_size'], ','),
                                            r['dst_sha256'][:16] + '…'))
        print('PATCH %s' % (r['patched_entries'],))
        print('      IsDisableSourceDisplay → %s' % r['flag_after'])
        print('NOTE  密文与 lock 原样保留（%d 个 EncryptedFile）—— '
              '能看，但分发即公开源码' % r['encrypted_file_after'])
    else:
        print('CHECK %s\n   vs %s' % (r['dst'], r['src']))
        print('  条目  %d → %d   变化 %d   新增 %d   删除 %d' % (
            r['entries'][0], r['entries'][1], len(r['changed']),
            len(r['added']), len(r['removed'])))
        for n in r['changed']:
            print('   ~ %s' % n)
        if r['flag_after']:
            print('  旗标  %s' % r['flag_after'])
        print('  密文  %d 个 EncryptedFile' % r['encrypted_file_after'])
    print('VERDICT %s' % r['verdict'])
    for p in r.get('problems', []):
        print('  ! %s' % p)
    for w in r.get('warnings', []):
        print('  WARN %s' % w)


def selftest():
    """用临时 ZIP 造三个夹具：正常改旗标 / 已改过 / 属性形式。"""
    import tempfile
    ok = True
    tmp = tempfile.mkdtemp(prefix='smxrb_')
    try:
        root = ('<data><data><LibraryModel><Name>X</Name>'
                '<IsSource>true</IsSource>' + OLD.decode() +
                '</LibraryModel></data></data>')
        src = os.path.join(tmp, 'a.slr')
        with zipfile.ZipFile(src, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr('root/root.xml', root)
            z.writestr('root/other.xml', '<x>untouched</x>')
        dst = os.path.join(tmp, 'b.slr')
        r = cmd_flag(src, dst) if False else None
        # 直接调用内部逻辑，避免打印
        infos, payload = _payload(src)
        assert any(OLD in d for _, d in payload)
        with zipfile.ZipFile(dst, 'w') as out:
            for i, data in payload:
                if OLD in data:
                    data = data.replace(OLD, NEW)
                zi = zipfile.ZipInfo(i.filename, date_time=i.date_time)
                zi.compress_type = i.compress_type
                out.writestr(zi, data)
        rep = cmd_check(src, dst, quiet=True)
        good = rep['verdict'] == 'PASS' and rep['changed'] == ['root/root.xml'] \
            and rep['flag_after'].get('root/root.xml') == 'false'
        print('%s flag+check  变化条目=%s 旗标=%s' % (
            'PASS' if good else 'FAIL', rep['changed'], rep['flag_after']))
        ok = ok and good

        # 已经改过 → 应报错
        try:
            cmd_flag(dst, os.path.join(tmp, 'c.slr'))
            print('FAIL idempotent-guard  已改过的库应报错却通过了')
            ok = False
        except SystemExit as e:
            print('PASS idempotent-guard  %s' % e)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nSELFTEST %s' % ('PASS' if ok else 'FAIL'))
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('cmd', nargs='?', choices=['flag', 'check'])
    ap.add_argument('src', nargs='?')
    ap.add_argument('dst', nargs='?')
    ap.add_argument('-o', '--out')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if a.cmd == 'flag':
        return cmd_flag(a.src, a.out or a.dst)
    if a.cmd == 'check':
        if not a.dst:
            raise SystemExit('check 需要两个参数：check <源> <产物>')
        return 0 if cmd_check(a.src, a.dst)['verdict'] == 'PASS' else 1
    ap.print_help()
    return 2


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    raise SystemExit(main())
