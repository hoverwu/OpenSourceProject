#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""smx_ui.py —— Sysmac Studio 的通用 UI 入口（Windows / 需管理员）

这个脚本只解决"环境"部分：启动、等加载、读状态、保存、关闭、版本探测；
复杂的 UIA 操作转发给同目录 `ui/` 下的已验证实现（ss.py / ss_libref.py / ss_libsrc.py / ss_build.py）。

**不含任何本机路径、项目名、pid**：Sysmac 位置靠"运行中进程 → 注册表 App Paths/卸载列表 → --exe"，
工程路径一律由参数传入；版本读 exe 的文件版本资源，与 VERIFIED_VERSION 比对后给出提示。

  smx_ui.py version                      打印"已验证版本 vs 本机安装版本"（不需要 Sysmac 在运行）
  smx_ui.py detect                       列出运行中的 Sysmac 实例（pid/hwnd/标题/版本）
  smx_ui.py open <工程.smc2> [--exe P] [--timeout 300]
  smx_ui.py state [pid]
  smx_ui.py lib-list <工程.smc2>         离线列出工程引用的库（不需要 Sysmac）
  smx_ui.py lib-open                     [转发] 工程(P)>库(L)>显示索引(S)
  smx_ui.py lib-replace <新库.slr> [--row N]   [转发] 删旧行 + 加新库 + 消警告
  smx_ui.py src-toolbox                  [转发] 工具箱里列库分组与 POU（自动展开）
  smx_ui.py src-goto <x> <y>             [转发] 右键 FB 实例 → 转到下层 → 导出全文
  smx_ui.py src-text [--title P]         [转发] 导出所有 SyntaxEditor 全文
  smx_ui.py build [--out F]              [转发] 编译控制器 + 读消息面板
  smx_ui.py save --file <工程.smc2>      文件(F)>保存(S) + sha256 前后对比
  smx_ui.py close [--save]               关闭（默认丢弃未保存改动）
  smx_ui.py portability                  扫描三个 skill 目录，检查是否混入本机痕迹
  smx_ui.py --selftest                   不启动 Sysmac 的静态自检

为什么 UI 段必须提权：Sysmac Studio 以 High 完整性级别运行，Medium 进程连它的 UIA 子树都读不到（UIPI）。
请从"以管理员身份运行"的终端里执行；脚本检测到非管理员会直接退出并提示。

作者：hoverwu ｜ 版本：1.1.0 ｜ 仅限自有工程与授权审计
"""
import sys, os, re, io, time, json, ctypes, ctypes.wintypes as wt, subprocess, hashlib, zipfile, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
UI = os.path.join(HERE, 'ui')
sys.path.insert(0, UI)

# 本 skill 全部 UI 结论只在这个版本上验证过。换版本先看 SKILL.md「版本适用性」。
VERIFIED_VERSION = '1.68.0.64010'
VERIFIED_FAMILY = '1.68'

NO_UI_CMDS = {'version', 'detect', 'lib-list', 'portability', 'selftest'}
WM_CLOSE = 0x0010


# ------------------------------------------------------------------ 基础
def _admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _ss():
    try:
        import ss
        return ss
    except ImportError as e:
        raise SystemExit('缺少依赖：%s\n  pip install uiautomation pillow' % e)


def sha(path):
    try:
        with open(path, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception:
        return None


def zip_ok(path):
    try:
        with zipfile.ZipFile(path) as z:
            return z.testzip() is None
    except Exception:
        return False


# ------------------------------------------------------- 版本探测（exe）
def exe_of_pid(pid):
    """运行中进程的可执行文件路径（不依赖安装位置）。"""
    k32 = ctypes.windll.kernel32
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
    if not h:
        return None
    try:
        buf = ctypes.create_unicode_buffer(1024)
        size = wt.DWORD(1024)
        if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return buf.value
        return None
    finally:
        k32.CloseHandle(h)


def file_version(path):
    """exe 的 FileVersion（如 1.68.0.64010）。纯 Win32 版本资源读取。"""
    if not path or not os.path.isfile(path):
        return None
    ver = ctypes.windll.version
    size = ver.GetFileVersionInfoSizeW(path, None)
    if not size:
        return None
    data = ctypes.create_string_buffer(size)
    if not ver.GetFileVersionInfoW(path, 0, size, data):
        return None
    ptr, ln = ctypes.c_void_p(), wt.UINT()
    if not ver.VerQueryValueW(data, '\\', ctypes.byref(ptr), ctypes.byref(ln)):
        return None
    # VS_FIXEDFILEINFO: dwSignature, dwStrucVersion, dwFileVersionMS, dwFileVersionLS ...
    vals = ctypes.cast(ptr, ctypes.POINTER(wt.DWORD))
    ms, ls = vals[2], vals[3]
    return '%d.%d.%d.%d' % (ms >> 16, ms & 0xFFFF, ls >> 16, ls & 0xFFFF)


def version_banner(local=None):
    ok = (local == VERIFIED_VERSION)
    print('VERIFIED  Sysmac Studio %s  (本 skill 只在这个版本上实测过)' % VERIFIED_VERSION)
    if local:
        print('LOCAL     Sysmac Studio %s%s' % (
            local, '' if ok else '   ← 与已验证版本不同'))
    else:
        print('LOCAL     (未读到文件版本)')
    if local and not ok:
        fam = '.'.join(local.split('.')[:2])
        if fam != VERIFIED_FAMILY:
            print('WARN      跨小版本（%s → %s）：UIA 控件树、菜单项名、实体 schema、'
                  '加密细节都可能变，**不要直接套用结论**，先按 SKILL.md「版本适用性」复核'
                  % (VERIFIED_FAMILY, fam))
        else:
            print('WARN      同一小版本内的不同 build：多数行为应一致，但 UIA 细节仍可能微调；'
                  '先跑 --selftest 与一次只读探测再下结论')
    return ok


# ------------------------------------------------------------ 通用小工具
def _main_title(ss, pid):
    hw = ss.main_hwnd(pid)
    if not hw:
        return None, ''
    for w in ss.wins_of(pid):
        if w['hwnd'] == hw:
            return hw, w['title']
    return hw, ''


def wait_loaded(ss, stem, timeout=300):
    """等工程真正加载：主窗口标题以工程文件名开头（Sysmac 用 .smc2 文件名当工程显示名）。"""
    t0 = time.time()
    last = ''
    while time.time() - t0 < timeout:
        for pid in list(ss.all_instances()):
            _, title = _main_title(ss, pid)
            if title:
                last = title
            if title.startswith(stem):
                return pid, title
        time.sleep(2)
    return None, last


def dismiss_esi(ss, pid):
    """ESI 核对框可能出现也可能不出现；出现就点 No（用本机 ESI 会污染实验）。"""
    for name in ('NoButton', 'No', '否(N)', 'いいえ'):
        c, _ = ss.find(pid, name)
        if c is None:
            continue
        for h in ('Invoke', 'Click'):
            fn = getattr(c, h, None)
            if fn:
                try:
                    fn()
                    print('ESI/对话框：已点击 %r' % name)
                    time.sleep(0.5)
                    return True
                except Exception:
                    pass
    return False


# ---------------------------------------------------------------- 命令
def installed_exe():
    """从注册表找已安装的 SysmacStudio.exe —— 不写死任何安装路径。

    先查 App Paths，再扫卸载列表的 DisplayIcon / InstallLocation。都没有就返回 None。
    """
    try:
        import winreg
    except ImportError:
        return None
    cands = []
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        try:
            k = winreg.OpenKey(hive, r'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\SysmacStudio.exe')
            try:
                v, _ = winreg.QueryValueEx(k, None)
                if v:
                    cands.append(os.path.expandvars(str(v).strip('"')))
            finally:
                winreg.CloseKey(k)
        except OSError:
            pass
        for sub in (r'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                    r'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'):
            try:
                root = winreg.OpenKey(hive, sub)
            except OSError:
                continue
            try:
                for i in range(winreg.QueryInfoKey(root)[0]):
                    try:
                        k = winreg.OpenKey(root, winreg.EnumKey(root, i))
                    except OSError:
                        continue
                    try:
                        try:
                            dn = str(winreg.QueryValueEx(k, 'DisplayName')[0])
                        except OSError:
                            continue
                        if 'sysmac' not in dn.lower():
                            continue
                        for val in ('DisplayIcon', 'InstallLocation'):
                            try:
                                p = str(winreg.QueryValueEx(k, val)[0])
                            except OSError:
                                continue
                            p = os.path.expandvars(p.strip('"').split(',')[0])
                            cands.append(p if p.lower().endswith('.exe')
                                         else os.path.join(p, 'SysmacStudio.exe'))
                    finally:
                        winreg.CloseKey(k)
            finally:
                winreg.CloseKey(root)
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return None


def cmd_version(a):
    running = None
    for pid in ss_all():
        exe = exe_of_pid(pid)
        if file_version(exe):
            running = (pid, exe, file_version(exe))
            break
    exe = running[1] if running else installed_exe()
    local = file_version(exe) if exe else None
    if running:
        print('RUNNING   pid=%s  %s' % (running[0], running[1]))
    if exe:
        print('EXE       %s' % exe)
    else:
        print('EXE       没找到（Sysmac 未运行，注册表也没登记）——请手动确认版本')
    version_banner(local)
    return 0


def ss_all():
    try:
        import ss
        return list(ss.all_instances())
    except Exception:
        return []


def cmd_detect(a):
    ss = _ss()
    inst = ss.all_instances()
    if not inst:
        print('NO SYSMAC  没有运行中的 Sysmac Studio 实例')
        print('提示：用 `open <工程>` 启动，或用 `--exe` 指定 SysmacStudio.exe 的完整路径')
        return 1
    local = None
    for pid in inst:
        hw, title = _main_title(ss, pid)
        exe = exe_of_pid(pid)
        v = file_version(exe)
        local = local or v
        print('pid=%-6d hwnd=%-10s ver=%-14s %s' % (pid, hw, v or '-', title))
    print()
    version_banner(local)
    return 0


def cmd_open(a):
    ss = _ss()
    project = os.path.abspath(a.project)
    if not os.path.isfile(project):
        raise SystemExit('找不到工程文件：%s' % project)
    stem = os.path.splitext(os.path.basename(project))[0]

    for pid in list(ss.all_instances()):
        _, title = _main_title(ss, pid)
        if title.startswith(stem):
            print('ALREADY OPEN  pid=%d  %s' % (pid, title))
            version_banner(file_version(exe_of_pid(pid)))
            return 0

    if a.exe:
        if not os.path.isfile(a.exe):
            raise SystemExit('--exe 指向的文件不存在：%s' % a.exe)
        print('launch: %s "%s"' % (a.exe, project))
        subprocess.Popen([a.exe, project])
    else:
        print('launch: 文件关联打开 %s' % project)
        os.startfile(project)

    pid, title = wait_loaded(ss, stem, a.timeout)
    if not pid:
        print('TIMEOUT  %ds 内没等到工程窗口（最后看到的标题：%r）' % (a.timeout, title))
        print('  排查：① Sysmac 是否真的起来了 ② 工程是否在报错 ③ 标题是否被别的工程占着')
        return 1
    print('LOADED   pid=%d  %s' % (pid, title))
    dismiss_esi(ss, pid)
    version_banner(file_version(exe_of_pid(pid)))
    return 0


def cmd_state(a):
    ss = _ss()
    pid = ss.resolve_pid(a.pid or 'auto')
    rc = ss.state(pid)
    version_banner(file_version(exe_of_pid(pid)))
    return rc


def cmd_lib_list(a):
    """离线读工程引用的库（不需要 Sysmac）。"""
    path = os.path.abspath(a.project)
    import html as _h
    rows = []
    with zipfile.ZipFile(path) as z:
        for n in z.namelist():
            if not n.lower().endswith('.xml'):
                continue
            t = _h.unescape(z.read(n).decode('utf-8-sig', errors='replace'))
            for m in re.finditer(r'<LibraryModel>(.*?)</LibraryModel>', t, re.S):
                blk = m.group(1)
                if 'BuildOption' in t[max(0, m.start() - 400):m.start()]:
                    continue
                def g(tag):
                    mm = re.search(r'<%s>([^<]*)</%s>' % (tag, tag), blk)
                    return mm.group(1).strip() if mm else ''
                if not g('LibraryId'):
                    continue
                rows.append({'entry': n, 'name': g('Name'), 'version': g('Version'),
                             'id': g('LibraryId'), 'path': g('LibraryFilePath'),
                             'source': g('IsSource'),
                             'hide': g('IsDisableSourceDisplay')})
    seen, uniq = set(), []
    for r in rows:
        k = (r['name'], r['version'], r['id'])
        if k in seen:
            continue
        seen.add(k)
        uniq.append(r)
    if not uniq:
        print('NO LIBRARY  工程里没有读到被引用的库')
        return 1
    for r in uniq:
        print('%-24s %-10s id=%s' % (r['name'] or '(无名)', r['version'] or '-', r['id']))
        print('   path  %s' % (r['path'] or '(空)'))
        print('   flags IsSource=%s  IsDisableSourceDisplay=%s' % (r['source'] or '-', r['hide'] or '-'))
    return 0


def _forward(script, args, out_default=None):
    """转发给 ui/ 下的已验证脚本，原样输出。"""
    _ss()
    exe = sys.executable
    cmd = [exe, os.path.join(UI, script)] + [str(x) for x in args]
    print('RUN %s %s' % (script, ' '.join(str(x) for x in args)))
    p = subprocess.run(cmd, capture_output=True, text=True,
                       encoding='utf-8', errors='replace')
    if p.stdout:
        print(p.stdout.rstrip())
    if p.stderr:
        print(p.stderr.rstrip())
    return p.returncode


def cmd_lib_open(a):
    ss = _ss()
    pid = ss.resolve_pid(a.pid or 'auto')
    return _forward('ss_libref.py', [pid, a.out or 'libref_open.txt', 'open'])


def cmd_lib_replace(a):
    ss = _ss()
    pid = ss.resolve_pid(a.pid or 'auto')
    args = [pid, a.out or 'libref_replace.txt', 'replace', os.path.abspath(a.slr)]
    if a.row:
        args.append('--row=%d' % a.row)
    return _forward('ss_libref.py', args)


def cmd_src_toolbox(a):
    ss = _ss()
    pid = ss.resolve_pid(a.pid or 'auto')
    return _forward('ss_libsrc.py', [pid, a.out or 'toolbox.txt', 'toolbox'])


def cmd_src_goto(a):
    ss = _ss()
    pid = ss.resolve_pid(a.pid or 'auto')
    args = [pid, a.out or 'goto.txt', 'goto', a.x, a.y]
    if a.title:
        args += ['--title', a.title]
    if a.st:
        args += ['--st', a.st]
    return _forward('ss_libsrc.py', args)


def cmd_src_text(a):
    ss = _ss()
    pid = ss.resolve_pid(a.pid or 'auto')
    args = [pid, a.out or 'text.txt', 'text']
    if a.title:
        args += ['--title', a.title]
    if a.st:
        args += ['--st', a.st]
    return _forward('ss_libsrc.py', args)


def cmd_build(a):
    ss = _ss()
    pid = ss.resolve_pid(a.pid or 'auto')
    return _forward('ss_build.py', ['run', pid, a.out or 'build.txt'])


def cmd_save(a):
    ss = _ss()
    path = os.path.abspath(a.file)
    before = sha(path)
    if not before:
        raise SystemExit('读不到目标文件（没有基线就无法验证保存）：%s' % path)
    pid = ss.resolve_pid(a.pid or 'auto')
    hw, title = _main_title(ss, pid)
    print('SAVE  pid=%d  %s' % (pid, title))
    print('  before sha256=%s' % before[:16])
    ss.force_foreground(hw)
    rc = ss.menu_item(pid, '文件(F)', '保存(S)', hw)
    if rc != 0:
        print('  菜单没走通（返回 %d）—— 检查是否有模态框挡住' % rc)
        return 1
    after = before
    for _ in range(a.timeout):
        time.sleep(1)
        after = sha(path)
        if after and after != before:
            break
    if after == before:
        print('  NO-CHANGE  文件哈希没变：要么没有改动，要么保存没落盘')
        print('  判据：NO-CHANGE 不等于失败，但**不能**当成"保存成功"的证据')
        return 0
    ok = zip_ok(path)
    print('  after  sha256=%s  zip_valid=%s' % (after[:16], ok))
    print('VERDICT %s' % ('PASS' if ok else 'FAIL（文件变了但不是有效归档）'))
    return 0 if ok else 1


def cmd_close(a):
    ss = _ss()
    if a.save and a.file:
        rc = cmd_save(argparse.Namespace(file=a.file, pid=a.pid, timeout=15))
        if rc != 0:
            print('保存未通过，仍继续关闭（改动可能丢失）')
    pid = ss.resolve_pid(a.pid or 'auto')
    hw, title = _main_title(ss, pid)
    print('CLOSE pid=%d  %s' % (pid, title))
    ctypes.windll.user32.PostMessageW(wt.HWND(hw), WM_CLOSE, 0, 0)
    t0 = time.time()
    while time.time() - t0 < a.timeout:
        if not ss.all_instances():
            print('  已退出')
            return 0
        # 保存确认框：标题=工程名，按钮 是(Y)/否(N)/取消
        for name in ('否(N)', 'No', 'NoButton'):
            c, _ = ss.find(pid, name)
            if c is not None:
                for h in ('Invoke', 'Click'):
                    fn = getattr(c, h, None)
                    if fn:
                        try:
                            fn()
                            print('  保存确认框：已选 %r（丢弃改动）' % name)
                            time.sleep(1)
                            break
                        except Exception:
                            pass
                break
        time.sleep(1)
    print('  TIMEOUT 进程还在（可能有别的模态框）')
    return 1


# ------------------------------------------------------------ 可移植性扫描
def cmd_portability(a):
    """扫三个 skill 目录，找"只对本机成立"的痕迹。"""
    root = os.path.abspath(a.root or os.path.join(HERE, '..', '..'))   # → Skills/
    pats = [
        ('绝对盘符路径', re.compile(r'[A-Za-z]:[\\/](?!\s*<)')),
        ('用户目录', re.compile(r'C:[\\/]Users[\\/]')),
        ('本机用户名占位', re.compile('h'+'over[\\\\/]')),
        ('内部 AgentID', re.compile('work'+'buddy-|qo'+'der-|open'+'code-')),
        ('本机项目名', re.compile('无源'+'库测试')),
        ('固定 pid 示例', re.compile(r'\bpid=\d{4,}')),
    ]
    me = os.path.abspath(__file__)
    hits, scanned = [], 0
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in ('__pycache__', '.git')]
        for fn in filenames:
            if not fn.endswith(('.py', '.md')):
                continue
            p = os.path.join(dirpath, fn)
            if os.path.abspath(p) == me:
                continue
            scanned += 1
            try:
                lines = io.open(p, encoding='utf-8', errors='replace').read().splitlines()
            except Exception:
                continue
            for i, line in enumerate(lines, 1):
                for label, rx in pats:
                    if rx.search(line):
                        hits.append((os.path.relpath(p, root), i, label, line.strip()[:100]))
    print('SCAN %s  （%d 个文件）' % (root, scanned))
    if not hits:
        print('PASS  没有发现本机痕迹')
        return 0
    for rel, i, label, line in hits:
        print('  %-52s:%-4d [%s] %s' % (rel, i, label, line))
    print('\nFAIL  %d 处需要清理' % len(hits))
    return 1


def selftest():
    ok = True
    print('VERIFIED_VERSION = %s' % VERIFIED_VERSION)
    # 1) 依赖可导入
    try:
        import ss
        print('PASS  import ui/ss.py  (%s)' % os.path.basename(ss.__file__))
    except Exception as e:
        print('FAIL  import ui/ss.py: %s' % e)
        ok = False
    # 2) 转发目标存在
    for f in ('ss.py', 'ss_libref.py', 'ss_libsrc.py', 'ss_build.py'):
        p = os.path.join(UI, f)
        good = os.path.isfile(p)
        ok = ok and good
        print('%s  ui/%s' % ('PASS' if good else 'FAIL', f))
    # 3) 版本比较逻辑
    cases = [('1.68.0.64010', True), ('1.68.0.70000', False), ('1.70.0.1', False)]
    for v, expect_same in cases:
        same = (v == VERIFIED_VERSION)
        good = (same == expect_same)
        ok = ok and good
        print('%s  version(%s) same=%s' % ('PASS' if good else 'FAIL', v, same))
    # 4) 参数解析：14 个子命令一个都不能少
    want = ('version', 'detect', 'open', 'state', 'lib-list', 'lib-open', 'lib-replace',
            'src-toolbox', 'src-goto', 'src-text', 'build', 'save', 'close', 'portability')
    miss = [c for c in want if c not in CMDS]
    ok = ok and not miss
    print('%s  %d 个子命令齐全%s' % ('PASS' if not miss else 'FAIL', len(want),
                                    '' if not miss else '（缺 %s）' % miss))
    print('\nSELFTEST %s' % ('PASS' if ok else 'FAIL'))
    return 0 if ok else 1


CMDS = {}


def main():
    ap = argparse.ArgumentParser(add_help=True)
    sub = ap.add_subparsers(dest='cmd')

    def add(name, fn, **kw):
        p = sub.add_parser(name)
        for k, v in kw.items():
            p.add_argument(k, **v)
        p.set_defaults(fn=fn)
        CMDS[name] = fn

    add('version', cmd_version)
    add('detect', cmd_detect)
    add('open', cmd_open, project={}, exe={'default': None},
        timeout={'type': int, 'default': 300})
    add('state', cmd_state, pid={'nargs': '?', 'default': None})
    add('lib-list', cmd_lib_list, project={})
    add('lib-open', cmd_lib_open, pid={'nargs': '?', 'default': None},
        out={'default': None})
    add('lib-replace', cmd_lib_replace, slr={}, pid={'nargs': '?', 'default': None},
        row={'type': int, 'default': 0}, out={'default': None})
    add('src-toolbox', cmd_src_toolbox, pid={'nargs': '?', 'default': None},
        out={'default': None})
    add('src-goto', cmd_src_goto, x={}, y={}, pid={'nargs': '?', 'default': None},
        title={'default': None}, st={'default': None}, out={'default': None})
    add('src-text', cmd_src_text, pid={'nargs': '?', 'default': None},
        title={'default': None}, st={'default': None}, out={'default': None})
    add('build', cmd_build, pid={'nargs': '?', 'default': None}, out={'default': None})
    add('save', cmd_save, file={}, pid={'nargs': '?', 'default': None},
        timeout={'type': int, 'default': 20})
    add('close', cmd_close, pid={'nargs': '?', 'default': None},
        save={'action': 'store_true'}, file={'default': None},
        timeout={'type': int, 'default': 25})
    add('portability', cmd_portability, root={'nargs': '?', 'default': None})

    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.cmd:
        ap.print_help()
        return 2

    if a.cmd not in NO_UI_CMDS and not _admin():
        print('需要管理员权限：Sysmac Studio 以 High 完整性级别运行，'
              'Medium 进程读不到它的 UIA 子树（UIPI）。')
        print('  做法：在"以管理员身份运行"的终端里执行本命令；'
              '或用 PowerShell：Start-Process -Verb RunAs <python> <本脚本> <参数>')
        return 3

    return a.fn(a)


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    raise SystemExit(main())
