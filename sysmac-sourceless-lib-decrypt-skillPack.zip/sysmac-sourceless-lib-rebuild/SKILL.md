---
name: sysmac-sourceless-lib-rebuild
version: 0.4.2
description: 从解密出的 Sysmac 无源库（创建类型「常规库」+ 勾选「禁用源显示」）明文源码重建一个内容一模一样的新 .slr 库文件，并用 Sysmac Studio 实测闭环验证。两条路径：重加密精确比对路径（把明文按原 EncryptionLock 推导的 key/IV 重新加密回填，密文与原库逐字节一致——重建精确性的最强证明）；源可见重建路径（唯一结构差异是 LibraryModel.IsDisableSourceDisplay true→false，其余条目逐字节保留，得到可在编辑器里查看 ST 源的普通库）。附带自包含脚本 scripts/smx_rebuild.py（flag / check / --selftest，纯离线，产出与历史产物逐字节一致）。关于「没有源代码的库」+禁显：2026-11-21 复核更正——实测走通的是「换载体」（用同名同版本的可解容器改旗标后替换工程引用，UI 显示全文且与明文逐字节一致），**不是**把明文装配进无源码库本体；后者从未实测且有结构障碍，文中明确标为不可用路径。包含结构校验清单、UI 实测 A/B 对照判据（变量表 vs 完整 ST+「显示源」菜单+工具箱命名空间）、看库 POU 源码的唯一稳定通道（程序编辑器 → 工具箱库分组 → 右键 FB 实例 → 转到下层 → SyntaxEditor TextPattern）、TextPattern 提取全文与离线明文逐字节比对、编译 0 错 0 警判据、不保存关闭与全量哈希核对，以及六个实测坑（绝对库路径缺失静默空树、剪贴板贴反斜杠路径、Git Bash 改写盘符路径、WPF 保存确认框、模态对话框吞点击、库索引 WPF 表格不向 UIA 暴露树）。2026-11-22 追加：无源码工程可离线重构为「源可见验证工程」（删 BuiltLibraryFiles、补 PouBody/SourceHolder/StructuredTextModel，接口取自 SLWD，反编译伪代码以注释嵌入）。**但该产物已判不可用**——17/17 POU 体为空（仅 `;`），逻辑全在注释里，能看不能跑，用户明确「重构的不行」；结构改得动不等于程序回来了。依赖 sysmac-sourceless-lib-decrypt 得到明文；UI 验证段用自带的 scripts/smx_ui.py（UIA 驱动随包分发，可替换为同源 sysmac-studio-control）。全部结论只在 Sysmac Studio V1.68（1.68.0.64010）+ Windows 11 上验证过，换版本先看 §0.1「版本适用性」。仅限自有库与授权审计使用。
metadata:
  author: hoverwu
  unofficial: true
  tested_against: 'Sysmac Studio V1.68 (1.68.0.64010) 64bit / Windows 11 / 7 POU 库 .slr（创建类型「常规库」+ 勾选「禁用源显示」），2026-11-20 端到端实测；另 2026-11-21 实测「没有源代码的库」+禁显工程 → 源可见重建库 → 新工程 UI 全文比对 + 保存；2026-11-22 离线重构「没有源代码的库」+禁显 17 POU 工程为源可见验证工程（结构 PASS，但 POU 体为空、语义全丢，用户判定不可用，UI 不做）'
  emoji: '🏗️'
  requires:
    python: '>=3.10'
    pip: ['pycryptodome']
---

# Sysmac 无源库重建（从解密明文到一模一样的新库）

作者：hoverwu ｜ 版本：0.4.2 ｜ 建立：2026-11-20

前置：已完成 `sysmac-sourceless-lib-decrypt`（拿到全部 POU 明文 ST 与 EncryptionLock）。仅限自有库/授权审计。

## 0.0 依赖与环境（换机器必读）

**路径 a / b 与结构校验全部离线自包含**：

| 项 | 要求 | 说明 |
| --- | --- | --- |
| Python | ≥ 3.10 | 路径 b 与校验只用标准库；路径 a 的重加密另需 `pycryptodome` |
| `pycryptodome` | 任意版本 | 仅路径 a（重加密逐字节比对）需要 |
| `uiautomation` + `pillow` | 任意版本 | 仅 §3 UI 段需要（`pip install uiautomation pillow`） |
| 网络 / 原工程 / 密码 | **都不需要** | 改旗标是对 ZIP 条目的字节级替换 |

**§3 的 UI 闭环另需**：Windows + Sysmac Studio V1.68 + **本目录自带的** `scripts/smx_ui.py`
（UIA 驱动已随包分发，见 §3；`pip install uiautomation pillow`，且必须以管理员身份运行）。
离线段（§2 + §2b + §3.4）已经足以产出并校验交付物；UI 段只用于"证明 Sysmac 真的显示全文"。

```bash
python scripts/smx_rebuild.py --selftest                      # 2 项自检
python scripts/smx_rebuild.py flag 库.slr -o 库_重建.slr       # 路径 b
python scripts/smx_rebuild.py check 库.slr 库_重建.slr         # 结构校验（改完必跑）
```

`flag` 内部已含 ZIP64 保护性判据（条目>60000 或单文件>2GB 直接拒绝）、单条目命中校验、
幂等保护（已改过的库会报错而不是静默成功），并在写完后自动跑一次 `check`。

## 0.1 版本适用性（换版本必读）

**本 skill 的全部结论只在一个版本上验证过**：

| 项 | 实测值 |
| --- | --- |
| Sysmac Studio | **V1.68（文件版本 `1.68.0.64010`）64bit** |
| 操作系统 | Windows 11 64bit |
| 样例库 | 7 个 POU（1 FB + 6 Function）的 `.slr`，创建类型「常规库」+ 勾选「禁用源显示」 |

**换版本不等于不能用，但要按下面三档处理**——先弄清"两个版本"分别是什么：

1. **库/工程是哪个版本生成的**：看归档里 `LibraryModel` 的
   `<ApplicationProductVersion>1.68.0.64010</ApplicationProductVersion>`。本 skill 的三个脚本都会读它，
   在输出里打一行 `PRODUCER Sysmac Studio <版本>`；与本表不一致时打 `VERSION:` 警告（**不阻断**，只提示）。
2. **本机 Sysmac 是哪个版本**：`python scripts/smx_ui.py version`（读 exe 的文件版本资源，不猜安装路径），
   或菜单 帮助(H) → 版本信息。

| 情形 | 离线段（§1 / §2 / §2b / §3.4） | UI 段（§3） |
| --- | --- | --- |
| 完全同版本 `1.68.0.64010` | 直接照用 | 直接照用 |
| 同 minor、不同 build（如 `1.68.0.7xxxx`） | 直接照用（ZIP 结构与旗标是容器级约定，不随 build 变） | 先跑 `smx_ui.py version` 确认，再做**一次**单 POU 的 A/B 对照（§3.2 第 2/4 步）；UIA 树（`AutomationId`、菜单名）是本 skill 最脆弱的部分 |
| 跨 minor（`1.6x` ↔ `1.7x` 及以上） | **重新验一遍再引用结论**：判型命令跑通、`flag` 产物能被 Sysmac 打开、`check` 全绿 | **必须重测**：UIA 元素名/菜单层级/对话框形态都可能变；§3.1 的六个坑里至少坑 2、3、4、6 与 UI 结构强相关 |

**换版本最小复核清单（3 条，10 分钟内可跑完）**：

```bash
python scripts/smx_rebuild.py --selftest                 # 1) 离线段自检仍过
python scripts/smx_rebuild.py flag 库.slr -o t.slr       # 2) 产出仍能被 check 判 PASS
python scripts/smx_ui.py version && python scripts/smx_ui.py --selftest   # 3) UI 段依赖与转发目标就位
```

三条全过 → 离线段结论可直接沿用；UI 段再补一次单 POU A/B 对照即可。任一条不过 →
把输出连同 `PRODUCER` 行一起记下来，按 §4「未验证」处理，**不要外推**。

## 0. 结论【实测】

重建可行且有强验收判据：

- **重加密路径** 7/7 POU 密文与原库**逐字节一致**（.NET `RijndaelManaged` 与 pycryptodome 双引擎交叉验证）→ 库加密是纯确定性变换，无盐、无时间戳进密文。
- **源可见重建库** 与原库唯一差异是根实体 `LibraryModel.IsDisableSourceDisplay` true→false（+1 字节），其余 ZIP 条目逐字节一致；换入测试工程后编译 **0 错 0 警**、编辑器显示的 ST 全文与离线解密明文**逐字节一致（零归一化）**。
- **「没有源代码的库」+禁显**（2026-11-21 实测，见 §2b）：无密文可重加密，但只要有明文参照，装配出的源可见库导入新工程后 UI **同样显示全文**，与明文逐字节一致，工程原生保存成功。
- **无源码工程 → 源可见验证工程**（2026-11-22，见 §2b.5）：没有可解容器时，可删 `BuiltLibraryFiles`、补 `PouBody`/`SourceHolder`/`PouBodySourceHolder`/`StructuredTextModel`，接口取自目标 SLWD。**但产物已判不可用**：17/17 POU 体为空（仅 `;`），逻辑全在注释里，运行起来什么都不做。**结构改得动 ≠ 程序回来了**——这条路只能作查看用途，不能交付。

路径 a/b/c 的选择只看一件事：**PouBody 里有没有 `EncryptedFile`**。§2b.5 是另一条"验证工程"路线，**已实测判不可用（语义为空）**，仅作结构可行性记录，不用于交付。

## 1. 路径 a：重加密精确比对（精确性证明，不交付）

用途：证明"重建"不是巧合——同一把锁（lock）+ 同一个明文必然得到同一串密文。

```
明文（EncryptedBody 信封原字节，HTML 转义前的 <Body> 内容）
  → key = LockToKey(EncryptionLock)（32 B ASCII）/ iv = LockToIV(EncryptionLock)（16 B ASCII）
  → AES-256-CBC/PKCS7 加密 → base64
  → 回填实体 xml 的 <Body>，与原密文逐字节比对
```

- **回填的是信封原字节**：不要先 `html.unescape` 再加密——实体 xml 的 `<Body>` 里存的就是加密后的 base64，明文是"信封 XML 字符串的 UTF-8 字节"，从信封原文直接加密。两方向用同一份字节序列即可逐字节对齐。
- 双引擎交叉：pycryptodome 为主，缺库时 PowerShell 调 `.NET RijndaelManaged`（Mode=CBC、Padding=PKCS7、KeySize=256、BlockSize=128，与 Sysmac 同款）。
- 全部 POU 比对通过 ⇒ 复刻文件与原库 0 条目差异；这一步的产物只当证据，不当交付物（它仍是"无源"库）。

## 2. 路径 b：源可见重建库（交付物）

**唯一结构差 = 显示旗标**【实测】：`IsSource` 在无源库与普通库两边都是 `true`（源码都在），无源库多的只是 `IsDisableSourceDisplay="true"`。参照验证法：欧姆龙安装目录自带的标准库 `.slr` **同样**用 EncryptedFile 加密（连欧姆龙自己的库都走同一加密），只是实体里**没有**这两个旗标——所以"无源"与"源可见"的差异是显示策略，不是加密形态。

**口径与外推边界**：路径 a/b 的"唯一结构差是显示旗标"只对创建类型**「常规库」+ 勾选「禁用源显示」**成立。创建类型**「没有源代码的库」+ 禁用源显示**已于 2026-11-21 复核（§2b）：该类库 `IsSource=false`、`IsBackwardCompatibleNoSource=true`、**0 个 `EncryptedFile`**——**没有密文可重加密，路径 a 直接失效**，路径 b 的"只改一个旗标"也不成立（改旗标不会凭空长出源码）。拿到新库先按 `sysmac-sourceless-lib-decrypt` §1 判型判明形态，再决定走哪条路径。

操作：解包 `.slr`（ZIP）→ 改根实体 `<IsDisableSourceDisplay>true</IsDisableSourceDisplay>` 为 `false` → 按原 compress_type 与条目顺序重写 ZIP。**其它任何条目都不动**（尤其 `<Checksum>`，语义未定位，密文不变时它天然有效）。

> **已固化成命令**：`python scripts/smx_rebuild.py flag <源.slr> -o <产物.slr>`，写完自动 `check`。
> 实现要点：**字节级 `bytes.replace`**，不要 decode→改→encode（BOM/CRLF 会变，"只有旗标变了"这条判据就失效）。实测对样例库（7 POU）产出 **66 512 B / `6dac3bf9…`**，与历史产物**逐字节一致**。

**⚠️ 交付物形态要看清（2026-11-21 实测）**：「源可见」有两种终态，产物性质不同，别混着说。

| 终态 | 旗标 | 载体 | 分发含义 |
| --- | --- | --- | --- |
| **改旗标**（路径 b 的产物） | `IsDisableSourceDisplay=false` | **密文与 lock 原样保留**（实测 7/7 个 Body 与原库逐字节相同） | 体积几乎不变；Sysmac 现解现显示；**密文 + 钥匙随库走，谁拿到都能解**（2026-11-21 T17 实测：按 decrypt §4 纯离线解 7/7 全出、与明文逐字节一致，**解密成本为零**）；对方把旗标改回去就又"禁显"了，但源码他早拿到了 |
| **明文装配**（原「路径 c」） | 同上 | 无密文，`StructuredTextModel` 里是明文 `<Text>` | **未实测，且结构障碍见 §2b.3** —— 不要当作可用路径。理论上它才是"真交付源码"的形态（分发即公开源码、不可逆） |

判型工具能直接区分：`scripts/smx_decrypt.py`（或 `ss_libtype.py`）对前者报 `AES_VISIBLE`、对后者报 `PLAIN_VISIBLE`（见 `sysmac-sourceless-lib-decrypt` §1）。
**现状**：路径 b 只解决"自己能看"，别把它的产物当成"已去加密"；"真交付源码"目前**没有已验证的路径**（§2b.3 的明文装配未实测）。

**结构校验清单**（改完必跑）：

- [ ] `zipfile.testzip()` 无坏条目、条目数与原库一致
- [ ] `.oem` 与根实体、全部 POU 实体 XML 良构（带 BOM 声明的按原编码）
- [ ] 除目标旗标外，逐条目字节不变
- [ ] 容器头装饰差异可接受：原库可能带 ZIP64 扩展头，标准 central directory 重写的文件数据区条目逐字节一致即可，ZIP 读取器（含 Sysmac）两者兼容【实测】

**ZIP64 保护性判据（代替"穷举验证兼容性"）**：重建前先量一下规模，超阈值直接拒绝，别硬写——

```python
with zipfile.ZipFile(src) as z:
    infos = z.infolist()
    n = len(infos)
    big = max(i.file_size for i in infos)
if n > 60000 or big > 2 * 1024**3:
    raise SystemExit("拒绝重建：条目数=%d / 单文件=%.1f GB，已进入 ZIP64 区；"
                     "需保留原 ZIP64 extra field 重写，本流程未验证" % (n, big / 1024**3))
```

理由：ZIP64 只在 >65535 条目或 >4 GB 时启用，实测库都是几十 KB~几 MB；与其覆盖各种 ZIP 读取器做穷举验证，不如在入口挡住，成本≈0。

## 2b. 「没有源代码的库」+禁显 的处理【2026-11-21 复核更正】

> **更正说明（必读）**：本节 0.2.x 版本把样例重建库（66 512 B / `6dac3bf9…`）当作「路径 c 明文装配」的产物引用，**这是错的**。复核证据：
>
> 1. 该文件判型 **`AES_VISIBLE`**，内含 **7 个 `EncryptedFile`**（密文与原 AES 库逐字节相同）；
> 2. 用「路径 b 改旗标」10 行代码即可**逐字节复现**它（`smx_rebuild.py flag 库.slr` → 66 512 B / `6dac3bf9…`）；
> 3. 验证工程的库引用是 `LibraryFilePath=…\重建库.slr` + `LibraryId=76b60aba`（= **AES 库**），
>    而改造前是 `…\无源码库.slr` + `LibraryId=e107827d`（= 无源码库）。
>
> ⇒ **原先记录的「明文装配」实际做的是「换载体」。** 下面把两条分开写。

### 2b.1 这类库长什么样（先确认，别拿路径 a 硬套）

| 判据 | 「常规库+禁显」 | 「没有源代码的库+禁显」 |
| --- | --- | --- |
| `IsSource` | `true` | **`false`** |
| `IsBackwardCompatibleNoSource` | 无 / 空 | **`true`** |
| PouBody 内 `EncryptedFile` | 7 个（AES 密文） | **0 个** |
| 程序体载体 | 加密 ST 信封 | `BuiltLibraryFile`：ELF64 Controller + PE Simulator + CX-IL `PouBodySourceHolder`（仅链接元数据，无 ST） |

⇒ **无密文可解、也无密文可回填**。源码级文本只能来自"别处的明文参照"。

### 2b.2 实测做法：换载体（端到端 PASS）

**前提**：你手上同时有该库的一个**可解容器**——同 `Name` + 同 `Version` + 同 POU 集合的 AES 库 `.slr`。
这时**不要碰无源码库本身**：

1. 对可解容器跑路径 b：`python scripts/smx_rebuild.py flag <AES库.slr> -o <同名_重建.slr>`
2. 工程(P) → 库(L) → 显示索引(S) → 选中旧行（指向 `_无源码.slr`）→ 删除 → `+` 添加重建库
   → 消「库已经被引用。库将被一个新的所替换…」选 **是(Y)** → 消「库中可能使用了当前控制器不支持的指令」
3. 按 §3.3 打开库 POU → 显示全文；按需保存（交付式）

实测：UI 显示 **11 766 字符 / 345 行 / `2cc52a1b…`**，与明文逐字节一致；保存后工程 248 749 → 89 119 B；
原件哈希全未变；保存后工程内嵌 7 个明文 `StructuredTextModel`。

**为什么体积降 64%**：原工程内嵌 7×ELF64 + 7×PE 的 `BuiltLibraryFile`；换成外部 `.slr` 引用 + 明文 ST 后自然变小。
**这不等于"无源码库被改成了明文库"**，只是工程换了个引用对象——重建库自己仍是 `AES_VISIBLE`（密文还在）。

### 2b.3 未实测的做法：把明文装配进无源码库本体

原文写的「把 `<BuiltLibraryFile>` 换成 `<StructuredTextModel><Text>明文</Text></StructuredTextModel>`」
**从未被实测**，而且有结构障碍：

| | 「常规库+禁显」 | 「没有源代码的库+禁显」 |
| --- | --- | --- |
| 归档条目数 | 49 | 28 |
| 实体布局 | **每个 POU 一个实体文件**（7 个 `<GUID>.xml`，各含 1 个 `EncryptedFile`） | **单个 608 KB 合并实体**，8 个 `BuiltLibraryFile` 全在里面 |
| 明文模型形态 | `<StructuredTextModel i:type="a:string">` + 转义信封 | 目标形态应为 `<StructuredTextModel xmlns=…><Text>`（无 `i:type`） |

⇒ 「一步替换」不成立：要动的是 608 KB 合并实体内部的多个位置，还要处理命名空间、`i:type` 的有无、
以及 CR 转义（实测明文体里 CR 写成 `&#xD;`；写裸 `\r` 会被 XML 解析器归一化成 `\n`）。
**本流程不提供该实现，也不声称它可行。** 若你只有无源码库、没有可解容器 → 走
`sysmac-build-artifact-capture`（接口 / 调用图 / 状态机骨架，**ST 全文不可得**），或按 §2b.5 做工程层源可见验证工程（接口精确、逻辑为反编译伪代码，**仍不是原 ST**）。

### 2b.4 换载体后的端到端结果（实测）

| 判据 | 实测值 |
| --- | --- |
| UI 显示源码 | `FB_Xxx - <控制器>` 的 `SyntaxEditor` 取全文，归一化 **11 766 字符 / 345 行** |
| 与明文一致性 | UI 文本 SHA-256 `2cc52a1b…` == 明文参照 `2cc52a1b…`，**逐字节一致**（仅 CRLF→LF 归一化） |
| 保存后工程旗标 | `<IsSource>true</IsSource>` + `<IsDisableSourceDisplay>false</IsDisableSourceDisplay>` + `LibraryFilePath` 指向重建库 |
| 源码落盘 | 工程内嵌 **7 个 `StructuredTextModel`**，最大者 11 766 字符 / 345 行 / `2cc52a1b…` |
| 原件未变 | 目标工程、参照 `.slr`、重建 `.slr` 哈希前后一致 |
| 体积变化 | 工程副本 248 749 B → 89 119 B（内嵌 `BuiltLibraryFile` 换成外部引用，属预期） |

等价性判据（离线，先跑再进 UI）：**7/7 POU 名 + TrackingId 集合相同**；同名实体 25 个中 16 个逐字节相同、
24 个忽略 `Id` 后语义相同、0 语义差异（差异全为 GUID）。

### 2b.5 无源码工程 → 源可见验证工程（2026-11-22 结构可行性记录，**产物已判不可用**）

> ⚠️ **结论先行（2026-11-22 用户判定「重构的不行」）**：这条路线产出的工程，**17/17 POU 的函数体都是空的**——只有一个 `;` 占位，全部逻辑只以 `//` 注释存在。它能编译、能看，但**运行起来什么都不做**（Function 恒返回 FALSE/0，FB 恒不动），与原程序行为完全不等价。**因此它不是一个可用的重构结果，不要作为交付物，也不要据此承诺"程序已重建"。** 保留本节仅作两件事的记录：① `BuiltLibraryFile` ↔ `PouBody` 的容器可被纯离线替换且 ZIP 结构合法；② 接口声明可从目标 SLWD 精确还原。**不再安排 Sysmac UI 导入/编译验证**（用户 2026-11-22 明确「不测了」）。
>
> 换句话说：**这条路能证明"结构改得动"，不能证明"程序回来了"。** 需要可用程序时，只能拿原源码或等价明文重新实现，反编译伪代码仅可作人工重写的参考底稿。

适用：目标是 `.smc2` 工程，库为「没有源代码的库」+禁显，且**没有可解容器 / 原源码**。目的仅限于把目标内可恢复的信息（精确接口 + 反编译伪代码）放进一个可查看的源可见工程。

1. 解包目标 `.smc2`，保留全部原始条目；定位 `.oem` 与含 `<BuiltLibraryFiles>` 的合并实体。
2. 对每个库 POU：保留原 `Entity` 树，在 POU 的 `ChildEntities` 内插入 `PouBody`（内含 nested `SourceHolder`）+ sibling `SourceHolder` + `PouBodySourceHolder`；`PouBody` 的 `trackingId` 与原 POU 对应。
3. 为每个 `PouBody` 生成一个 `StructuredTextModel` 条目，`<Text>` 内是 HTML 转义后的 ST。
4. 删除 `<BuiltLibraryFiles>`；`IsSource` 置 `true`、`IsDisableSourceDisplay` 置 `false`、删除 `IsBackwardCompatibleNoSource`。
5. ST 声明从目标 SLWD 取：**按每个变量自己的 `G=` 分组**（`VAR_INPUT` / `VAR_OUTPUT` / `VAR_IN_OUT` / `VAR`），不要按外层 `+GN=` 容器——否则 `VAR_IN_OUT` 会被误放进 `VAR_INPUT`（2026-11-22 实测踩到并修正）。
6. 反编译伪代码整段以 `//` 注释嵌入，末尾保留一个 `;` 占位。**注意这一步就是产物不可用的根因**：注释不是代码，POU 体实际为空。
7. 离线校验：ZIP CRC、`StructuredTextModel` 数、0 `BuiltLibraryFile`、0 `EncryptedFile`、每个 POU 三件套完整、声明与 SLWD 逐项一致。**这些校验只覆盖结构，不覆盖语义**——全部通过也不代表程序能用。

2026-11-22 实测（17 POU，目标 `dc0ab745…`）：

| 判据 | 结果 |
| --- | --- |
| 输出 | 196 067 B / `c0a2eb8f…` |
| ST 结构 | 17 `StructuredTextModel` / 0 `BuiltLibraryFile` / 0 `EncryptedFile` |
| holder | 17/17 完整（`PouBody` + `SourceHolder` + `PouBodySourceHolder`） |
| 接口 | 17/17 声明与目标 SLWD 的组/名称/顺序一致 |
| 反编译可信度 | 8 FULL / 8 PARTIAL / 1 SKELETON |
| **可执行逻辑** | **0 条语句；17/17 POU 体仅 `;`** |
| **行为等价性** | **不等价（恒返回默认值 / FB 不动作）** |
| **用户判定** | **不可用（2026-11-22 15:56）** |
| UI | **不做**（用户明确「不测了」） |

**边界**：这不是原源码，也**不是**可运行等价程序——比"不等价"更准确的说法是"没有逻辑"。与 §2b.3 的区别：§2b.3 是"把明文装配进无源码库本体"（未实测、不可用）；§2b.5 是"在工程层重建源可见结构"，结构成立但**语义为空**，同样不可用于交付。两条路都**不能**把反编译伪代码变成可运行程序。

## 3. UI 实测闭环（`scripts/smx_ui.py`，或任一同源 UIA 驱动）

在一一次性**测试工程副本**上做（原件只读）。全流程 headless UIA、需要提权通道（Sysmac 自动提权 High，UIA 进程须同完整性）。

> **本 skill 已自带 UIA 驱动**：`scripts/smx_ui.py`（1.0.0）+ `scripts/ui/{ss,ss_libref,ss_libsrc,ss_build}.py`。
> 它们从作者同源的 `sysmac-studio-control` skill 收编而来，已去掉全部本机路径/项目名/pid：
> Sysmac 位置靠**进程名**识别，工程路径一律由参数传入，版本靠 **exe 文件版本资源**读取。
> 若你环境里已有更新的 `sysmac-studio-control`，可整目录替换 `scripts/ui/`，命令不变。
>
> ```bash
> python scripts/smx_ui.py --selftest            # 依赖 + 转发目标 + 版本比较，不启动 Sysmac
> python scripts/smx_ui.py version               # 打印运行中/已安装 Sysmac 的版本并与实测版本比对
> python scripts/smx_ui.py portability           # 扫描 skill 目录，查有没有混进本机痕迹
> ```
>
> 其余子命令一一对应 §3.2 的步骤：`detect`/`state` 看进程与工程是否就绪、`open` 开副本、
> `lib-list`/`lib-open`/`lib-replace` 走库索引、`src-toolbox`/`src-goto`/`src-text` 取库 POU 源码（§3.3）、
> `build` 编译、`save` 保存、`close` 关闭。`save` 会比对前后 sha256，报 `NO-CHANGE` 时**不能当成保存成功**。
>
> `version` 不靠猜安装路径：先看有没有正在运行的 Sysmac 进程，没有再查注册表
> （`App Paths\SysmacStudio.exe` 与卸载列表的 `DisplayIcon`/`InstallLocation`）定位 exe，
> 读它的**文件版本资源**，再与 `1.68.0.64010` 比对给出「同版本 / 同 minor / 跨 minor」提示。

两种收尾模式，**先明确要哪一种**：

| 模式 | 用途 | 收尾 |
| --- | --- | --- |
| **A/B 取证式** | 只证明"能看见源码"，不改磁盘 | 第 7 步**不保存**关闭 → 哈希全等 |
| **交付式**（实测） | 要一份"打开就能看源码"的工程 | 第 7 步**原生保存** → 副本哈希变化 + 原件不变；再把副本重新打开复核一次更稳 |

### 3.1 六个实测坑（先读，每条都吃掉过一轮时间）

1. **绝对库路径缺失 → 静默空树**：`ReferredLibrariesModel` 里存的是**绝对** `LibraryFilePath`；路径不存在时 Sysmac **不弹任何框**，库索引树直接为空。打开工程后库树是空的，先把 `.slr` 放回记录的路径，或重做引用。
2. **文件对话框拒正斜杠**：给「引用库文件」输入路径时，native 文件对话框不接受正斜杠；自动化通道里反斜杠又容易被命令行解析吞掉——**用剪贴板粘贴完整反斜杠路径**，且粘贴后校验输入框 `Value` 等于目标路径再点「打开(O)」。
3. **模态「库索引」对话框不关会吞掉全部工具栏点击**：编译按钮点了没反应、busy 永不可见 → 先用 UIA Invoke 点「确定」关掉库索引对话框（WPF 对话框不是 `#32770`，按 pid 枚举顶层窗找）。
4. **关闭时的保存确认是 WPF 弹窗**：标题=工程名、非 `#32770`，按钮 是(Y)/否(N)/取消；按 pid 枚举顶层窗 + UIA Invoke 否(N)。点击"落空"不报错的另一个来源是无关系统弹层抢焦点（全屏截图排查，ESC 解除）。
5. **Git Bash 会改写盘符路径**（2026-11-21 实测）：命令行里传 `<盘>:\proj\a.smc2` 到 native 对话框，会被 MSYS 改写成 `<盘>:/proj/a.smc2`（正斜杠），Sysmac 报「…文件名无效。」；`MSYS_NO_PATHCONV=1` 与 `MSYS2_ARG_CONV_EXCL='*'` **都拦不住**。解法：在 Python 里用 `r"<盘>:\..."` 拼出整条命令再提交，并**读回输入框 `Value` 校验反斜杠仍在**。
6. **库索引的树展不开，别硬啃**（2026-11-21 实测）：`LibraryDataGrid` 是 WPF 自绘表格，**不向 UIA 暴露任何行/子节点**；坐标点展开箭头（x 全扫）、双击行、`SetFocus` + `VK_DOWN`/`VK_RIGHT` **全部无效**（前后 dump 完全一致）。要看库 POU 源码走 §3.3 的通道。

### 3.2 步骤与判据

| 步 | 动作 | 判据 |
| --- | --- | --- |
| 1 | 打开测试工程副本，确认库树非空（坑 3.1-1） | 库索引出现库名与版本 |
| 2 | **A 态取证**（原无源库引用）：展开到目标 FB，双击打开 | 编辑器**只有变量表**（输入/输出引脚），无代码，无「显示源」菜单 |
| 3 | 库替换：`工程(P)` → `库(L)` → `显示索引(S)` → 选中旧行 → 删除 → `+` 重加重建库路径（坑 3.1-2）→ 消「库已经被引用。库将被一个新的所替换…」警告（**是(Y)**）→ 消「库中可能使用了当前控制器不支持的指令」→ `确定` | 替换**不是追加**：同名库不删旧行直接 `+` 会撞名出两行；两个警告都可能 >2s 才冒出来，别抢点 |
| 4 | **B 态取证**（重建库引用）：§3.3 打开目标 FB | **完整 ST 源显示** + 工具箱出现 `<库名> (<版本>)` 命名空间 |
| 5 | **终极闭环**：对 `SyntaxEditor` 取 `TextPattern.DocumentRange.GetText(-1)` | 与离线明文**逐字节一致（仅 CRLF→LF 归一化）**——Sysmac 编辑器里显示的就是原始源码 |
| 6 | **编译验证**（可选）：`编译控制器(B)` | PASS = errors=0 warnings=0 且判据满足（观测到 busy 或计数/网格变化 + 连续两次稳定空闲快照）；缺证据一律 INCONCLUSIVE，不放宽 |
| 7 | **收尾**：按模式选「不保存关闭」或「`文件(F)` → `保存(S)`」→ 全量哈希核对 | 取证式：哈希全等；交付式：副本哈希变化 + 原件不变 + 保存后工程内嵌 `StructuredTextModel` 含明文 |

### 3.3 看库 POU 源码的唯一稳定通道【2026-11-21 实测】

> 已固化成命令，不必再手写脚本：`scripts/smx_ui.py`（本 skill 自带）
> `src-toolbox` 列库分组与 POU、`src-goto <x> <y>` 右键实例按名 Invoke `转到下层`、`src-text` 导出全文 + sha256。
> 底层实现在 `scripts/ui/ss_libsrc.py`。下面是从零实现时的等价写法，用于换环境/换版本时对照。

```
打开任一程序编辑器（梯形图即可）
  → 工具箱出现库分组按钮 ` <库名> ( <版本> )`（AutomationId = groupToggle）
  → GetTogglePattern().Toggle() 展开 → 列出库内全部 POU
  → 在梯形图里右键该库的 FB 实例 → 菜单「转到下层」（快捷键 Ctrl+Shift+L）
  → 打开 `<FB名> - <实例名>` DocumentWindow
       └ Pane → Custom(SyntaxEditorView) → Text(AutomationId=textEditor, class=SyntaxEditor)
  → editor.GetTextPattern().DocumentRange.GetText(-1)  # 全文 ST
```

要点：
- **折叠的库分组不向 UIA 暴露子项**：不 Toggle 展开只能拿到分组名（2026-11-21 实测）。
- **不要**试图在库索引里点选 POU 打开——那条路 UIA 走不通（坑 3.1-6）。
- 右键菜单项是 `MenuItemControl` 且 `Name == '转到下层'`，用 `GetInvokePattern().Invoke()`；不要用坐标点击（会抢鼠标，且菜单易被别的窗口盖住）。
- `SyntaxEditor` 的 `AutomationId` 固定是 `textEditor`，靠这个定位最稳，别靠 `Name`（为空）。
- 取到的文本是**编辑器显示文本**：CRLF 与首尾空行可能和磁盘明文不同，比对前统一做 `replace('\r\n','\n').strip('\n')`，**不要**做内容级清洗。

### 3.4 保存后如何在磁盘上复核（不依赖 UI）

保存后的 `.smc2` 是普通 ZIP，直接查三件事：

```python
# 1) 库引用旗标：ReferredLibrary/LibraryModel 下是【元素文本】形式，不是属性
'<IsSource>true</IsSource>' in xml and '<IsDisableSourceDisplay>false</IsDisableSourceDisplay>' in xml
# 2) 源码已落盘：数 <StructuredTextModel> 实体，逐个取 <Text> 与明文比 sha256
# 3) 别被同名节点骗：<BuildOption> 下也有一个 LibraryModel（工程自身，Name=工程名、路径空），
#    它的 IsDisableSourceDisplay 是 true 属正常，不是"没改成功"
```

实测：目标 FB 的 `StructuredTextModel` = 11 766 字符 / 345 行 / `2cc52a1b…`，与明文完全一致；工程内共 7 个 `StructuredTextModel`。

## 4. 已验证事实 vs 未验证

> `影响面` 三档：**阻塞可用性**（错了结论要降级）｜**静默错误风险**（错了看不出来）｜**仅认知/边界**（记录即可，不必排期）。

| 状态 | 影响面 | 内容 |
| --- | --- | --- |
| 实测 | — | 重加密 7/7 逐字节一致（双引擎）；重建库换入后 A/B 对照成立、TextPattern 全文逐字节一致、编译 0/0、哈希核对通过 |
| 实测（2026-11-21，UI 闭环） | — | **「没有源代码的库」+禁显 → 可看源码**（§2b.2 **换载体**，不是明文装配）：用同名同版本的可解容器改旗标后替换工程引用，UI 显示全文 11 766 字符/345 行、与明文逐字节一致、工程原生保存且内嵌 7 个 `StructuredTextModel`、原件未变。**「明文装配进无源码库本体」仍未实测**（§2b.3） |
| 实测（2026-11-21，7 POU 一致性） | 静默错误风险 → 已关闭 | **换载体产物的 7 个 POU 全部逐字节一致**（原「只比了 1 个 FB」的空白已补）：离线把工程内嵌的 7 个 `StructuredTextModel` 与 7 份 slr 明文按归一化 sha256 对撞，**7/7 全等、参照侧无剩余**（FB `2cc52a1b…`、其余 6 个 Function `1a6306b4…`/`4efcb0dd…`/`baaa4613…`/`bf3d8dbe…`/`f117a911…`/`fcbbba97…`）。**不需要 UI**，一条脚本即可复跑 |
| 实测（2026-11-21，编译验证） | 阻塞可用性 → 已关闭 | **换载体产物的库编译验证 PASS**：验证工程（引用重建库）`编译控制器(B)` → **errors=0 / warnings=0**（`ss_build.py run` 返回 0，且满足"本轮真的编译过"的新鲜度判据，不是陈旧计数）。未保存关闭，工程哈希 `61c69427…` 前后一致 |
| 实测（2026-11-21，编译成员） | 阻塞可用性 → **直接测量（不再是推断）** | **引用库整体参与编译已在本工程实测**：在验证副本上编译并**保存**（`61c69427…` → `b568772d…`，归档成员 72→73），离线递归解包捕获副本得 **`UserLib_*.cxif2` = 7 个**，trackingId 与本库 7 个 POU 逐一对应、**无缺无余**（`7aa51b9d`/`f292374c`/`30e406ad`/`215939f2`/`d5461dbb`/`49c2b078`/`2fd7ed5f`），另有 8 个 `LV_*.cxil2`（7 库 POU + 1 程序）。原先那条"依据另一个工程"的跨工程推断**已作废** |
| 实测（2026-11-21，UIA 通道） | — | 库索引 `LibraryDataGrid` 不向 UIA 暴露树；`转到下层` 是看库 POU 源码的唯一稳定通道（§3.3） |
| **实测失败（2026-11-22，§2b.5）** | **阻塞可用性 → 判定不可用** | **无源码工程 → 源可见验证工程，用户判定「重构的不行」**：结构侧全过（17 `StructuredTextModel` / 0 `BuiltLibraryFile` / holder 17/17 / 声明 17/17），**但语义侧全空——17/17 POU 体仅 `;`，0 条可执行语句**，Function 恒返回默认值、FB 不动作。**教训：结构校验（ZIP CRC、标签计数、声明比对）不能代替语义校验；"能导入能编译"也不等于"程序能跑"。** 用户 2026-11-22 明确不再做 UI 验证 |
| 实测（2026-11-22，离线结构） | 静默错误风险（已缓解） | **17 POU「没有源代码的库」+禁显工程 → 源可见验证工程**（§2b.5）：17 `StructuredTextModel` / 0 `BuiltLibraryFile` / 0 `EncryptedFile` / holder 17/17 / 声明 17/17 与 SLWD 一致。接口分组按每变量 `G=`，修正了 `VAR_IN_OUT` 误入 `VAR_INPUT` 的问题。**UI 导入/编译未验证**，伪代码不是原源码 |
| 未验证 | 仅认知/边界 | `EncryptedFile <Checksum>` 语义（重建不动它）；ZIP64 → 标准 CD 重写在所有 ZIP 读取器上的兼容性（实测 Sysmac 兼容）。**不再作为待验证项排期**，改为 §2 的保护性判据（超阈值直接拒绝），见下 |
| 提示 | — | 重建库若要长期使用，引用它的工程每次导入库仍会重加密——与本 skill 无关，属正常导入行为 |

**剩余的真实空白（如实）**：§2b.2「换载体」只在一个库（7 POU）上验证过；换库、换版本、换 POU 种类（如带动作/结构的 FB）仍属未测。**§2b.3「明文装配进无源码库本体」完全没有实测过**，不要当成可用路径。**§2b.5「无源码工程 → 源可见验证工程」已判不可用**：结构成立但 POU 体为空、语义全丢，用户 2026-11-22 判定「重构的不行」并停止 UI 验证。**结论：反编译伪代码无法经"重建源可见工程"变成可运行程序；要可用程序只能拿原源码或等价明文重新实现。**

## 5. 版本记录

| 版本 | 日期 | 内容 |
| --- | --- | --- |
| 0.4.2 | 2026-11-22 | **§2b.5 判定由"结构验证通过"改为"产物不可用"**（用户 15:56「重构的不行」+「不测了」）：实测复核 17/17 POU 体只有 `;`、0 条可执行语句，逻辑全在 `//` 注释里，Function 恒返回默认值、FB 不动作 ⇒ 能看不能跑。§2b.5 加结论先行警示块、实测表补"可执行逻辑 0 条 / 行为不等价 / 用户判定不可用 / UI 不做"三行、步骤 6 标注这就是不可用根因；§0 摘要、§1 路线说明、§4 风险表（新增一行**实测失败**）、"剩余的真实空白" 全部同步。**核心教训：结构校验（CRC/标签计数/声明比对）不能代替语义校验，"能导入能编译"也不等于"程序能跑"** |
| 0.4.1 | 2026-11-22 | 回填 17 POU「没有源代码的库」+禁显工程的**离线源可见重构**：新增 §2b.5（删 `BuiltLibraryFiles`、补 `PouBody`/`SourceHolder`/`PouBodySourceHolder`/`StructuredTextModel`；接口取自 SLWD；反编译伪代码以注释嵌入）；实测 17 ST / 0 BuiltLibraryFile / 0 EncryptedFile / holder 17/17 / 声明 17/17；修正按 `+GN=` 分组导致 `VAR_IN_OUT` 误入 `VAR_INPUT` 的坑；明确 UI 未验证、不是原源码/可运行等价程序 |
| 0.4.0 | 2026-11-21 | **通用化（换机/换版本可用）**：① **UIA 驱动随包分发**——新增 `scripts/smx_ui.py`（1.0.0，14 个子命令：`version`/`detect`/`open`/`state`/`lib-list`/`lib-open`/`lib-replace`/`src-toolbox`/`src-goto`/`src-text`/`build`/`save`/`close`/`portability`，另加 `--selftest`）+ `scripts/ui/{ss,ss_libref,ss_libsrc,ss_build}.py`；去掉全部本机路径/项目名/pid，Sysmac 位置靠进程名识别、版本靠 exe 文件版本资源读、工程路径全靠参数；不再依赖外部 `sysmac-studio-control`；② 新增 **§0.1「版本适用性」**：写明实测版本 `1.68.0.64010` / Windows 11，给出「同 build / 同 minor / 跨 minor」三档处理与 3 条换版本最小复核清单，并说明 `PRODUCER` 行怎么读；③ 三个脚本统一加 `VERIFIED_VERSION` 与 `VERSION:` 警告（版本不符只提示不阻断）；④ §3 重写为"自带驱动 + 等价写法"，§3.3 指向 `src-toolbox`/`src-goto`/`src-text`；⑤ 清理文档里残留的本机盘符与项目名，把被过度脱敏的内容哈希恢复成实测值 |
| 0.3.0 | 2026-11-21 | **可移植性修复 + 路径 c 更正**：① 新增 `scripts/smx_rebuild.py`（1.0.0）——`flag`（路径 b，字节级替换 + ZIP64 判据 + 单条目校验 + 幂等保护 + 自动 check）/ `check`（结构校验）/ `--selftest`；对样例库（7 POU）产出 66 512 B / `6dac3bf9…`，与历史产物逐字节一致；② 新增 §0.0「依赖与环境」；③ **更正 §2b**：原文把样例重建库当作「路径 c 明文装配」产物，实际它是「路径 b 改旗标」产物（`AES_VISIBLE`、7 个密文），原先记录的验证工程真正做的是**换载体**（库引用从 `无源码库.slr`/`e107827d` 换成 `重建库.slr`/`76b60aba`）；「明文装配进无源码库本体」**从未实测**且有结构障碍（无源码库是单个 608 KB 合并实体，AES 库是每 POU 一实体），已明确标为不可用路径；④ §4 表与「剩余空白」同步；⑤ 版本表按 semver 重排 |
| 0.2.4 | 2026-11-21 | 回填 T17：§2「两种源可见终态」表的**改旗标**一行补实测——按 decrypt §4 纯离线解 7/7 全出、与明文逐字节一致、重加密逐字节回原密文 ⇒ **密文+钥匙随库走，分发即公开源码，解密成本为零**（不是推论）。交付口径据此写死：只想自己看→改旗标；要真交付源码→必须明文装配（路径 c） |
| 0.2.3 | 2026-11-21 | 回填 T15/T16：① §4 U5 从**跨工程推断**改为**直接测量**——本工程验证副本编译并保存后，离线解包得 `UserLib_*.cxif2` = 7 个、trackingId 与 7 个 POU 逐一对应（无缺无余）；② §2 新增「两种源可见终态」表：改旗标（密文保留、钥匙随库走）vs 明文装配（无密文、体积降 64%），并给出 `ss_libtype.py` 的 `AES_VISIBLE`/`PLAIN_VISIBLE` 区分方式 |
| 0.2.2 | 2026-11-21 | 回填 T14：① 路径 c 的 **7 个 POU 全部逐字节一致**（原"只比 1 个 FB"的静默错误风险关闭，离线 7/7）；② 路径 c **编译验证 PASS（0 错 0 警）**，并说明引用库 7 个 POU 整体参与编译（依据 T9 的 7 个 `UserLib_*.cxif2`）；③ ZIP64 兼容性从"待验证"改为 **§2 保护性判据**（条目>60000 或单文件>2GB 直接拒绝）；④ §4 表新增 `影响面` 列 |
| 0.2.1 | 2026-11-21 | §3.3 指向已固化的命令 `ss_libsrc.py`（toolbox/goto/text），并补「折叠分组不暴露子项」这条实测；MCP 侧同步发布 `sysmac-studio-control` 0.12.11（新脚本 + `ss_uimap.py text` + `ss_libref.py` 0.3.0） |
| 0.2.0 | 2026-11-21 | 新增 §2b 路径 c：「没有源代码的库」+禁显 → 源可见库（无密文可重加密，靠明文装配），端到端 UI 实测 PASS；§3 增加"取证式/交付式"两种收尾、坑 5（Git Bash 改写盘符路径）与坑 6（库索引表格不暴露树）、§3.3 `转到下层` 通道、§3.4 磁盘复核口径 |
| 0.1.1 | 2026-11-20 | 口径澄清：实测对象=创建类型「常规库」+勾选「禁用源显示」；「没有源代码的库」+禁显组合标未验证，不外推 |
| 0.1.0 | 2026-11-20 | 首版：双路径重建、结构校验、UI 实测闭环与四个坑（实测 7 POU 库端到端 PASS） |
