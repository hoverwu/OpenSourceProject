#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""批量把 script.json（或纯文本行稿）合成成克隆音色的旁白 + SRT + meta。

Agent 负责写内容；本脚本只负责调 GPT-SoVITS API 出声，并按实测时长生成字幕。
内置近无声检测（MIN_PEAK=200，最多重试 3 次；缓存命中也校验）：
全 0 或过弱都会失败，避免整批产出“有文件没声音”。极短句会给出改写警告。

用法：
  python tts_batch.py \
    --script "<剧集>/script.json" \
    --out "<剧集>/chapters/chNN/assets/audio/chNN" \
    --ref "<参考音频.wav>" \
    --prompt-text "<参考音频逐字稿>"

输出：<out>.wav / <out>.mp3 / <out>.srt / <out>.meta.json / <out>_parts/*.wav
依赖：numpy（训练环境自带）、ffmpeg（转 MP3 用，可选）。
"""
import argparse
import json
import os
import re
import subprocess
import sys
import urllib.request
import wave

import numpy as np

# 实测：正常句峰值 600~1000；坏句只有 25~60（int16），全 0 检查抓不到。
MIN_PEAK = 200
MAX_RETRY = 3


def peak_of(pcm):
    return int(np.abs(pcm).max()) if pcm.size else 0


def split_sentences(text, max_chars=70):
    text = re.sub(r"\s+", "", text or "")
    if not text:
        return []
    parts = re.split(r"(?<=[。！？!?；;])", text)
    out = []
    for p in parts:
        p = p.strip()
        if not p:
            continue
        if len(p) <= max_chars:
            out.append(p)
            continue
        subs = re.split(r"(?<=[，,、：:])", p)
        buf = ""
        for s in subs:
            if len(buf) + len(s) > max_chars and buf:
                out.append(buf)
                buf = s
            else:
                buf += s
        if buf:
            out.append(buf)
    return [s for s in out if s]


def load_units(path, max_chars):
    units = []
    if path.lower().endswith(".json"):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        scenes = data.get("scenes", [])
        if not scenes:
            raise ValueError("script.json 里没有 scenes")
        for sc in scenes:
            sid = sc.get("id", "S")
            for t in split_sentences(sc.get("narration", ""), max_chars) or [""]:
                units.append((sid, t))
    else:
        with open(path, "r", encoding="utf-8-sig") as f:
            for i, line in enumerate(f, 1):
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                for t in split_sentences(line, max_chars):
                    units.append((f"L{i:03d}", t))
    return units


def synth(text, api, ref, prompt_text, timeout=600):
    payload = json.dumps({
        "text": text,
        "text_lang": "zh",
        "ref_audio_path": ref,
        "prompt_text": prompt_text,
        "prompt_lang": "zh",
        "text_split_method": "cut0",
    }).encode("utf-8")
    req = urllib.request.Request(
        api.rstrip("/") + "/tts",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def read_wav(data_bytes):
    with wave.open(__import__("io").BytesIO(data_bytes), "rb") as w:
        sr = w.getframerate()
        pcm = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    return sr, pcm


def fmt_time(sec):
    ms = int(round(sec * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--script", required=True, help="script.json 或纯文本行稿")
    ap.add_argument("--out", required=True, help="输出基名，例如 .../assets/audio/ch01")
    ap.add_argument("--api", default="http://127.0.0.1:9880")
    ap.add_argument("--ref", required=True, help="3-10 秒参考音频绝对路径")
    ap.add_argument("--prompt-text", required=True, help="参考音频逐字稿")
    ap.add_argument("--max-chars", type=int, default=70)
    ap.add_argument("--force", action="store_true", help="忽略已缓存的分句音频")
    args = ap.parse_args()

    out_base = os.path.abspath(args.out)
    out_dir = os.path.dirname(out_base)
    os.makedirs(out_dir, exist_ok=True)
    parts_dir = os.path.join(out_dir, os.path.basename(out_base) + "_parts")
    os.makedirs(parts_dir, exist_ok=True)

    units = load_units(args.script, args.max_chars)
    if not units:
        print("没有可合成的句子。", file=sys.stderr)
        return 1
    print(f"共 {len(units)} 句 -> {out_base}")

    pieces, srt_lines, meta_lines = [], [], []
    scene_acc = {}
    cursor = 0.0

    for i, (scene_id, text) in enumerate(units, 1):
        part = os.path.join(parts_dir, f"{i:04d}_{scene_id}.wav")
        cached = os.path.exists(part) and not args.force
        if cached:
            with wave.open(part, "rb") as w:
                sr = w.getframerate()
                pcm = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
            if peak_of(pcm) < MIN_PEAK:
                # 缓存里的近无声句也要重录，否则会一直复用坏音频
                print(f"[{i}] 缓存过弱 (peak={peak_of(pcm)})，重新合成", file=sys.stderr)
                cached = False
        if not cached:
            if len(text) <= 5:
                print(f"[{i}] 警告：极短句（{len(text)} 字）克隆音色容易塌，"
                      f"建议改写加长。", file=sys.stderr)
            sr = pcm = None
            for attempt in range(1, MAX_RETRY + 1):
                sr, pcm = read_wav(synth(text, args.api, args.ref, args.prompt_text))
                pk = peak_of(pcm)
                if pk >= MIN_PEAK:
                    break
                print(f"[{i}] 第 {attempt}/{MAX_RETRY} 次输出过弱 (peak={pk})，重试…",
                      file=sys.stderr)
            else:
                raise RuntimeError(
                    f"第 {i} 句全 0 或过弱 (peak={peak_of(pcm)})：{text}"
                )
            with wave.open(part, "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(sr)
                w.writeframes(pcm.tobytes())

        dur = len(pcm) / float(sr)
        start, end = cursor, cursor + dur
        cursor = end
        pieces.append(pcm)
        srt_lines.append(f"{i}\n{fmt_time(start)} --> {fmt_time(end)}\n{text}\n")
        meta_lines.append({
            "index": i, "scene": scene_id, "text": text,
            "start": round(start, 3), "end": round(end, 3),
            "duration": round(dur, 3), "wav": part, "cached": cached,
        })
        acc = scene_acc.setdefault(
            scene_id, {"start": round(start, 3), "end": round(end, 3), "sentences": 0}
        )
        acc["end"] = round(end, 3)
        acc["sentences"] += 1
        print(f"[{i:3d}/{len(units)}] {scene_id} {dur:5.2f}s "
              f"{'cache' if cached else 'synth'} | {text[:26]}")

    with wave.open(meta_lines[0]["wav"], "rb") as w:
        target_sr = w.getframerate()
    merged = np.concatenate([p for p in pieces if p.size]).astype(np.int16)

    wav_path = out_base + ".wav"
    with wave.open(wav_path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(target_sr)
        w.writeframes(merged.tobytes())

    with open(out_base + ".srt", "w", encoding="utf-8") as f:
        f.write("\n".join(srt_lines))

    meta = {
        "voice": "GPT-SoVITS v2ProPlus cloned voice (fp32 inference)",
        "ref_audio": args.ref,
        "prompt_text": args.prompt_text,
        "total_duration": round(cursor, 3),
        "sentences": meta_lines,
        "scenes": scene_acc,
    }
    with open(out_base + ".meta.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    mp3_path = out_base + ".mp3"
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-loglevel", "error", "-i", wav_path,
             "-af", "loudnorm=I=-14:TP=-1:LRA=7,aresample=48000",
             "-ac", "2", "-c:a", "libmp3lame", "-b:a", "192k", mp3_path],
            check=True,
        )
        print("MP3:", mp3_path)
    except Exception as e:
        print("MP3 转换跳过（WAV/SRT 仍可用）:", e, file=sys.stderr)

    print("WAV:", wav_path)
    print("SRT:", out_base + ".srt")
    print("META:", out_base + ".meta.json")
    print(f"总时长 {cursor:.2f}s / 场景 {len(scene_acc)} 个")
    return 0


if __name__ == "__main__":
    sys.exit(main())
