#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""检查一个或多个 WAV 是否静音，并打印时长/峰值/RMS/非零比例。

静音（max==0 或 nonzero==0）时退出码为 1；正常为 0；读取失败为 2。
用于验证 TTS 输出——时长正确不代表有声。

用法：
  python check_audio.py out.wav
  python check_audio.py *.wav --json
"""
import argparse
import json
import sys
import wave

import numpy as np


def inspect(path):
    with wave.open(path, "rb") as w:
        sr = w.getframerate()
        ch = w.getnchannels()
        sw = w.getsampwidth()
        frames = w.getnframes()
        dtype = {1: np.int8, 2: np.int16, 4: np.int32}.get(sw, np.int16)
        raw = w.readframes(frames)
    d = np.frombuffer(raw, dtype=dtype)
    if d.size == 0:
        return {"path": path, "error": "empty PCM", "silent": True}
    f = d.astype(np.float64)
    peak = int(np.abs(f).max())
    rms = float(np.sqrt((f * f).mean()))
    nonzero = float((d != 0).mean() * 100)
    return {
        "path": path,
        "duration_s": round(frames / float(sr), 3),
        "sample_rate": sr,
        "channels": ch,
        "sample_width": sw,
        "max": peak,
        "rms": round(rms, 2),
        "nonzero_pct": round(nonzero, 2),
        "silent": peak == 0 or nonzero == 0,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+", help="WAV 文件路径")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    args = ap.parse_args()

    results = []
    for path in args.files:
        try:
            results.append(inspect(path))
        except Exception as e:
            results.append({"path": path, "error": str(e), "silent": True})

    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        for r in results:
            if "error" in r:
                print(f"[ERR ] {r['path']}: {r['error']}")
            else:
                flag = "SILENT" if r["silent"] else "OK    "
                print(
                    f"[{flag}] {r['path']}  dur={r['duration_s']}s "
                    f"sr={r['sample_rate']} max={r['max']} "
                    f"rms={r['rms']} nonzero={r['nonzero_pct']}%"
                )

    if any(r.get("silent", True) for r in results):
        print("FAIL: 存在静音或读取失败的音频。", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
