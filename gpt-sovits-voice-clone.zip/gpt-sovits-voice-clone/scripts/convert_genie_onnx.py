#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""把 GPT-SoVITS v2ProPlus 的 .pth + .ckpt 转成 Genie-TTS ONNX，供弱显卡/CPU 机器离线推理。

只支持 V2 / V2ProPlus；不要用于 V3/V4。
运行前必须先备好 GenieData，否则 import genie_tts 会挂在隐藏 input()。

用法：
  python convert_genie_onnx.py \
    --pth "<PKG>\SoVITS_weights_v2ProPlus\<EXP>_e12_s1176.pth" \
    --ckpt "<PKG>\GPT_weights_v2ProPlus\<EXP>-e5.ckpt" \
    --out "<DEPLOY_DIR>\models\onnx"

环境：Python 3.10 venv，genie-tts==2.0.2、onnxruntime、numpy<2、torch、onnx、tokenizers、
soundfile、pyopenjtalk-plus 及 G2P 依赖。
"""
import argparse
import os
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pth", required=True, help="SoVITS 权重 .pth 路径")
    ap.add_argument("--ckpt", required=True, help="GPT 权重 .ckpt 路径")
    ap.add_argument("--out", required=True, help="ONNX 输出目录")
    ap.add_argument("--genie-data", default="", help="GenieData 目录（用于预检）")
    ap.add_argument("--dry-run", action="store_true", help="只打印将要执行的操作")
    args = ap.parse_args()

    for label, path in (("pth", args.pth), ("ckpt", args.ckpt)):
        if not os.path.isfile(path):
            print(f"FAIL: {label} 不存在：{path}", file=sys.stderr)
            return 2

    if args.genie_data and not os.path.isdir(args.genie_data):
        print(f"FAIL: GenieData 不存在：{args.genie_data}", file=sys.stderr)
        return 2

    out_dir = os.path.abspath(args.out)
    if args.dry_run:
        print(f"convert_to_onnx(torch_pth_path={args.pth!r}, "
              f"torch_ckpt_path={args.ckpt!r}, output_dir={out_dir!r})")
        return 0

    try:
        import genie_tts
    except Exception as e:
        print(f"FAIL: 导入 genie_tts 失败（检查 venv / GenieData）：{e}", file=sys.stderr)
        return 2

    if not hasattr(genie_tts, "convert_to_onnx"):
        print("FAIL: 当前 genie-tts 版本没有 convert_to_onnx，请装 2.0.2。", file=sys.stderr)
        return 2

    os.makedirs(out_dir, exist_ok=True)
    try:
        genie_tts.convert_to_onnx(
            torch_pth_path=args.pth,
            torch_ckpt_path=args.ckpt,
            output_dir=out_dir,
        )
    except Exception as e:
        print(f"FAIL: ONNX 转换失败：{e}", file=sys.stderr)
        return 1

    files = []
    for root, _, names in os.walk(out_dir):
        for n in names:
            files.append(os.path.join(root, n))
    if not files:
        print("FAIL: 输出目录为空。", file=sys.stderr)
        return 1

    print(f"PASS: 生成 {len(files)} 个文件 -> {out_dir}")
    for f in files:
        print("  ", f, os.path.getsize(f))
    print("下一步：把 onnx 目录 + GenieData + genie-env 拷到目标机，用 onnxruntime CPU 推理；"
          "部署后同样要跑 check_audio.py 验证非静音。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
