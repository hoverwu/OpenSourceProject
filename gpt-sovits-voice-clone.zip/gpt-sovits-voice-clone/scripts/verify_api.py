#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""对本机 GPT-SoVITS API 做端到端健康检查：发短文本请求并检查输出非静音。

正常退出码 0；静音 1；网络/HTTP 错误 2。
启动 API 后先跑这个，再跑批量配音，避免整批产出静音。

用法：
  python verify_api.py --ref <参考音频.wav> --prompt-text "<逐字稿>"
"""
import argparse
import io
import json
import sys
import urllib.request
import wave

import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", default="http://127.0.0.1:9880")
    ap.add_argument("--ref", required=True, help="3-10 秒参考音频绝对路径")
    ap.add_argument("--prompt-text", required=True, help="参考音频逐字稿")
    ap.add_argument("--text", default="测试声音。")
    ap.add_argument("--out", default="", help="可选：把响应保存为 WAV")
    args = ap.parse_args()

    payload = json.dumps({
        "text": args.text,
        "text_lang": "zh",
        "ref_audio_path": args.ref,
        "prompt_text": args.prompt_text,
        "prompt_lang": "zh",
        "text_split_method": "cut0",
    }).encode("utf-8")

    try:
        req = urllib.request.Request(
            args.api.rstrip("/") + "/tts",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=600) as r:
            data = r.read()
    except Exception as e:
        print(f"FAIL: 请求失败：{e}", file=sys.stderr)
        return 2

    if args.out:
        with open(args.out, "wb") as f:
            f.write(data)

    try:
        with wave.open(io.BytesIO(data), "rb") as w:
            sr = w.getframerate()
            pcm = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
        peak = int(np.abs(pcm).max())
        rms = float(np.sqrt((pcm.astype(np.float64) ** 2).mean()))
        dur = len(pcm) / float(sr)
    except Exception as e:
        print(f"FAIL: 响应不是有效 WAV：{e}", file=sys.stderr)
        return 2

    print(f"dur={dur:.2f}s max={peak} rms={rms:.1f} bytes={len(data)}")
    if peak == 0:
        print(
            "FAIL: 输出是全 0 静音。检查 tts_infer.yaml 是否 is_half: false "
            "（无 Tensor Core 卡上 fp16 推理会静音），然后重启 API。",
            file=sys.stderr,
        )
        return 1
    print("PASS: API 正常且输出有声。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
