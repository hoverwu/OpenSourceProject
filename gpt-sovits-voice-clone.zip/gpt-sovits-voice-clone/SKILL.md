---
name: gpt-sovits-voice-clone
description: Build and deploy a local cloned-voice pipeline with GPT-SoVITS v2ProPlus. Use when cloning a voice on a mid-range NVIDIA GPU (e.g. a 6 GB GTX 16-series card), training SoVITS/GPT weights from AISHELL-1 or licensed audio, debugging silent TTS output, batch-generating narration with subtitles for video tools such as HyperFrames, or running the trained voice on a weak-GPU / CPU-only machine via Genie-TTS ONNX. Covers installation, data alignment, headless training, mandatory waveform verification, fp16 pitfalls, and lightweight offline deployment.
agent_created: true
---

# GPT-SoVITS 本地克隆语音：训练、验证与弱显卡部署

## 概述

本技能沉淀了一条已在 6 GB 显存 NVIDIA 笔记本（GTX 16 系）上完整跑通、并面向弱显卡/无独显电脑部署的克隆语音流水线。核心选 **GPT-SoVITS v2ProPlus**（不选 V3/V4，因为 Genie-TTS 只支持 V2/V2ProPlus 的 ONNX 转换）。整条链路分两台机器：训练机出权重，弱显卡机只做 CPU/劣质显卡推理。

## 何时使用

- 用户要在本地电脑上克隆一个声音，并给出训练语料（AISHELL-1、本人录音等）。
- 用户要确认某个 TTS 输出“有没有声音”——必须检查波形，不能只看时长和 HTTP 200。
- 用户要把训练好的 `.pth` / `.ckpt` 拿到显卡很差的电脑上离线用。
- 用户要把克隆音色接进视频流水线（HyperFrames 等）做批量旁白和字幕。

## 硬件与方案决策

| 场景 | 方案 |
|---|---|
| 训练机：6 GB 显存（GTX 16 系等 Turing 无 Tensor Core 卡） | GPT-SoVITS v2ProPlus 整合包 + 自带 runtime；训练可用 fp16，**推理必须 fp32** |
| 目标机：显卡很差或无独显 | 同权重转 Genie-TTS ONNX，`onnxruntime` CPU 推理；不重训 |
| 语料 | 优先 AISHELL-1 等有明确许可的开源数据；商业音乐/他人声音先取得授权 |

不要在 6 GB 卡上选 V3/V4：Onnx 转换不兼容，且显存更紧。

## 端到端流程

按顺序推进，每个阶段都要留证据文件（结论、日志、哈希、耗时）。

### 阶段 0：合规与数据准备

- 确认声音来源授权；拒绝未授权的商业音频或他人音色。
- AISHELL-1：`speech_asr_aishell_testsets.zip` + `aishell_transcript_v0.8.txt`，按说话人抽取 40–60 句、3–8 秒、合计 3–5 分钟。
- 生成 GPT-SoVITS `.list`：`绝对路径|说话人ID|zh|去掉空格的转写`。
- 留出 1 条训练集外参考音频（3–10 秒）和对应逐字稿。
- 详细命令见 `references/setup-and-training.md`。

### 阶段 1：安装整合包

- 从 ModelScope 镜像下载官方 Windows 7z 整合包（HuggingFace 直连慢）；用 `7zr.exe` 解压，`py7zr` 遇到 BCJ2 过滤会失败。
- Python 3.10 + 整合包自带 runtime；**不要用 Python 3.13**（`jieba_fast` 编译失败）。
- 解压后改写 `runtime\Lib\site-packages\users.pth` 里打包者的硬编码路径为本机路径。
- Genie-TTS 环境单独建 venv（3.10），先下好 `GenieData` 再 import，否则 `Resources.ensure_exists` 里隐藏的 `input()` 会挂住。
- 详见 `references/setup-and-training.md`。

### 阶段 2：无头训练

- 用编排脚本依次跑 1A 文本/BERT → 1B HuBERT/wav32k/SV → 1C 语义 token → 2A SoVITS → 2B GPT。
- 关键参数：`batch_size=1`、`epochs=12`（SoVITS）/ 15（GPT）、`grad_ckpt=True`、fp16 训练、`gpu_numbers="0"`。
- `gpu_numbers` 写成 `"0-0"` 会被转成 `CUDA_VISIBLE_DEVICES="0,0"` 导致无效序号并静默回退 CPU——必须写 `"0"`。
- 预先创建 `logs_s2_v2ProPlus` / `logs_s1_v2ProPlus`；YAML 注入键必须缩进在 `train:` 段内。
- GPT 中途 CUDA 崩溃时，取已保存的 epoch 5 权重即可，不必重跑。
- 模板与逐阶段命令见 `references/setup-and-training.md`。

### 阶段 3：推理验证（最容易出错）

**铁律：只检查时长和 HTTP 200 不算通过，必须检查波形非零。**

- 先把 `tts_infer.yaml` 的 `custom` 段指向训练权重，`version: v2ProPlus`，`device: cuda`。
- **GTX 16 系等无 Tensor Core 卡必须设 `is_half: false`**。fp16 推理会产生 NaN/下溢，转 int16 时全部变 0，得到“有文件没声音”的静音 WAV。训练用 fp16 保存权重没问题，推理不能开。
- 启动 API：`runtime\python.exe -u api_v2.py -a 127.0.0.1 -p 9880 -c GPT_SoVITS/configs/tts_infer.yaml`。
- 用 `scripts/verify_api.py` 发短文本请求；用 `scripts/check_audio.py` 检查 max / RMS / 非零采样数。
- 显存基线约 4.8 GB、峰值约 5.2 GB（6 GB 卡可用）。
- 完整排查见 `references/inference-and-verification.md`。

### 阶段 4：批量配音与字幕

- Agent 负责理解内容并写 `script.json` 的 `scenes[].narration`；TTS 只负责出声。
- 运行批量脚本（参考音频与逐字稿必填）：
  ```bash
  python scripts/tts_batch.py \
    --script <script.json> \
    --out <章节音频基名> \
    --ref <参考音频.wav> \
    --prompt-text "<参考音频逐字稿>"
  ```
  它逐句调 API、拼整章音频、按实测时长生成 SRT 与 `meta.json`。
- 脚本对全 0 **和近无声**（峰值 < 200）都报错并自动重试 3 次，缓存命中也校验。极短句（≤5 字）容易塌成近无声，优先改写加长，而不是降低阈值。
- 接 HyperFrames 的细节见 `references/hyperframes-integration.md`。

### 阶段 5：部署到弱显卡电脑

- 在训练机上用 Genie-TTS `convert_to_onnx()` 把 `.pth` + `.ckpt` 转 ONNX，全程按 fp32 处理。
- 拷贝：ONNX 模型、`GenieData`、venv、`config.json`；目标机用 `onnxruntime` CPU 推理，不加载 PyTorch/CUDA。
- 目标机只做推理，不训练；显存差也能跑，代价是 RTF 更高。
- 步骤与限制见 `references/weak-gpu-deployment.md`。

## 全局铁律

1. **先验波形再宣称成功**：静音文件也有正确时长和 SHA。
2. **训练机推理一律 fp32**（无 Tensor Core 卡）；fp16 只用于训练保存权重。
3. **不盲等慢下载**：HuggingFace 慢就切 ModelScope 镜像或分段续传，但先确认方案没选错。
4. **证据落盘**：每次训练/推理留 `findings_*.md`、日志、显存采样、关键哈希。
5. **GPU 占用看 `nvidia-smi`**，任务管理器可能显示 0%——CUDA 计算不被它统计。

## 资源

- `references/setup-and-training.md` — 安装、语料对齐、无头训练编排与参数。
- `references/inference-and-verification.md` — API 启动、fp16 静音根因、波形验证。
- `references/weak-gpu-deployment.md` — Genie-TTS ONNX 转换与弱显卡/CPU 推理。
- `references/troubleshooting.md` — 全部踩坑速查表。
- `references/hyperframes-integration.md` — 克隆音色接入视频流水线。
- `scripts/check_audio.py` — 检查 WAV 是否静音。
- `scripts/verify_api.py` — 健康检查 API 并验证输出有声。
- `scripts/tts_batch.py` — 批量合成旁白 + SRT + meta。
- `scripts/convert_genie_onnx.py` — Genie-TTS ONNX 转换模板。
