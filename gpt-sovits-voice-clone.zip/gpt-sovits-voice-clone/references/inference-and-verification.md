# 推理验证：fp16 静音陷阱与波形检查

## 1. 配置 custom 段

`<PKG>\GPT_SoVITS\configs\tts_infer.yaml` 的 `custom:` 段改为：

```yaml
custom:
  bert_base_path: GPT_SoVITS/pretrained_models/chinese-roberta-wwm-ext-large
  cnhuhbert_base_path: GPT_SoVITS/pretrained_models/chinese-hubert-base
  device: cuda
  is_half: false          # 关键：训练机推理必须 fp32
  t2s_weights_path: GPT_weights_v2ProPlus/<EXP>-e5.ckpt
  version: v2ProPlus
  vits_weights_path: SoVITS_weights_v2ProPlus/<EXP>_e12_s1176.pth
```

## 2. 启动 API

```bash
cd <PKG>
runtime\python.exe -u api_v2.py -a 127.0.0.1 -p 9880 -c GPT_SoVITS/configs/tts_infer.yaml
```

启动日志会打印 TTS Config；确认 `is_half: False`、`version: v2ProPlus`，并等 `Uvicorn running on http://127.0.0.1:9880`。加载权重需 1–2 分钟，期间没有输出是正常的。后台任务可能在数小时后自行退出（exit 127）；用同一命令重启即可。

## 3. 请求示例

```python
import json, urllib.request
payload = json.dumps({
    "text": "人工智能语音合成技术发展迅速，今天天气晴朗，适合出门散步。",
    "text_lang": "zh",
    "ref_audio_path": r"<WORK>\ref_s0764.wav",
    "prompt_text": "甚至出现交易几乎停滞的情况",
    "prompt_lang": "zh",
    "text_split_method": "cut0",
}).encode("utf-8")
req = urllib.request.Request("http://127.0.0.1:9880/tts",
                             data=payload,
                             headers={"Content-Type": "application/json"})
data = urllib.request.urlopen(req, timeout=600).read()
open("out.wav", "wb").write(data)
```

参考音频超出 3–10 秒会被拒绝；`prompt_text` 要与参考音频逐字稿一致。

## 4. 必须检查波形

运行 `scripts/check_audio.py out.wav`。正常结果应类似：

```
dur 7.26s  max 1009  rms 169.0  nonzero 92.9%
```

判断标准：

- `max == 0` 或 `nonzero == 0` → **静音，未通过**，哪怕 HTTP 200、时长正确。
- `max` 只有几百、RMS 一百多 → 有声但偏小。可用脚本放大或交给后续 ffmpeg `loudnorm` 处理。
- 已验证的修复案例：fp16 输出 `debug_fp16.wav` max=0；改 fp32 后 `debug_fp32.wav` max=1077 / RMS=178 / 非零 227510。

## 5. 根因：为什么 fp16 会静音

GTX 16 系（Turing TU116）**没有 Tensor Core**，fp16 计算吞吐极低。GPT-SoVITS 在 `is_half: true` 时会把 BERT、CNHuBERT、GPT、SoVITS、Vocoder 全部 `.half()`；该链路上产生 NaN 或极端下溢，最后 `audio_postprocess` 执行 `(audio * 32768).astype(np.int16)`，NaN 被转成 0，于是整段 WAV 全 0。

注意区分：

- **训练用 fp16 保存权重没问题**（权重实测 NaN=0 / Inf=0，dtype 为 float16）。
- **推理必须 fp32**。这是两回事，不要因为训练成功就推断推理也行。
- 任务管理器 GPU 占用显示 0% 不代表没在用 GPU——它不统计 CUDA 计算。以 `nvidia-smi` 为准（实测训练时占用率 84%、P0 状态）。

## 6. 显存与性能基线（6 GB 显存档）

| 指标 | 数值 |
|---|---|
| 服务加载后基线 | 4842 MiB |
| 合成峰值 | 5180 MiB / 6144 MiB（84%） |
| 热服务合成 7.26 s 音频 | 5.2 s |

6 GB 卡可以跑 fp32 推理；关掉其它占显存程序即可。

## 7. 留痕

把以下写进 `findings_*.md`：配置片段、请求文本、参考音频、波形统计、显存基线/峰值、耗时、输出 SHA256 前若干位、证据文件名（如 `debug_fp16.wav`、`debug_fp32.wav`、`api_server*.log`、`vram_fp32.txt`）。
