# 把训练好的声音部署到显卡很差的电脑

## 1. 方案选择

目标机（弱显卡 / 无独显电脑）不重训、不跑 GPT-SoVITS 完整栈。做法是把训练好的 `.pth` + `.ckpt` 转成 **Genie-TTS ONNX**，用 `onnxruntime` 在 CPU 上推理。

限制必须提前讲清：**Genie-TTS 只支持 V2 / V2ProPlus，不支持 V3/V4**。这正是训练阶段选 v2ProPlus 的原因。

## 2. 转换（训练机或任意有 Python 的机器）

`scripts/convert_genie_onnx.py` 为模板，核心调用：

```python
import genie_tts

genie.convert_to_onnx(
    torch_pth_path=r"<PKG>\SoVITS_weights_v2ProPlus\<EXP>_e12_s1176.pth",
    torch_ckpt_path=r"<PKG>\GPT_weights_v2ProPlus\<EXP>-e5.ckpt",
    output_dir=r"<OUT>\onnx",
)
```

要点：

- 环境：Python 3.10 venv，`genie-tts==2.0.2`、`onnxruntime`、`numpy<2`、`torch`、`onnx`、`tokenizers`、`soundfile`、`pyopenjtalk-plus` 及 G2P 依赖。
- **先备好 `GenieData` 再 import**，否则隐藏 `input()` 会挂住进程。
- 权重按 fp32 处理；不要在目标机再开 fp16。
- 转换后验证 `genie.tts` 能调用并产出非静音音频。

## 3. 目标机环境

只需 CPU 依赖，不需要 CUDA / 大显存：

```
<DEPLOY_DIR>\
  genie-env\              # Python 3.10 venv（onnxruntime + genie-tts + 依赖）
  GenieData\              # 约 391 MB / 17 文件
  models\onnx\            # 转换出的 ONNX 模型
  config.json
```

推理代码路径与目标机无关：

```python
import genie_tts
# 按 genie-tts 2.0.2 的 tts 接口传入文本、模型目录、参考音频
```

## 4. 体积参考

| 项 | 大小 |
|---|---|
| SoVITS `.pth` | 172 MB |
| GPT `.ckpt` | 155 MB |
| GenieData | 391.5 MB |
| 整合包（训练机） | 14.13 GB / 50,612 文件 |

目标机不用拷贝 14 GB 整合包，只带 ONNX 模型 + GenieData + 小 venv。

## 5. 预期取舍

- 弱显卡/CPU 推理速度显著慢于 6 GB GPU，适合离线批量生成，不适合实时对话。
- 音色一致性依赖同一个参考音频和逐字稿；换音色改参考音频即可。
- 部署后同样要跑波形检查（`scripts/check_audio.py`），不能只看文件存在。

## 6. 合规

只克隆本人或已获明确授权的声音。训练语料与参考音频的许可要能追溯到来源。
