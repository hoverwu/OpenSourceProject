# 克隆音色接入 HyperFrames 视频流水线

## 1. 分工

- **Agent 负责内容**：理解主题、写 `script.json` 的 `scenes[].narration`，以及画面分镜。
- **GPT-SoVITS 只负责出声**：把每段 narration 合成 WAV，不参与内容创作。
- **HyperFrames 负责渲染**：它不加载 GPT-SoVITS / Genie-TTS 模型，只把 `<audio>` 文件混进成片。

因此不要用 HyperFrames 自带的 `tools/tts-edge.sh`（Edge TTS `zh-CN-XiaoxiaoNeural`，音色不同），也不要用 `hyperframes tts`（本地 Kokoro-82M，且不是克隆音色）。

## 2. 批量合成

```bash
python scripts/tts_batch.py \
  --script "<剧集>/script.json" \
  --out "<剧集>/chapters/chNN/assets/audio/chNN" \
  --ref "<WORK>\ref_s0764.wav" \
  --prompt-text "甚至出现交易几乎停滞的情况"
```

输出：

- `chNN.wav` / `chNN.mp3`（整章旁白；MP3 为 48 kHz stereo / -14 LUFS）
- `chNN.srt`（一句一条，时间来自实测音频时长）
- `chNN.meta.json`（每句与每场的 `start` / `end` / `duration`）
- `chNN_parts/*.wav`（每句音频，支持断点续跑）

脚本按中文标点切句，长句再按逗号切；检测全 0 或近无声（峰值 < 200）会重试，仍不合格则报错。

**重跑 TTS 后必须重跑流水线的音频重定时步骤**（如 `build/retime_audio.py`），否则 TTS 会重写未加间隙的原版 `<base>.wav/.mp3/.srt`，覆盖已按场景时间轴切好的版本，造成音画错位。已有剧集里曾发生过一次这种覆盖。

## 3. 章节 HTML

结构与原来兼容，只需保证 `id` 与路径：

```html
<audio id="vo"
  src="assets/audio/chNN.mp3"
  data-start="0"
  data-duration="708.104"
  data-volume="1"
></audio>
```

`data-duration` 取整章时长；场景的 `data-start` / `data-duration` 用 `meta.json` 的 `scenes` 聚合时长对齐。

## 4. 字幕

GPT-SoVITS 不输出词级时间戳。本方案按句生成 SRT，天然与克隆音色的每句一一对应，Agent 不用手算时间。需要逐词高亮时，另跑转写引擎（Parakeet / whisper.cpp）生成词级 JSON。

## 5. 门禁

改了音频源文件后：

1. `npm run gate -- verify` —— 相关节点变 stale。
2. `npm run gate -- request ep01/G5` —— 重新申请音频节点。
3. 审批台人工通过（不要让 Agent 代点 approve/reject）。
4. `npm run render:guarded` 渲染，禁止裸调 `hyperframes render`。

同时把 `pipeline/project.json` 和 `brief.md` 的“配音”字段改成 `GPT-SoVITS S0764 v2ProPlus`，避免规格与产物不一致。
