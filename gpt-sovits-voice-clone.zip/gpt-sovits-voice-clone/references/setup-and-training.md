# 安装、语料对齐与无头训练

本文给出在 6 GB 显存 Windows 电脑上从零到权重落盘的可复跑细节。路径中的 `<PKG>` 指整合包根目录，`<WORK>` 指本任务工作区；按本机实际替换。

## 1. 安装整合包

1. 从 ModelScope 镜像 `FlowerCry/gpt-sovits-7z-pacakges` 下载 `GPT-SoVITS-v2pro-20250604.7z`。HuggingFace 直连常只有 40–50 KB/s；ModelScope 快得多。若仍慢，用 12 线程分段续传下载器，按 `Content-Length` 校验总大小（实测 8,185,086,602 字节）。
2. 用官方 `7zr.exe` 解压（`py7zr` 对 BCJ2 过滤会失败）。解压后约 50,612 文件 / 14.13 GB。
3. 运行整合包自带 `runtime\python.exe`，不要另装 Python 3.13（`jieba_fast` 编译失败）。若需独立 Python，用 3.10.x。
4. 改写 `<PKG>\runtime\Lib\site-packages\users.pth`：把打包者硬编码的 `D:\BaiduNetdiskDownload\...` 全部换成 `<PKG>` 下对应路径，否则子进程 `import text` / `GPT_SoVITS` 全挂。
5. 确认 `<PKG>\go-webui.bat` 与 `api_v2.py` 存在。

## 2. Genie-TTS 环境（为目标机准备，训练机也装）

```bash
python3.10 -m venv <GENIE_ENV>
<GENIE_ENV>\Scripts\pip install genie-tts==2.0.2 onnxruntime numpy"<2" torch onnx tokenizers soundfile pyopenjtalk-plus
```

先把 `GenieData` 下到 `<GENIE_ENV>\GenieData`（约 391 MB / 17 文件，可用 hf-mirror），**再** import `genie_tts`。否则 `Resources.ensure_exists` 会弹出隐藏 `input()`，进程看似挂死。验证：

```python
import genie_tts
assert hasattr(genie_tts, "convert_to_onnx") and hasattr(genie_tts, "tts")
```

## 3. 语料准备（AISHELL-1 示例）

- 下载 `speech_asr_aishell_testsets.zip` 与官方 `aishell_transcript_v0.8.txt`。
- 按说话人（如 S0764）抽取 40–60 句、单句 3–8 秒、合计 3–5 分钟。
- 从 transcript 取对应行，去掉空格，写 `<WORK>\s0764.list`：
  ```
  <WORK>\dataset_s0764\BAC009S0764W0209.wav|s0764|zh|甚至出现交易几乎停滞的情况
  ```
  每行格式：`wav绝对路径|说话人ID|zh|去空格转写`。
- 留一条训练集外参考音频（3–10 秒）和逐字稿，如 `ref_s0764.wav` + `ref_s0764.txt`。API 会拒绝 3 秒以下或 10 秒以上的参考音频。
- 用 `wave` / `numpy` 打印每条时长，存 `s0764_durs.json`，便于筛选。

## 4. 无头训练编排

以已验证的 `train_s0764.py` 为模板（脚本放在任务工作区，可复制到新机器改常量）。它用系统 Python 启动 `<PKG>\runtime\python.exe -s ...` 子进程，按阶段幂等执行。

需要改的常量：

```python
PKG  = r"<PKG>"
PY   = os.path.join(PKG, "runtime", "python.exe")
EXP  = "<说话人>_v2ProPlus"
LIST_FILE = r"<WORK>\<说话人>.list"
LOG_DIR   = r"<WORK>\train_logs"
```

关键环境与配置：

- 公共 env：`inp_text=LIST_FILE`、`exp_name=EXP`、`opt_dir=logs/<EXP>`、`i_part=0`、`all_parts=1`、`_CUDA_VISIBLE_DEVICES="0"`、`is_half="True"`（训练可用 fp16）。
- **GPU 序号必须 `"0"`**。写 `"0-0"` 会被展开成 `CUDA_VISIBLE_DEVICES="0,0"`，出现 CUDA Error 101 并静默回退 CPU（实测 7.3 s/it vs 1.43 s/it）。
- 1A：`GPT_SoVITS/prepare_datasets/1-get-text.py`，附 `bert_pretrained_dir`；结束后合并 `2-name2text-0.txt` → `2-name2text.txt`。
- 1B：`2-get-hubert-wav32k.py` + `2-get-sv.py`，附 `cnhubert_base_dir`、`sv_path`。
- 1C：`3-get-semantic.py`，附 `pretrained_s2G=.../v2Pro/s2Gv2ProPlus.pth` 与 `s2config_path=.../s2v2ProPlus.json`；合并 `6-name2semantic-0.tsv` → `.tsv`。
- 2A SoVITS：改 `s2v2ProPlus.json` 的 `train.batch_size=1`、`epochs=12`、`save_every_epoch=4`、`if_save_every_weights=True`、`gpu_numbers="0"`、`grad_ckpt=True`、`lora_rank=8`；`model.version="v2ProPlus"`；`save_weight_dir=SoVITS_weights_v2ProPlus`。写到 `<PKG>\TEMP\tmp_s2.json` 后传给 `s2_train.py --config`。
- 2B GPT：基于 `s1longer-v2.yaml` 文本替换 `epochs: 15`、`batch_size: 1`、`save_every_n_epoch: 5`；把 `if_save_latest` / `if_save_every_weights` / `if_dpo: false` / `half_weights_save_dir: GPT_weights_v2ProPlus` / `exp_name` **插在 `gradient_clip: 1.0` 之后**（必须缩进在 `train:` 段内，append 到文件尾会被解析进 `inference:`）；顶层追加 `pretrained_s1`、`train_semantic_path`、`train_phoneme_path`、`output_dir`。写到 `<PKG>\TEMP\tmp_s1.yaml` 后传给 `s1_train.py --config_file`。
- 训练前手动创建 `<PKG>\logs\<EXP>\logs_s2_v2ProPlus` 与 `logs_s1_v2ProPlus`，否则 SoVITS 存权重时报错。

实测（49 句 / 241 秒语料，6 GB 显存档）：

| 阶段 | 结果 | 耗时 | 显存峰值 |
|---|---|---|---|
| 1A/1B/1C | exit 0 | 数分钟 | — |
| 2A SoVITS | exit 0，12 epochs × 98 步 | 1799.9 s | 4456 MiB |
| 2B GPT | epoch 7 起 `0xC0000409` 崩溃，但 epoch 5 权重已存 | — | — |

GPT 崩溃时不必重训：取 `GPT_weights_v2ProPlus/<EXP>-e5.ckpt`，推理验证即可。日志显示 top_3_acc 已到 1.000、loss 412→26。

## 5. 产物

- `<PKG>\SoVITS_weights_v2ProPlus\<EXP>_e12_s1176.pth`（约 172 MB）
- `<PKG>\GPT_weights_v2ProPlus\<EXP>-e5.ckpt`（约 155 MB，dtype 为 float16，NaN/Inf 均为 0）

每阶段把 exit code、耗时、显存峰值、日志路径写进 `<WORK>\findings_*.md`。
