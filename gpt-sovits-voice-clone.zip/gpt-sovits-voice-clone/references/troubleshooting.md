# 踩坑速查表

按“现象 → 根因 → 修复”列出已实测的问题。处理新问题时先在此表检索关键词。

| 现象 | 根因 | 修复 |
|---|---|---|
| 输出 WAV 时长正常但全 0 静音 | 无 Tensor Core 卡上 `is_half: true` 推理产生 NaN/下溢，int16 转换归零 | `tts_infer.yaml` 设 `custom.is_half: false`，重启 API，重新推理 |
| 只看了时长和 HTTP 200 就判 PASS | 验证方法错 | 必须跑 `scripts/check_audio.py` 检查 max / RMS / 非零采样 |
| 有字幕没配音，但 WAV 不是全 0 | 近无声句：正常峰值 600~1000，坏句只有 25~60；全 0 检查抓不到 | `tts_batch.py` 用 `MIN_PEAK=200` 闸门，新合成和**缓存命中**都校验，自动重试 3 次 |
| 极短句（≤5 字，如“两条出路。”）连续塌成近无声 | 克隆音色对极短句不稳 | 改写加长（如“剩下的路只有两条。”），比降阈值可靠 |
| HuggingFace 下载 40–50 KB/s | 网络链路慢 | 切 ModelScope 镜像；必要时 12 线程分段续传并校验 Content-Length |
| pip 502 / 超时 | 代理不稳 | 用阿里云/清华镜像，加长 timeout 与重试 |
| Python 3.13 装 `jieba_fast` 编译失败 | 版本不兼容 | 改 Python 3.10；训练用整合包自带 runtime |
| ModelScope 下载出现 `.incomplete` 截断 | 传输中断 | 续传或用整合包下载器替换 |
| `py7zr` 解压失败 | BCJ2 过滤不支持 | 下载官方 `7zr.exe` 解压 |
| 安装器 UAC / 路径空格问题 | 安装参数不当 | 关掉 all-users launcher，`TargetDir` 加引号 |
| `import genie_tts` 永久挂起 | `GenieData` 缺失时 `Resources.ensure_exists` 调隐藏 `input()` | 先下好 GenieData（约 391 MB）再 import |
| API 拒绝参考音频 | 参考音频不在 3–10 秒 | 重新生成合规长度（实测 13 s 被拒，7.09 s 通过） |
| `ModuleNotFoundError: text` | `users.pth` 硬编码打包者 `D:\BaiduNetdiskDownload\...` | 改写为本机 `<PKG>` 路径 |
| 训练跑到 CPU，7.3 s/it | `_CUDA_VISIBLE_DEVICES="0-0"` 被转成 `"0,0"` 无效序号，静默回退 | 改成 `"0"`；GPU 应 1.43 s/it |
| GPU 温度升高、风扇狂转但任务管理器 0% | 任务管理器不统计 CUDA 计算 | 用 `nvidia-smi`：实测占用率 84%、P0 状态 |
| SoVITS 存权重失败 | `logs_s2_v2ProPlus` 目录不存在 | 训练前 `os.makedirs` |
| YAML 参数不生效 | 键被写进 `inference:` 段 | 插在 `train:` 段的 `gradient_clip` 之后，注意缩进 |
| GPT epoch 7 `0xC0000409` 崩溃 | CUDA 驱动级问题 | 用 epoch 5 已存权重；top_3_acc=1.000、loss 已收敛 |
| 后台 API 数小时后退出（exit 127） | 会话/任务生命周期 | 用同一命令重启；确认日志 `is_half: False` 并做短文本健康检查 |
| 用户要求用商业音乐/他人声音训练 | 合规问题 | 拒绝，改用自有或明确授权的语料（如 AISHELL-1） |

## 调试顺序

1. 先看证据文件（日志、`findings_*.md`），不要凭印象。
2. 音频问题先查波形，再查配置。
3. 环境问题先查 Python 版本、路径、依赖顺序。
4. 训练问题先看 exit code 与显存，确认是否真的跑在 GPU 上。
5. 每次修复后重新验证并更新证据文件，不要覆盖历史结论而不注明。
